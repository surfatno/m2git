/*
  This file is licensed to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
*/
package org.xmlunit.util;

/**
 * A function that tests an object for a property.
 * @param <T> type to test
 */
public interface Predicate<T> {
    /**
     * Performs the test.
     * @param toTest the object to test
     * @return true if the test is successful
     */
    boolean test(T toTest);
}
