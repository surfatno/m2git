/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.mutable;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * A mutable {@code short} wrapper.
 * <p>
 * This class was created before the introduction of the {@link java.util.concurrent.atomic} package and the {@link AtomicInteger} class.
 * </p>
 * <p>
 * Note that as MutableShort does not extend Short, it is not treated by String.format as a Short parameter.
 * </p>
 *
 * @see Short
 * @see AtomicInteger
 * @since 2.1
 */
public class MutableShort extends Number implements Comparable<MutableShort>, Mutable<Number> {

    /**
     * Required for serialization support.
     *
     * @see java.io.Serializable
     */
    private static final long serialVersionUID = -2135791679L;

    /** The mutable value. */
    private short value;

    /**
     * Constructs a new MutableShort with the default value of zero.
     */
    public MutableShort() {
    }

    /**
     * Constructs a new MutableShort with the specified value.
     *
     * @param value  The initial value to store, not null.
     * @throws NullPointerException Thrown if the object is null.
     */
    public MutableShort(final Number value) {
        this.value = value.shortValue();
    }

    /**
     * Constructs a new MutableShort with the specified value.
     *
     * @param value  The initial value to store.
     */
    public MutableShort(final short value) {
        this.value = value;
    }

    /**
     * Constructs a new MutableShort parsing the given string.
     *
     * @param value  The string to parse, not null.
     * @throws NumberFormatException Thrown if the string cannot be parsed into a short, see {@link Short#parseShort(String)}.
     * @since 2.5
     */
    public MutableShort(final String value) {
        this.value = Short.parseShort(value);
    }

    /**
     * Adds a value to the value of this instance.
     *
     * @param operand  The value to add, not null.
     * @throws NullPointerException Thrown if the object is null.
     * @since 2.2
     */
    public void add(final Number operand) {
        this.value += operand.shortValue();
    }

    /**
     * Adds a value to the value of this instance.
     *
     * @param operand  The value to add, not null.
     * @since 2.2
     */
    public void add(final short operand) {
        this.value += operand;
    }

    /**
     * Increments this instance's value by {@code operand}; this method returns the value associated with the instance
     * immediately after the addition operation. This method is not thread safe.
     *
     * @param operand The quantity to add, not null.
     * @throws NullPointerException Thrown if {@code operand} is null.
     * @return The value associated with this instance after adding the operand.
     * @since 3.5
     */
    public short addAndGet(final Number operand) {
        this.value += operand.shortValue();
        return value;
    }

    /**
     * Increments this instance's value by {@code operand}; this method returns the value associated with the instance
     * immediately after the addition operation. This method is not thread safe.
     *
     * @param operand The quantity to add, not null.
     * @return The value associated with this instance after adding the operand.
     * @since 3.5
     */
    public short addAndGet(final short operand) {
        this.value += operand;
        return value;
    }

    /**
     * Compares this mutable to another in ascending order.
     *
     * @param other  The other mutable to compare to, not null.
     * @return negative if this is less, zero if equal, positive if greater.
     */
    @Override
    public int compareTo(final MutableShort other) {
        return Short.compare(this.value, other.value);
    }

    /**
     * Decrements the value.
     *
     * @since 2.2
     */
    public void decrement() {
        value--;
    }

    /**
     * Decrements this instance's value by 1; this method returns the value associated with the instance
     * immediately after the decrement operation. This method is not thread safe.
     *
     * @return The value associated with the instance after it is decremented.
     * @since 3.5
     */
    public short decrementAndGet() {
        value--;
        return value;
    }

    /**
     * Returns the value of this MutableShort as a double.
     *
     * @return The numeric value represented by this object after conversion to type double.
     */
    @Override
    public double doubleValue() {
        return value;
    }

    /**
     * Compares this object to the specified object. The result is {@code true} if and only if the argument
     * is not {@code null} and is a {@link MutableShort} object that contains the same {@code short}
     * value as this object.
     *
     * @param obj  The object to compare with, null returns false.
     * @return {@code true} if the objects are the same; {@code false} otherwise.
     */
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof MutableShort) {
            return value == ((MutableShort) obj).shortValue();
        }
        return false;
    }

    /**
     * Returns the value of this MutableShort as a float.
     *
     * @return The numeric value represented by this object after conversion to type float.
     */
    @Override
    public float floatValue() {
        return value;
    }

    /**
     * Gets this instance's current value, then adds {@code operand}. This method is not thread-safe.
     *
     * @param operand The quantity to add, not null.
     * @throws NullPointerException Thrown if {@code operand} is null.
     * @return The value associated with this instance immediately before the operand was added.
     * @since 3.5
     */
    public short getAndAdd(final Number operand) {
        final short last = value;
        this.value += operand.shortValue();
        return last;
    }

    /**
     * Gets this instance's current value, then adds {@code operand}. This method is not thread-safe.
     *
     * @param operand The quantity to add, not null.
     * @return The value associated with this instance immediately before the operand was added.
     * @since 3.5
     */
    public short getAndAdd(final short operand) {
        final short last = value;
        this.value += operand;
        return last;
    }

    /**
     * Gets this instance's current value, then decrements it by 1. This method is not thread-safe.
     *
     * @return The value associated with the instance before it was decremented.
     * @since 3.5
     */
    public short getAndDecrement() {
        final short last = value;
        value--;
        return last;
    }

    /**
     * Gets this instance's current value, then increments it by 1. This method is not thread-safe.
     *
     * @return The value associated with the instance before it was incremented.
     * @since 3.5
     */
    public short getAndIncrement() {
        final short last = value;
        value++;
        return last;
    }

    /**
     * Gets the value as a Short instance.
     *
     * @return The value as a Short, never null.
     * @deprecated Use {@link #get()}.
     */
    @Deprecated
    @Override
    public Short getValue() {
        return Short.valueOf(this.value);
    }

    /**
     * Returns a suitable hash code for this mutable.
     *
     * @return A suitable hash code.
     */
    @Override
    public int hashCode() {
        return value;
    }

    /**
     * Increments the value.
     *
     * @since 2.2
     */
    public void increment() {
        value++;
    }

    /**
     * Increments this instance's value by 1; this method returns the value associated with the instance
     * immediately after the increment operation. This method is not thread safe.
     *
     * @return The value associated with the instance after it is incremented.
     * @since 3.5
     */
    public short incrementAndGet() {
        value++;
        return value;
    }

    /**
     * Returns the value of this MutableShort as an int.
     *
     * @return The numeric value represented by this object after conversion to type int.
     */
    @Override
    public int intValue() {
        return value;
    }

    /**
     * Returns the value of this MutableShort as a long.
     *
     * @return The numeric value represented by this object after conversion to type long.
     */
    @Override
    public long longValue() {
        return value;
    }

    /**
     * Sets the value from any Number instance.
     *
     * @param value  The value to set, not null.
     * @throws NullPointerException Thrown if the object is null.
     */
    @Override
    public void setValue(final Number value) {
        this.value = value.shortValue();
    }

    /**
     * Sets the value.
     *
     * @param value  The value to set
     */
    public void setValue(final short value) {
        this.value = value;
    }

    // byteValue relies on Number implementation
    /**
     * Returns the value of this MutableShort as a short.
     *
     * @return The numeric value represented by this object after conversion to type short.
     */
    @Override
    public short shortValue() {
        return value;
    }

    /**
     * Subtracts a value from the value of this instance.
     *
     * @param operand  The value to subtract, not null.
     * @throws NullPointerException Thrown if the object is null.
     * @since 2.2
     */
    public void subtract(final Number operand) {
        this.value -= operand.shortValue();
    }

    /**
     * Subtracts a value from the value of this instance.
     *
     * @param operand  The value to subtract, not null.
     * @since 2.2
     */
    public void subtract(final short operand) {
        this.value -= operand;
    }

    /**
     * Gets this mutable as an instance of Short.
     *
     * @return A Short instance containing the value from this mutable, never null.
     */
    public Short toShort() {
        return Short.valueOf(shortValue());
    }

    /**
     * Returns the String value of this mutable.
     *
     * @return The mutable value as a string.
     */
    @Override
    public String toString() {
        return String.valueOf(value);
    }

}
