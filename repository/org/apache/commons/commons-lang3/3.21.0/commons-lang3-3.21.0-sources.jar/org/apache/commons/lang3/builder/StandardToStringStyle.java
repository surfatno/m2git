/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.builder;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * Works with {@link ToStringBuilder} to create a {@code toString}.
 *
 * <p>
 * This class is intended to be used as a singleton.
 * There is no need to instantiate a new style each time.
 * Simply instantiate the class once, customize the values as required, and
 * store the result in a public static final variable for the rest of the
 * program to access.
 * </p>
 *
 * @since 1.0
 */
public class StandardToStringStyle extends ToStringStyle {

    /**
     * Required for serialization support.
     *
     * @see java.io.Serializable
     */
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new instance.
     */
    public StandardToStringStyle() {
    }

    /**
     * Gets the array end text.
     *
     * @return The current array end text
     */
    @Override
    public String getArrayEnd() {
        return super.getArrayEnd();
    }

    /**
     * Gets the array separator text.
     *
     * @return The current array separator text
     */
    @Override
    public String getArraySeparator() {
        return super.getArraySeparator();
    }

    /**
     * Gets the array start text.
     *
     * @return The current array start text
     */
    @Override
    public String getArrayStart() {
        return super.getArrayStart();
    }

    /**
     * Gets the content end text.
     *
     * @return The current content end text
     */
    @Override
    public String getContentEnd() {
        return super.getContentEnd();
    }

    /**
     * Gets the content start text.
     *
     * @return The current content start text
     */
    @Override
    public String getContentStart() {
        return super.getContentStart();
    }

    /**
     * Gets the field name value separator text.
     *
     * @return The current field name value separator text
     */
    @Override
    public String getFieldNameValueSeparator() {
        return super.getFieldNameValueSeparator();
    }

    /**
     * Gets the field separator text.
     *
     * @return The current field separator text
     */
    @Override
    public String getFieldSeparator() {
        return super.getFieldSeparator();
    }

    /**
     * Gets the text to output when {@code null} found.
     *
     * @return The current text to output when {@code null} found
     */
    @Override
    public String getNullText() {
        return super.getNullText();
    }

    /**
     * Gets the end text to output when a {@link Collection},
     * {@link Map} or {@link Array} size is output.
     *
     * <p>
     * This is output after the size value.
     * </p>
     *
     * @return The current end of size text
     */
    @Override
    public String getSizeEndText() {
        return super.getSizeEndText();
    }

    /**
     * Gets the text to output when a {@link Collection},
     * {@link Map} or {@link Array} size is output.
     *
     * <p>
     * This is output before the size value.
     * </p>
     *
     * @return The current start of size text
     */
    @Override
    public String getSizeStartText() {
        return super.getSizeStartText();
    }

    /**
     * Gets the end text to output when an {@link Object} is
     * output in summary mode.
     *
     * <p>
     * This is output after the size value.
     * </p>
     *
     * @return The current end of summary text
     */
    @Override
    public String getSummaryObjectEndText() {
        return super.getSummaryObjectEndText();
    }

    /**
     * Gets the start text to output when an {@link Object} is
     * output in summary mode.
     *
     * <p>
     * This is output before the size value.
     * </p>
     *
     * @return The current start of summary text
     */
    @Override
    public String getSummaryObjectStartText() {
        return super.getSummaryObjectStartText();
    }

    /**
     * Tests whether to output array content detail.
     *
     * @return The current array content detail setting
     */
    @Override
    public boolean isArrayContentDetail() {
        return super.isArrayContentDetail();
    }

    /**
     * Tests whether full detail is used when the caller does not specify a detail level.
     *
     * @return The current defaultFullDetail flag
     */
    @Override
    public boolean isDefaultFullDetail() {
        return super.isDefaultFullDetail();
    }

    /**
     * Tests whether the field separator should be added at the end of each buffer.
     *
     * @return fieldSeparatorAtEnd flag
     * @since 2.0
     */
    @Override
    public boolean isFieldSeparatorAtEnd() {
        return super.isFieldSeparatorAtEnd();
    }

    /**
     * Tests whether the field separator should be added at the start of each buffer.
     *
     * @return The fieldSeparatorAtStart flag
     * @since 2.0
     */
    @Override
    public boolean isFieldSeparatorAtStart() {
        return super.isFieldSeparatorAtStart();
    }

    /**
     * Tests whether to use the class name.
     *
     * @return The current useClassName flag
     */
    @Override
    public boolean isUseClassName() {
        return super.isUseClassName();
    }

    /**
     * Tests whether to use the field names passed in.
     *
     * @return The current useFieldNames flag
     */
    @Override
    public boolean isUseFieldNames() {
        return super.isUseFieldNames();
    }

    /**
     * Tests whether to use the identity hash code.
     *
     * @return The current useIdentityHashCode flag
     */
    @Override
    public boolean isUseIdentityHashCode() {
        return super.isUseIdentityHashCode();
    }

    /**
     * Tests whether short class names should be output.
     *
     * @return The current useShortClassName flag
     * @since 2.0
     */
    @Override
    public boolean isUseShortClassName() {
        return super.isUseShortClassName();
    }

    /**
     * Sets whether to output array content detail.
     *
     * @param arrayContentDetail  The new arrayContentDetail flag
     */
    @Override
    public void setArrayContentDetail(final boolean arrayContentDetail) {
        super.setArrayContentDetail(arrayContentDetail);
    }

    /**
     * Sets the array end text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param arrayEnd  The new array end text
     */
    @Override
    public void setArrayEnd(final String arrayEnd) {
        super.setArrayEnd(arrayEnd);
    }

    /**
     * Sets the array separator text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param arraySeparator  The new array separator text
     */
    @Override
    public void setArraySeparator(final String arraySeparator) {
        super.setArraySeparator(arraySeparator);
    }

    /**
     * Sets the array start text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param arrayStart  The new array start text
     */
    @Override
    public void setArrayStart(final String arrayStart) {
        super.setArrayStart(arrayStart);
    }

    /**
     * Sets the content end text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param contentEnd  The new content end text
     */
    @Override
    public void setContentEnd(final String contentEnd) {
        super.setContentEnd(contentEnd);
    }

    /**
     * Sets the content start text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param contentStart  The new content start text
     */
    @Override
    public void setContentStart(final String contentStart) {
        super.setContentStart(contentStart);
    }

    /**
     * Sets whether to use full detail when the caller doesn't
     * specify.
     *
     * @param defaultFullDetail  The new defaultFullDetail flag
     */
    @Override
    public void setDefaultFullDetail(final boolean defaultFullDetail) {
        super.setDefaultFullDetail(defaultFullDetail);
    }

    /**
     * Sets the field name value separator text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param fieldNameValueSeparator  The new field name value separator text
     */
    @Override
    public void setFieldNameValueSeparator(final String fieldNameValueSeparator) {
        super.setFieldNameValueSeparator(fieldNameValueSeparator);
    }

    /**
     * Sets the field separator text.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param fieldSeparator  The new field separator text
     */
    @Override
    public void setFieldSeparator(final String fieldSeparator) {
        super.setFieldSeparator(fieldSeparator);
    }

    /**
     * Sets whether the field separator should be added at the end
     * of each buffer.
     *
     * @param fieldSeparatorAtEnd  The fieldSeparatorAtEnd flag
     * @since 2.0
     */
    @Override
    public void setFieldSeparatorAtEnd(final boolean fieldSeparatorAtEnd) {
        super.setFieldSeparatorAtEnd(fieldSeparatorAtEnd);
    }

    /**
     * Sets whether the field separator should be added at the start
     * of each buffer.
     *
     * @param fieldSeparatorAtStart  The fieldSeparatorAtStart flag
     * @since 2.0
     */
    @Override
    public void setFieldSeparatorAtStart(final boolean fieldSeparatorAtStart) {
        super.setFieldSeparatorAtStart(fieldSeparatorAtStart);
    }

    /**
     * Sets the text to output when {@code null} found.
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param nullText  The new text to output when {@code null} found
     */
    @Override
    public void setNullText(final String nullText) {
        super.setNullText(nullText);
    }

    /**
     * Sets the end text to output when a {@link Collection},
     * {@link Map} or {@link Array} size is output.
     *
     * <p>
     * This is output after the size value.
     * </p>
     *
     * <p>
     * {@code null} is accepted, but will be converted
     * to an empty String.
     * </p>
     *
     * @param sizeEndText  The new end of size text
     */
    @Override
    public void setSizeEndText(final String sizeEndText) {
        super.setSizeEndText(sizeEndText);
    }

    /**
     * Sets the start text to output when a {@link Collection},
     * {@link Map} or {@link Array} size is output.
     *
     * <p>
     * This is output before the size value.
     * </p>
     *
     * <p>
     * {@code null} is accepted, but will be converted to
     * an empty String.
     * </p>
     *
     * @param sizeStartText  The new start of size text
     */
    @Override
    public void setSizeStartText(final String sizeStartText) {
        super.setSizeStartText(sizeStartText);
    }

    /**
     * Sets the end text to output when an {@link Object} is
     * output in summary mode.
     *
     * <p>
     * This is output after the size value.
     * </p>
     *
     * <p>
     * {@code null} is accepted, but will be converted to
     * an empty String.
     * </p>
     *
     * @param summaryObjectEndText  The new end of summary text
     */
    @Override
    public void setSummaryObjectEndText(final String summaryObjectEndText) {
        super.setSummaryObjectEndText(summaryObjectEndText);
    }

    /**
     * Sets the start text to output when an {@link Object} is
     * output in summary mode.
     *
     * <p>
     * This is output before the size value.
     * </p>
     *
     * <p>
     * {@code null} is accepted, but will be converted to
     * an empty String.
     * </p>
     *
     * @param summaryObjectStartText  The new start of summary text
     */
    @Override
    public void setSummaryObjectStartText(final String summaryObjectStartText) {
        super.setSummaryObjectStartText(summaryObjectStartText);
    }

    /**
     * Sets whether to use the class name.
     *
     * @param useClassName  The new useClassName flag
     */
    @Override
    public void setUseClassName(final boolean useClassName) {
        super.setUseClassName(useClassName);
    }

    /**
     * Sets whether to use the field names passed in.
     *
     * @param useFieldNames  The new useFieldNames flag
     */
    @Override
    public void setUseFieldNames(final boolean useFieldNames) {
        super.setUseFieldNames(useFieldNames);
    }

    /**
     * Sets whether to use the identity hash code.
     *
     * @param useIdentityHashCode  The new useIdentityHashCode flag
     */
    @Override
    public void setUseIdentityHashCode(final boolean useIdentityHashCode) {
        super.setUseIdentityHashCode(useIdentityHashCode);
    }

    /**
     * Sets whether to output short or long class names.
     *
     * @param useShortClassName  The new useShortClassName flag
     * @since 2.0
     */
    @Override
    public void setUseShortClassName(final boolean useShortClassName) {
        super.setUseShortClassName(useShortClassName);
    }

}
