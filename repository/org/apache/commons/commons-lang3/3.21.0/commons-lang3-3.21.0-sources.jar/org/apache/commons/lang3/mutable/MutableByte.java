/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.mutable;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * A mutable {@code byte} wrapper.
 * <p>
 * This class was created before the introduction of the {@link java.util.concurrent.atomic} package and the {@link AtomicInteger} class.
 * </p>
 * <p>
 * Note that as MutableByte does not extend Byte, it is not treated by String.format as a Byte parameter.
 * </p>
 *
 * @see Byte
 * @see AtomicInteger
 * @since 2.1
 */
public class MutableByte extends Number implements Comparable<MutableByte>, Mutable<Number> {

    /**
     * Required for serialization support.
     *
     * @see java.io.Serializable
     */
    private static final long serialVersionUID = -1585823265L;

    /** The mutable value. */
    private byte value;

    /**
     * Constructs a new MutableByte with the default value of zero.
     */
    public MutableByte() {
    }

    /**
     * Constructs a new MutableByte with the specified value.
     *
     * @param value  The initial value to store
     */
    public MutableByte(final byte value) {
        this.value = value;
    }

    /**
     * Constructs a new MutableByte with the specified value.
     *
     * @param value  The initial value to store, not null.
     * @throws NullPointerException Thrown if the object is null.
     */
    public MutableByte(final Number value) {
        this.value = value.byteValue();
    }

    /**
     * Constructs a new MutableByte parsing the given string.
     *
     * @param value  The string to parse, not null.
     * @throws NumberFormatException Thrown if the string cannot be parsed into a byte, see {@link Byte#parseByte(String)}.
     * @since 2.5
     */
    public MutableByte(final String value) {
        this.value = Byte.parseByte(value);
    }

    /**
     * Adds a value to the value of this instance.
     *
     * @param operand  The value to add, not null.
     * @since 2.2
     */
    public void add(final byte operand) {
        this.value += operand;
    }

    /**
     * Adds a value to the value of this instance.
     *
     * @param operand  The value to add, not null.
     * @throws NullPointerException Thrown if the object is null.
     * @since 2.2
     */
    public void add(final Number operand) {
        this.value += operand.byteValue();
    }

    /**
     * Increments this instance's value by {@code operand}; this method returns the value associated with the instance
     * immediately after the addition operation. This method is not thread safe.
     *
     * @param operand The quantity to add, not null.
     * @return The value associated with this instance after adding the operand.
     * @since 3.5
     */
    public byte addAndGet(final byte operand) {
        this.value += operand;
        return value;
    }

    /**
     * Increments this instance's value by {@code operand}; this method returns the value associated with the instance
     * immediately after the addition operation. This method is not thread safe.
     *
     * @param operand The quantity to add, not null.
     * @throws NullPointerException Thrown if {@code operand} is null.
     * @return The value associated with this instance after adding the operand.
     * @since 3.5
     */
    public byte addAndGet(final Number operand) {
        this.value += operand.byteValue();
        return value;
    }

    // shortValue relies on Number implementation
    /**
     * Returns the value of this MutableByte as a byte.
     *
     * @return The numeric value represented by this object after conversion to type byte.
     */
    @Override
    public byte byteValue() {
        return value;
    }

    /**
     * Compares this mutable to another in ascending order.
     *
     * @param other  The other mutable to compare to, not null.
     * @return negative if this is less, zero if equal, positive if greater.
     */
    @Override
    public int compareTo(final MutableByte other) {
        return Byte.compare(this.value, other.value);
    }

    /**
     * Decrements the value.
     *
     * @since 2.2
     */
    public void decrement() {
        value--;
    }

    /**
     * Decrements this instance's value by 1; this method returns the value associated with the instance
     * immediately after the decrement operation. This method is not thread safe.
     *
     * @return The value associated with the instance after it is decremented.
     * @since 3.5
     */
    public byte decrementAndGet() {
        value--;
        return value;
    }

    /**
     * Returns the value of this MutableByte as a double.
     *
     * @return The numeric value represented by this object after conversion to type double.
     */
    @Override
    public double doubleValue() {
        return value;
    }

    /**
     * Compares this object to the specified object. The result is {@code true} if and only if the argument is
     * not {@code null} and is a {@link MutableByte} object that contains the same {@code byte} value
     * as this object.
     *
     * @param obj  The object to compare with, null returns false.
     * @return {@code true} if the objects are the same; {@code false} otherwise.
     */
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof MutableByte) {
            return value == ((MutableByte) obj).byteValue();
        }
        return false;
    }

    /**
     * Returns the value of this MutableByte as a float.
     *
     * @return The numeric value represented by this object after conversion to type float.
     */
    @Override
    public float floatValue() {
        return value;
    }

    /**
     * Gets this instance's current value, then adds {@code operand}. This method is not thread-safe.
     *
     * @param operand The quantity to add, not null.
     * @return The value associated with this instance immediately before the operand was added.
     * @since 3.5
     */
    public byte getAndAdd(final byte operand) {
        final byte last = value;
        this.value += operand;
        return last;
    }

    /**
     * Gets this instance's current value, then adds {@code operand}. This method is not thread-safe.
     *
     * @param operand The quantity to add, not null.
     * @throws NullPointerException Thrown if {@code operand} is null.
     * @return The value associated with this instance immediately before the operand was added.
     * @since 3.5
     */
    public byte getAndAdd(final Number operand) {
        final byte last = value;
        this.value += operand.byteValue();
        return last;
    }

    /**
     * Gets this instance's current value, then decrements it by 1. This method is not thread-safe.
     *
     * @return The value associated with the instance before it was decremented.
     * @since 3.5
     */
    public byte getAndDecrement() {
        final byte last = value;
        value--;
        return last;
    }

    /**
     * Gets this instance's current value, then increments it by 1. This method is not thread-safe.
     *
     * @return The value associated with the instance before it was incremented.
     * @since 3.5
     */
    public byte getAndIncrement() {
        final byte last = value;
        value++;
        return last;
    }

    /**
     * Gets the value as a Byte instance.
     *
     * @return The value as a Byte, never null.
     * @deprecated Use {@link #get()}.
     */
    @Deprecated
    @Override
    public Byte getValue() {
        return Byte.valueOf(this.value);
    }

    /**
     * Returns a suitable hash code for this mutable.
     *
     * @return A suitable hash code.
     */
    @Override
    public int hashCode() {
        return value;
    }

    /**
     * Increments the value.
     *
     * @since 2.2
     */
    public void increment() {
        value++;
    }

    /**
     * Increments this instance's value by 1; this method returns the value associated with the instance
     * immediately after the increment operation. This method is not thread safe.
     *
     * @return The value associated with the instance after it is incremented.
     * @since 3.5
     */
    public byte incrementAndGet() {
        value++;
        return value;
    }

    /**
     * Returns the value of this MutableByte as an int.
     *
     * @return The numeric value represented by this object after conversion to type int.
     */
    @Override
    public int intValue() {
        return value;
    }

    /**
     * Returns the value of this MutableByte as a long.
     *
     * @return The numeric value represented by this object after conversion to type long.
     */
    @Override
    public long longValue() {
        return value;
    }

    /**
     * Sets the value.
     *
     * @param value  The value to set.
     */
    public void setValue(final byte value) {
        this.value = value;
    }

    /**
     * Sets the value from any Number instance.
     *
     * @param value  The value to set, not null.
     * @throws NullPointerException Thrown if the object is null.
     */
    @Override
    public void setValue(final Number value) {
        this.value = value.byteValue();
    }

    /**
     * Subtracts a value from the value of this instance.
     *
     * @param operand  The value to subtract, not null.
     * @since 2.2
     */
    public void subtract(final byte operand) {
        this.value -= operand;
    }

    /**
     * Subtracts a value from the value of this instance.
     *
     * @param operand  The value to subtract, not null.
     * @throws NullPointerException Thrown if the object is null.
     * @since 2.2
     */
    public void subtract(final Number operand) {
        this.value -= operand.byteValue();
    }

    /**
     * Gets this mutable as an instance of Byte.
     *
     * @return A Byte instance containing the value from this mutable.
     */
    public Byte toByte() {
        return Byte.valueOf(byteValue());
    }

    /**
     * Returns the String value of this mutable.
     *
     * @return The mutable value as a string.
     */
    @Override
    public String toString() {
        return String.valueOf(value);
    }

}
