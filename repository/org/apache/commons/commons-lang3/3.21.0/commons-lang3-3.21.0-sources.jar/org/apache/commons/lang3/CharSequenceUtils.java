/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3;

/**
 * Operations on {@link CharSequence} that are
 * {@code null} safe.
 *
 * @see CharSequence
 * @since 3.0
 */
public class CharSequenceUtils {

    private static final int NOT_FOUND = -1;

    /**
     * Whether the running JDK folds a supplementary code point split across a surrogate pair when comparing case insensitively in
     * {@link String#regionMatches(boolean, int, String, int, int)}. JDKs up to and including Java 11 compare surrogate by surrogate and never match such a
     * pair; later JDKs fold the whole code point. Probing what {@link String} actually does (rather than gating on a version constant) keeps every
     * {@link CharSequence} type in step with {@link String} on whatever JDK is running. DESERET CAPITAL LETTER LONG I (U+10400) folds to its small form
     * (U+10428).
     */
    private static final boolean STRING_FOLDS_SUPPLEMENTARY_CASE = new String(Character.toChars(0x10400)).regionMatches(true, 0,
            new String(Character.toChars(0x10428)), 0, 2);

    static final int TO_STRING_LIMIT = 16;

    private static boolean checkLaterThan1(final CharSequence cs, final CharSequence searchChar, final int len2, final int start1) {
        for (int i = 1, j = len2 - 1; i <= j; i++, j--) {
            if (cs.charAt(start1 + i) != searchChar.charAt(i) || cs.charAt(start1 + j) != searchChar.charAt(j)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Tests whether two code points are equal ignoring case, matching the folding used by {@link String#regionMatches(boolean, int, String, int, int)}.
     *
     * @param cp1 The first code point.
     * @param cp2 The second code point.
     * @return whether the code points are equal ignoring case.
     */
    private static boolean equalsIgnoreCase(final int cp1, final int cp2) {
        final int u1 = Character.toUpperCase(cp1);
        final int u2 = Character.toUpperCase(cp2);
        return u1 == u2 || Character.toLowerCase(u1) == Character.toLowerCase(u2);
    }

    /**
     * Used by the indexOf(CharSequence methods) as a green implementation of indexOf.
     * <p>
     * {@link CharSequence} types without a dedicated branch are scanned in place rather than materialized with {@code toString()}: for builder
     * types (for example {@code org.apache.commons.lang3.text.StrBuilder}), {@code toString()} copies the whole buffer, and callers that invoke
     * this method once per occurrence (such as {@code deleteAll}/{@code replaceAll}) would multiply that copy into allocation-quadratic churn.
     * </p>
     *
     * @param cs         The {@link CharSequence} to be processed.
     * @param searchChar The {@link CharSequence} to be searched for.
     * @param start      The start index.
     * @return The index where the search sequence was found, or {@code -1} if there is no such occurrence.
     */
    static int indexOf(final CharSequence cs, final CharSequence searchChar, final int start) {
        if (cs == null || searchChar == null) {
            return StringUtils.INDEX_NOT_FOUND;
        }
        if (cs instanceof String) {
            return ((String) cs).indexOf(searchChar.toString(), start);
        }
        if (cs instanceof StringBuilder) {
            return ((StringBuilder) cs).indexOf(searchChar.toString(), start);
        }
        if (cs instanceof StringBuffer) {
            return ((StringBuffer) cs).indexOf(searchChar.toString(), start);
        }
        // Direct scan without copying cs; matches the semantics of String.indexOf(String, int).
        final int len1 = cs.length();
        final int len2 = searchChar.length();
        final int from = Math.max(start, 0);
        if (len2 == 0) {
            return Math.min(from, len1);
        }
        if (len2 > len1 - from) {
            return StringUtils.INDEX_NOT_FOUND;
        }
        final char char0 = searchChar.charAt(0);
        final int max = len1 - len2;
        for (int i = from; i <= max; i++) {
            if (cs.charAt(i) == char0 && checkLaterThan1(cs, searchChar, len2, i)) {
                return i;
            }
        }
        return StringUtils.INDEX_NOT_FOUND;
    }

    /**
     * Returns the index within {@code cs} of the first occurrence of the specified character, starting the search at the specified index.
     * <p>
     * If a character with value {@code searchChar} occurs in the character sequence represented by the {@code cs} object at an index no smaller than
     * {@code start}, then the index of the first such occurrence is returned. For values of {@code searchChar} in the range from 0 to 0xFFFF (inclusive), this
     * is the smallest value <em>k</em> such that:
     * </p>
     *
     * <pre>
     * (this.charAt(<em>k</em>) == searchChar) &amp;&amp; (<em>k</em> &gt;= start)
     * </pre>
     * <p>
     * is true. For other values of {@code searchChar}, it is the smallest value <em>k</em> such that:
     * </p>
     *
     * <pre>
     * (this.codePointAt(<em>k</em>) == searchChar) &amp;&amp; (<em>k</em> &gt;= start)
     * </pre>
     * <p>
     * is true. In either case, if no such character occurs inm {@code cs} at or after position {@code start}, then {@code -1} is returned.
     * </p>
     * <p>
     * There is no restriction on the value of {@code start}. If it is negative, it has the same effect as if it were zero: the entire {@link CharSequence} may
     * be searched. If it is greater than the length of {@code cs}, it has the same effect as if it were equal to the length of {@code cs}: {@code -1} is
     * returned.
     * </p>
     * <p>
     * All indices are specified in {@code char} values (Unicode code units).
     * </p>
     *
     * @param cs         The {@link CharSequence} to be processed, not null.
     * @param searchChar The char to be searched for.
     * @param start      The start index, negative starts at the string start.
     * @return The index where the search char was found, -1 if not found.
     * @since 3.6 updated to behave more like {@link String}.
     */
    static int indexOf(final CharSequence cs, final int searchChar, int start) {
        if (cs instanceof String) {
            return ((String) cs).indexOf(searchChar, start);
        }
        final int sz = cs.length();
        if (start < 0) {
            start = 0;
        }
        if (searchChar < Character.MIN_SUPPLEMENTARY_CODE_POINT) {
            for (int i = start; i < sz; i++) {
                if (cs.charAt(i) == searchChar) {
                    return i;
                }
            }
            return NOT_FOUND;
        }
        //supplementary characters (LANG1300)
        if (searchChar <= Character.MAX_CODE_POINT) {
            final char[] chars = Character.toChars(searchChar);
            for (int i = start; i < sz - 1; i++) {
                final char high = cs.charAt(i);
                final char low = cs.charAt(i + 1);
                if (high == chars[0] && low == chars[1]) {
                    return i;
                }
            }
        }
        return NOT_FOUND;
    }

    /**
     * Used by the lastIndexOf(CharSequence methods) as a green implementation of lastIndexOf
     *
     * @param cs The {@link CharSequence} to be processed.
     * @param searchChar The {@link CharSequence} to find.
     * @param start The start index.
     * @return The index where the search sequence was found.
     */
    static int lastIndexOf(final CharSequence cs, final CharSequence searchChar, int start) {
        if (searchChar == null || cs == null) {
            return NOT_FOUND;
        }
        if (searchChar instanceof String) {
            if (cs instanceof String) {
                return ((String) cs).lastIndexOf((String) searchChar, start);
            }
            if (cs instanceof StringBuilder) {
                return ((StringBuilder) cs).lastIndexOf((String) searchChar, start);
            }
            if (cs instanceof StringBuffer) {
                return ((StringBuffer) cs).lastIndexOf((String) searchChar, start);
            }
        }

        final int len1 = cs.length();
        final int len2 = searchChar.length();

        if (start > len1) {
            start = len1;
        }

        if (start < 0 || len2 > len1) {
            return NOT_FOUND;
        }

        if (len2 == 0) {
            return start;
        }

        if (len2 <= TO_STRING_LIMIT) {
            if (cs instanceof String) {
                return ((String) cs).lastIndexOf(searchChar.toString(), start);
            }
            if (cs instanceof StringBuilder) {
                return ((StringBuilder) cs).lastIndexOf(searchChar.toString(), start);
            }
            if (cs instanceof StringBuffer) {
                return ((StringBuffer) cs).lastIndexOf(searchChar.toString(), start);
            }
        }

        if (start + len2 > len1) {
            start = len1 - len2;
        }

        final char char0 = searchChar.charAt(0);

        int i = start;
        while (true) {
            while (cs.charAt(i) != char0) {
                i--;
                if (i < 0) {
                    return NOT_FOUND;
                }
            }
            if (checkLaterThan1(cs, searchChar, len2, i)) {
                return i;
            }
            i--;
            if (i < 0) {
                return NOT_FOUND;
            }
        }
    }

    /**
     * Returns the index within {@code cs} of the last occurrence of the specified character, searching backward starting at the specified index. For values of
     * {@code searchChar} in the range from 0 to 0xFFFF (inclusive), the index returned is the largest value <em>k</em> such that:
     *
     * <pre>
     * (this.charAt(<em>k</em>) == searchChar) &amp;&amp; (<em>k</em> &lt;= start)
     * </pre>
     * <p>
     * is true. For other values of {@code searchChar}, it is the largest value <em>k</em> such that:
     * <p>
     *
     * <pre>
     * (this.codePointAt(<em>k</em>) == searchChar) &amp;&amp; (<em>k</em> &lt;= start)
     * </pre>
     * <p>
     * is true. In either case, if no such character occurs in {@code cs} at or before position {@code start}, then {@code -1} is returned.
     * </p>
     * <p>
     * All indices are specified in {@code char} values (Unicode code units).
     * </p>
     *
     * @param cs         The {@link CharSequence} to be processed.
     * @param searchChar The char to be searched for.
     * @param start      The start index, negative returns -1, beyond length starts at end.
     * @return The index where the search char was found, -1 if not found.
     * @since 3.6 updated to behave more like {@link String}.
     */
    static int lastIndexOf(final CharSequence cs, final int searchChar, int start) {
        if (cs instanceof String) {
            return ((String) cs).lastIndexOf(searchChar, start);
        }
        final int sz = cs.length();
        if (start < 0) {
            return NOT_FOUND;
        }
        if (start >= sz) {
            start = sz - 1;
        }
        if (searchChar < Character.MIN_SUPPLEMENTARY_CODE_POINT) {
            for (int i = start; i >= 0; --i) {
                if (cs.charAt(i) == searchChar) {
                    return i;
                }
            }
            return NOT_FOUND;
        }
        //supplementary characters (LANG1300)
        //NOTE - we must do a forward traversal for this to avoid duplicating code points
        if (searchChar <= Character.MAX_CODE_POINT) {
            final char[] chars = Character.toChars(searchChar);
            // A supplementary code point spans two chars, so its high surrogate can start no later
            // than sz - 2; clamp the search origin instead of bailing out when start is the last index.
            for (int i = Math.min(start, sz - 2); i >= 0; i--) {
                final char high = cs.charAt(i);
                final char low = cs.charAt(i + 1);
                if (chars[0] == high && chars[1] == low) {
                    return i;
                }
            }
        }
        return NOT_FOUND;
    }

    /**
     * Tests if two string regions are equal.
     *
     * @param cs         The {@link CharSequence} to be processed.
     * @param ignoreCase whether or not to be case-insensitive.
     * @param thisStart  The index to start on the {@code cs} CharSequence.
     * @param substring  The {@link CharSequence} to be looked for.
     * @param start      The index to start on the {@code substring} CharSequence.
     * @param length     character length of the region.
     * @return whether the region matched.
     * @see String#regionMatches(boolean, int, String, int, int)
     */
    static boolean regionMatches(final CharSequence cs, final boolean ignoreCase, final int thisStart, final CharSequence substring, final int start,
            final int length) {
        // Green implementation of regionMatches.
        if (cs instanceof String && substring instanceof String) {
            return ((String) cs).regionMatches(ignoreCase, thisStart, (String) substring, start, length);
        }
        // Extract these first so we detect NPEs the same as the java.lang.String version
        final int srcLen = cs.length() - thisStart;
        final int otherLen = substring.length() - start;
        // Check for invalid parameters
        if (thisStart < 0 || start < 0 || length < 0) {
            return false;
        }
        // Check that the regions are long enough
        if (srcLen < length || otherLen < length) {
            return false;
        }
        final int end1 = thisStart + length;
        final int end2 = start + length;
        int index1 = thisStart;
        int index2 = start;
        while (index1 < end1 && index2 < end2) {
            final char c1 = cs.charAt(index1);
            final char c2 = substring.charAt(index2);
            if (c1 == c2) {
                index1++;
                index2++;
                continue;
            }
            if (!ignoreCase) {
                return false;
            }
            // The same case-insensitive check as String#regionMatches(boolean, int, String, int, int).
            if (!equalsIgnoreCase(c1, c2)) {
                // Only fold a supplementary code point split across a surrogate pair where String itself does, so
                // every CharSequence type gives the same result that String does on the running JDK (see field).
                if (!STRING_FOLDS_SUPPLEMENTARY_CASE) {
                    return false;
                }
                int cp1 = c1;
                if (Character.isHighSurrogate(c1)) {
                    if (index1 + 1 < end1 && Character.isLowSurrogate(cs.charAt(index1 + 1))) {
                        cp1 = Character.toCodePoint(c1, cs.charAt(index1 + 1));
                        index1++;
                    }
                } else if (Character.isLowSurrogate(c1) && index1 > thisStart && Character.isHighSurrogate(cs.charAt(index1 - 1))) {
                    cp1 = Character.toCodePoint(cs.charAt(index1 - 1), c1);
                }
                int cp2 = c2;
                if (Character.isHighSurrogate(c2)) {
                    if (index2 + 1 < end2 && Character.isLowSurrogate(substring.charAt(index2 + 1))) {
                        cp2 = Character.toCodePoint(c2, substring.charAt(index2 + 1));
                        index2++;
                    }
                } else if (Character.isLowSurrogate(c2) && index2 > start && Character.isHighSurrogate(substring.charAt(index2 - 1))) {
                    cp2 = Character.toCodePoint(substring.charAt(index2 - 1), c2);
                }
                if (!equalsIgnoreCase(cp1, cp2)) {
                    return false;
                }
            }
            index1++;
            index2++;
        }
        return true;
    }

    /**
     * Returns a new {@link CharSequence} that is a subsequence of this
     * sequence starting with the {@code char} value at the specified index.
     *
     * <p>
     * This provides the {@link CharSequence} equivalent to {@link String#substring(int)}.
     * The length (in {@code char}) of the returned sequence is {@code length() - start},
     * so if {@code start == end} then an empty sequence is returned.
     * </p>
     *
     * @param cs  The specified subsequence, null returns null.
     * @param start  The start index, inclusive, valid.
     * @return A new subsequence, may be null.
     * @throws IndexOutOfBoundsException Thrown if {@code start} is negative or if
     *  {@code start} is greater than {@code length()}.
     */
    public static CharSequence subSequence(final CharSequence cs, final int start) {
        return cs == null ? null : cs.subSequence(start, cs.length());
    }

    /**
     * Converts the given CharSequence to a char[].
     *
     * @param source The {@link CharSequence} to be processed.
     * @return The resulting char array, never null.
     * @since 3.11
     */
    public static char[] toCharArray(final CharSequence source) {
        // See CharSequenceUtilsBenchmark
        final int len = StringUtils.length(source);
        if (len == 0) {
            return ArrayUtils.EMPTY_CHAR_ARRAY;
        }
        if (source instanceof String) {
            return ((String) source).toCharArray();
        }
        if (source instanceof StringBuilder) {
            final char[] array = new char[len];
            ((StringBuilder) source).getChars(0, len, array, 0);
            return array;
        }
        if (source instanceof StringBuffer) {
            final char[] array = new char[len];
            ((StringBuffer) source).getChars(0, len, array, 0);
            return array;
        }
        final char[] array = new char[len];
        for (int i = 0; i < len; i++) {
            array[i] = source.charAt(i);
        }
        return array;
    }

    /**
     * {@link CharSequenceUtils} instances should NOT be constructed in
     * standard programming.
     *
     * <p>
     * This constructor is public to permit tools that require a JavaBean
     * instance to operate.
     * </p>
     *
     * @deprecated TODO Make private in 4.0.
     */
    @Deprecated
    public CharSequenceUtils() {
        // empty
    }
}
