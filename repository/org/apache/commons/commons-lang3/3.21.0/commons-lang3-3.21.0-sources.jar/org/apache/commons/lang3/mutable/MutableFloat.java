/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.lang3.mutable;

import java.util.concurrent.atomic.DoubleAccumulator;
import java.util.concurrent.atomic.DoubleAdder;

/**
 * A mutable {@code float} wrapper.
 * <p>
 * This class was created before the introduction of the {@link java.util.concurrent.atomic} package and the {@link DoubleAccumulator} class.
 * </p>
 * <p>
 * Note that as MutableFloat does not extend Float, it is not treated by String.format as a Float parameter.
 * </p>
 *
 * @see Float
 * @see DoubleAccumulator
 * @see DoubleAdder
 * @since 2.1
 */
public class MutableFloat extends Number implements Comparable<MutableFloat>, Mutable<Number> {

    /**
     * Required for serialization support.
     *
     * @see java.io.Serializable
     */
    private static final long serialVersionUID = 5787169186L;

    /** The mutable value. */
    private float value;

    /**
     * Constructs a new MutableFloat with the default value of zero.
     */
    public MutableFloat() {
    }

    /**
     * Constructs a new MutableFloat with the specified value.
     *
     * @param value  The initial value to store.
     */
    public MutableFloat(final float value) {
        this.value = value;
    }

    /**
     * Constructs a new MutableFloat with the specified value.
     *
     * @param value  The initial value to store, not null.
     * @throws NullPointerException Thrown if the object is null.
     */
    public MutableFloat(final Number value) {
        this.value = value.floatValue();
    }

    /**
     * Constructs a new MutableFloat parsing the given string.
     *
     * @param value  The string to parse, not null.
     * @throws NumberFormatException Thrown if the string cannot be parsed into a float, see {@link Float#parseFloat(String)}.
     * @since 2.5
     */
    public MutableFloat(final String value) {
        this.value = Float.parseFloat(value);
    }

    /**
     * Adds a value to the value of this instance.
     *
     * @param operand  The value to add, not null.
     * @since 2.2
     */
    public void add(final float operand) {
        this.value += operand;
    }

    /**
     * Adds a value to the value of this instance.
     *
     * @param operand  The value to add, not null.
     * @throws NullPointerException Thrown if the object is null.
     * @since 2.2
     */
    public void add(final Number operand) {
        this.value += operand.floatValue();
    }

    /**
     * Increments this instance's value by {@code operand}; this method returns the value associated with the instance
     * immediately after the addition operation. This method is not thread safe.
     *
     * @param operand The quantity to add, not null.
     * @return The value associated with this instance after adding the operand.
     * @since 3.5
     */
    public float addAndGet(final float operand) {
        this.value += operand;
        return value;
    }

    /**
     * Increments this instance's value by {@code operand}; this method returns the value associated with the instance
     * immediately after the addition operation. This method is not thread safe.
     *
     * @param operand The quantity to add, not null.
     * @throws NullPointerException Thrown if {@code operand} is null.
     * @return The value associated with this instance after adding the operand.
     * @since 3.5
     */
    public float addAndGet(final Number operand) {
        this.value += operand.floatValue();
        return value;
    }

    /**
     * Compares this mutable to another in ascending order.
     *
     * @param other  The other mutable to compare to, not null.
     * @return negative if this is less, zero if equal, positive if greater.
     */
    @Override
    public int compareTo(final MutableFloat other) {
        return Float.compare(this.value, other.value);
    }

    /**
     * Decrements the value.
     *
     * @since 2.2
     */
    public void decrement() {
        value--;
    }

    /**
     * Decrements this instance's value by 1; this method returns the value associated with the instance
     * immediately after the decrement operation. This method is not thread safe.
     *
     * @return The value associated with the instance after it is decremented.
     * @since 3.5
     */
    public float decrementAndGet() {
        value--;
        return value;
    }

    /**
     * Returns the value of this MutableFloat as a double.
     *
     * @return The numeric value represented by this object after conversion to type double.
     */
    @Override
    public double doubleValue() {
        return value;
    }

    /**
     * Compares this object against some other object. The result is {@code true} if and only if the argument is not {@code null} and is a {@link Float} object
     * that represents a {@code float} that has the identical bit pattern to the bit pattern of the {@code float} represented by this object. For this purpose,
     * two float values are considered to be the same if and only if the method {@link Float#floatToIntBits(float)}returns the same int value when applied to
     * each.
     * <p>
     * Note that in most cases, for two instances of class {@link Float},{@code f1} and {@code f2}, the value of {@code f1.equals(f2)} is {@code true} if and
     * only if:
     * </p>
     * <pre>
     * f1.floatValue() == f2.floatValue()
     * </pre>
     * <p>
     * also has the value {@code true}. However, there are two exceptions:
     * </p>
     * <ul>
     * <li>If {@code f1} and {@code f2} both represent {@code Float.NaN}, then the {@code equals} method returns {@code true}, even though
     * {@code Float.NaN == Float.NaN} has the value {@code false}.</li>
     * <li>If {@code f1} represents {@code +0.0f} while {@code f2} represents {@code -0.0f}, or vice versa, the {@code equal} test has the value {@code false},
     * even though {@code 0.0f == -0.0f} has the value {@code true}.</li>
     * </ul>
     * <p>
     * This definition allows hashtables to operate properly.
     * </p>
     *
     * @param obj The object to compare with, null returns false.
     * @return {@code true} if the objects are the same; {@code false} otherwise.
     * @see Float#floatToIntBits(float)
     */
    @Override
    public boolean equals(final Object obj) {
        return obj instanceof MutableFloat
            && Float.floatToIntBits(((MutableFloat) obj).value) == Float.floatToIntBits(value);
    }

    /**
     * Returns the value of this MutableFloat as a float.
     *
     * @return The numeric value represented by this object after conversion to type float.
     */
    @Override
    public float floatValue() {
        return value;
    }

    /**
     * Gets this instance's current value, then adds {@code operand}. This method is not thread-safe.
     *
     * @param operand The quantity to add, not null.
     * @return The value associated with this instance immediately before the operand was added.
     * @since 3.5
     */
    public float getAndAdd(final float operand) {
        final float last = value;
        this.value += operand;
        return last;
    }

    /**
     * Gets this instance's current value, then adds {@code operand}. This method is not thread-safe.
     *
     * @param operand The quantity to add, not null.
     * @throws NullPointerException Thrown if {@code operand} is null.
     * @return The value associated with this instance immediately before the operand was added.
     * @since 3.5
     */
    public float getAndAdd(final Number operand) {
        final float last = value;
        this.value += operand.floatValue();
        return last;
    }

    /**
     * Gets this instance's current value, then decrements it by 1. This method is not thread-safe.
     *
     * @return The value associated with the instance before it was decremented.
     * @since 3.5
     */
    public float getAndDecrement() {
        final float last = value;
        value--;
        return last;
    }

    /**
     * Gets this instance's current value, then increments it by 1. This method is not thread-safe.
     *
     * @return The value associated with the instance before it was incremented.
     * @since 3.5
     */
    public float getAndIncrement() {
        final float last = value;
        value++;
        return last;
    }

    /**
     * Gets the value as a Float instance.
     *
     * @return The value as a Float, never null.
     * @deprecated Use {@link #get()}.
     */
    @Deprecated
    @Override
    public Float getValue() {
        return Float.valueOf(this.value);
    }

    /**
     * Returns a suitable hash code for this mutable.
     *
     * @return A suitable hash code.
     */
    @Override
    public int hashCode() {
        return Float.floatToIntBits(value);
    }

    /**
     * Increments the value.
     *
     * @since 2.2
     */
    public void increment() {
        value++;
    }

    /**
     * Increments this instance's value by 1; this method returns the value associated with the instance
     * immediately after the increment operation. This method is not thread safe.
     *
     * @return The value associated with the instance after it is incremented.
     * @since 3.5
     */
    public float incrementAndGet() {
        value++;
        return value;
    }

    // shortValue and byteValue rely on Number implementation
    /**
     * Returns the value of this MutableFloat as an int.
     *
     * @return The numeric value represented by this object after conversion to type int.
     */
    @Override
    public int intValue() {
        return (int) value;
    }

    /**
     * Tests whether the float value is infinite.
     *
     * @return true if infinite
     */
    public boolean isInfinite() {
        return Float.isInfinite(value);
    }

    /**
     * Tests whether the float value is the special NaN value.
     *
     * @return true if NaN.
     */
    public boolean isNaN() {
        return Float.isNaN(value);
    }

    /**
     * Returns the value of this MutableFloat as a long.
     *
     * @return The numeric value represented by this object after conversion to type long.
     */
    @Override
    public long longValue() {
        return (long) value;
    }

    /**
     * Sets the value.
     *
     * @param value  The value to set.
     */
    public void setValue(final float value) {
        this.value = value;
    }

    /**
     * Sets the value from any Number instance.
     *
     * @param value  The value to set, not null.
     * @throws NullPointerException Thrown if the object is null.
     */
    @Override
    public void setValue(final Number value) {
        this.value = value.floatValue();
    }

    /**
     * Subtracts a value from the value of this instance.
     *
     * @param operand  The value to subtract.
     * @since 2.2
     */
    public void subtract(final float operand) {
        this.value -= operand;
    }

    /**
     * Subtracts a value from the value of this instance.
     *
     * @param operand  The value to subtract, not null.
     * @throws NullPointerException Thrown if the object is null.
     * @since 2.2
     */
    public void subtract(final Number operand) {
        this.value -= operand.floatValue();
    }

    /**
     * Gets this mutable as an instance of Float.
     *
     * @return A Float instance containing the value from this mutable, never null.
     */
    public Float toFloat() {
        return Float.valueOf(floatValue());
    }

    /**
     * Returns the String value of this mutable.
     *
     * @return The mutable value as a string.
     */
    @Override
    public String toString() {
        return String.valueOf(value);
    }

}
