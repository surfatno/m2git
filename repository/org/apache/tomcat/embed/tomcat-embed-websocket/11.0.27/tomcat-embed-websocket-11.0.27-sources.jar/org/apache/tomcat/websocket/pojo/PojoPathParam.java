/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package org.apache.tomcat.websocket.pojo;

import jakarta.websocket.DeploymentException;

import org.apache.tomcat.util.res.StringManager;
import org.apache.tomcat.websocket.Util;

/**
 * Stores the parameter type and name for a parameter that needs to be passed to an onXxx method of
 * {@link jakarta.websocket.Endpoint}. The name is only present for parameters annotated with
 * {@link jakarta.websocket.server.PathParam}; for all other parameters, {@link #getName()} will always return
 * <code>null</code>.
 */
public class PojoPathParam {

    private static final StringManager sm = StringManager.getManager(PojoPathParam.class);

    private final Class<?> type;
    private final String name;


    /**
     * Create a path parameter.
     *
     * @param type Parameter type
     * @param name Parameter name (may be {@code null} for non-{@code @PathParam} parameters)
     *
     * @throws DeploymentException If the type is not valid for a {@code @PathParam} parameter
     */
    public PojoPathParam(Class<?> type, String name) throws DeploymentException {
        if (name != null) {
            // Annotated as @PathParam so validate type
            validateType(type);
        }
        this.type = type;
        this.name = name;
    }


    /**
     * Return the type of the parameter.
     *
     * @return Parameter type
     */
    public Class<?> getType() {
        return type;
    }


    /**
     * Return the name of the parameter.
     *
     * @return Parameter name or {@code null} for non-{@code @PathParam} parameters
     */
    public String getName() {
        return name;
    }


    private static void validateType(Class<?> type) throws DeploymentException {
        if (String.class == type) {
            return;
        }
        if (Util.isPrimitive(type)) {
            return;
        }
        throw new DeploymentException(sm.getString("pojoPathParam.wrongType", type.getName()));
    }
}
