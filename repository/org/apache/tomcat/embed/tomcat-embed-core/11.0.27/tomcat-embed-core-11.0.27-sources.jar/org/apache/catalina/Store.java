/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.catalina;


import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;


/**
 * A <b>Store</b> is the abstraction of a Catalina component that provides persistent storage and loading of Sessions
 * and their associated user data. Implementations are free to save and load the Sessions to any media they wish, but it
 * is assumed that saved Sessions are persistent across server or context restarts.
 */
public interface Store {

    /**
     * Return the Manager instance associated with this Store.
     *
     * @return the Manager instance
     */
    Manager getManager();


    /**
     * Set the Manager associated with this Store.
     *
     * @param manager The Manager which will use this Store.
     */
    void setManager(Manager manager);


    /**
     * Return the number of Sessions present in this Store.
     *
     * @return the number of Sessions
     *
     * @throws IOException if an input/output error occurs
     */
    int getSize() throws IOException;


    /**
     * Add a property change listener to this component.
     *
     * @param listener The listener to add
     */
    void addPropertyChangeListener(PropertyChangeListener listener);


    /**
     * Return an array containing the session identifiers of all Sessions currently saved in this Store. If there are no
     * such Sessions, a zero-length array is returned.
     *
     * @return the session identifiers
     *
     * @throws IOException if an input/output error occurred
     */
    String[] keys() throws IOException;


    /**
     * Load and return the Session associated with the specified session identifier from this Store, without removing
     * it. If there is no such stored Session, return <code>null</code>.
     * <p>
     * Implementations should expect, and correctly handle, concurrent calls to any method but in particular calls to
     * {@code #load(String)}, {@code #save(Session)} and {@code #remove(String)} for the same session.
     * <p>
     * The session ID is user provided so stores must treat it as untrusted data.
     *
     * @param id Session identifier of the session to load
     *
     * @throws ClassNotFoundException if a deserialization error occurs
     * @throws IOException             if an input/output error occurs
     *
     * @return the loaded Session instance
     */
    Session load(String id) throws ClassNotFoundException, IOException;


    /**
     * Remove the Session with the specified session identifier from this Store, if present. If no such Session is
     * present, this method takes no action.
     * <p>
     * Implementations should expect, and correctly handle, concurrent calls to any method but in particular calls to
     * {@code #load(String)}, {@code #save(Session)} and {@code #remove(String)} for the same session.
     * <p>
     * The session ID is user provided so stores must treat it as untrusted data.
     *
     * @param id Session identifier of the Session to be removed
     *
     * @throws IOException if an input/output error occurs
     */
    void remove(String id) throws IOException;


    /**
     * Remove all Sessions from this Store.
     *
     * @throws IOException if an input/output error occurs
     */
    void clear() throws IOException;


    /**
     * Remove a property change listener from this component.
     *
     * @param listener The listener to remove
     */
    void removePropertyChangeListener(PropertyChangeListener listener);


    /**
     * Save the specified Session into this Store. Any previously saved information for the associated session
     * identifier is replaced.
     * <p>
     * Implementations should expect, and correctly handle, concurrent calls to any method but in particular calls to
     * {@code #load(String)}, {@code #save(Session)} and {@code #remove(String)} for the same session.
     *
     * @param session Session to be saved
     *
     * @throws IOException if an input/output error occurs
     */
    void save(Session session) throws IOException;


    /**
     * Obtain the session store lock for the session with the given identifier.
     * <p>
     * Sub-classes of StoreBase use this lock as necessary. External users of the Store must obtain a write lock before
     * changing the session identifier. More generally, external users of the store must obtain a write lock before
     * manipulating the session in any way that changes the mapping from session object to session identifier.
     * <p>
     * Implementations of this interface <b>MUST</b> provide an implementation of this method else any change in session
     * identifier, e.g. on authentication, may result in inconsistent data being held in the store.
     * <p>
     * Prior to Tomcat 12, the default implementation always returns a new {@link ReadWriteLock} which will not provide
     * any concurrency protection. From Tomcat 12, an {@link UnsupportedOperationException} is thrown.
     *
     * @param sessionId the session identifier
     *
     * @return The lock for the given session identifier
     */
    default ReadWriteLock getSessionStoreLock(String sessionId) {
        return new ReentrantReadWriteLock();
    }
}
