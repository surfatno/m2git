/*
 * Copyright 2012-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.cloud.client.discovery.composite.reactive;

import java.util.List;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.ConditionalOnDiscoveryEnabled;
import org.springframework.cloud.client.ConditionalOnReactiveDiscoveryEnabled;
import org.springframework.cloud.client.discovery.ReactiveDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * Auto-configuration for reactive composite discovery client.
 *
 * @author Tim Ysewyn
 * @since 2.2.0
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnDiscoveryEnabled
@ConditionalOnReactiveDiscoveryEnabled
@EnableConfigurationProperties(ReactiveCompositeDiscoveryClientProperties.class)
public class ReactiveCompositeDiscoveryClientAutoConfiguration {

	private final ReactiveCompositeDiscoveryClientProperties properties;

	public ReactiveCompositeDiscoveryClientAutoConfiguration(ReactiveCompositeDiscoveryClientProperties properties) {
		this.properties = properties;
	}

	@Bean
	@Primary
	public ReactiveCompositeDiscoveryClient reactiveCompositeDiscoveryClient(
			List<ReactiveDiscoveryClient> discoveryClients) {
		return new ReactiveCompositeDiscoveryClient(discoveryClients, this.properties.isOrderEnforced());
	}

}
