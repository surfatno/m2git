/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.cloud.netflix.eureka.http;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.hc.client5.http.config.RequestConfig;

import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.lang.Nullable;

/**
 * Supplier for the {@link ClientHttpRequestFactory} to be used by Eureka client.
 *
 * @author Marcin Grzejszczak
 * @since 3.0.0
 */
public interface EurekaClientHttpRequestFactorySupplier {

	/**
	 * Returns a constructed {@link ClientHttpRequestFactory}.
	 * @param sslContext SSL Context
	 * @param hostnameVerifier Hostname verifier
	 * @return {@link ClientHttpRequestFactory}
	 */
	ClientHttpRequestFactory get(SSLContext sslContext, @Nullable HostnameVerifier hostnameVerifier);

	/**
	 * Allows customising the {@link RequestConfig} of the underlying Apache HC5 instance.
	 *
	 * @author Olga Maciaszek-Sharma
	 * @since 4.2.1
	 */
	@FunctionalInterface
	interface RequestConfigCustomizer {

		void customize(RequestConfig.Builder builder);

	}

}
