/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.devtools.autoconfigure;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.derby.jdbc.EmbeddedDriver;
import org.jspecify.annotations.Nullable;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionMessage;
import org.springframework.boot.autoconfigure.condition.ConditionOutcome;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.SpringBootCondition;
import org.springframework.boot.devtools.autoconfigure.DevToolsDataSourceAutoConfiguration.DatabaseShutdownExecutorEntityManagerFactoryDependsOnConfiguration;
import org.springframework.boot.devtools.autoconfigure.DevToolsDataSourceAutoConfiguration.DevToolsDataSourceCondition;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.boot.jdbc.autoconfigure.DataSourceProperties;
import org.springframework.boot.jpa.autoconfigure.EntityManagerFactoryDependsOnPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ConfigurationCondition;
import org.springframework.context.annotation.Import;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.orm.jpa.AbstractEntityManagerFactoryBean;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.util.Assert;

/**
 * {@link EnableAutoConfiguration Auto-configuration} for DevTools-specific
 * {@link DataSource} configuration.
 *
 * @author Andy Wilkinson
 * @since 1.3.3
 */
@ConditionalOnClass({ DataSource.class, DataSourceProperties.class })
@ConditionalOnEnabledDevTools
@Conditional(DevToolsDataSourceCondition.class)
@AutoConfiguration(afterName = "org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration")
@Import(DatabaseShutdownExecutorEntityManagerFactoryDependsOnConfiguration.class)
public final class DevToolsDataSourceAutoConfiguration {

	@Bean
	NonEmbeddedInMemoryDatabaseShutdownExecutor inMemoryDatabaseShutdownExecutor(DataSource dataSource,
			DataSourceProperties dataSourceProperties) {
		return new NonEmbeddedInMemoryDatabaseShutdownExecutor(dataSource, dataSourceProperties);
	}

	@Configuration(proxyBeanMethods = false)
	@ConditionalOnClass({ EntityManagerFactoryDependsOnPostProcessor.class,
			LocalContainerEntityManagerFactoryBean.class })
	@ConditionalOnBean(AbstractEntityManagerFactoryBean.class)
	@Import(DatabaseShutdownExecutorEntityManagerFactoryDependsOnPostProcessor.class)
	static class DatabaseShutdownExecutorEntityManagerFactoryDependsOnConfiguration {

	}

	/**
	 * Post processor to ensure that {@link jakarta.persistence.EntityManagerFactory}
	 * beans depend on the {@code inMemoryDatabaseShutdownExecutor} bean.
	 */
	static class DatabaseShutdownExecutorEntityManagerFactoryDependsOnPostProcessor
			extends EntityManagerFactoryDependsOnPostProcessor {

		DatabaseShutdownExecutorEntityManagerFactoryDependsOnPostProcessor() {
			super("inMemoryDatabaseShutdownExecutor");
		}

	}

	static final class NonEmbeddedInMemoryDatabaseShutdownExecutor implements DisposableBean {

		private final DataSource dataSource;

		private final DataSourceProperties dataSourceProperties;

		NonEmbeddedInMemoryDatabaseShutdownExecutor(DataSource dataSource, DataSourceProperties dataSourceProperties) {
			this.dataSource = dataSource;
			this.dataSourceProperties = dataSourceProperties;
		}

		@Override
		public void destroy() throws Exception {
			for (InMemoryDatabase inMemoryDatabase : InMemoryDatabase.values()) {
				if (inMemoryDatabase.matches(this.dataSourceProperties)) {
					inMemoryDatabase.shutdown(this.dataSource);
					return;
				}
			}
		}

		private enum InMemoryDatabase {

			/*
			 * @deprecated since 4.1.0 for removal in 4.3.0 as Derby is EOL.
			 */
			@Deprecated(since = "4.1.0", forRemoval = true)
			DERBY(null, Set.of("org.apache.derby.jdbc.EmbeddedDriver"), (dataSource) -> {
				String url;
				try (Connection connection = dataSource.getConnection()) {
					url = connection.getMetaData().getURL();
				}
				try {
					new EmbeddedDriver().connect(url + ";drop=true", new Properties()).close();
				}
				catch (SQLException ex) {
					if (!"08006".equals(ex.getSQLState())) {
						throw ex;
					}
				}
			}),

			H2("jdbc:h2:mem:", Set.of("org.h2.Driver", "org.h2.jdbcx.JdbcDataSource")),

			HSQLDB("jdbc:hsqldb:mem:", Set.of("org.hsqldb.jdbcDriver", "org.hsqldb.jdbc.JDBCDriver",
					"org.hsqldb.jdbc.pool.JDBCXADataSource"));

			private final @Nullable String urlPrefix;

			private final ShutdownHandler shutdownHandler;

			private final Set<String> driverClassNames;

			InMemoryDatabase(@Nullable String urlPrefix, Set<String> driverClassNames) {
				this(urlPrefix, driverClassNames, (dataSource) -> {
					try (Connection connection = dataSource.getConnection()) {
						try (Statement statement = connection.createStatement()) {
							statement.execute("SHUTDOWN");
						}
					}
				});
			}

			InMemoryDatabase(@Nullable String urlPrefix, Set<String> driverClassNames,
					ShutdownHandler shutdownHandler) {
				this.urlPrefix = urlPrefix;
				this.driverClassNames = driverClassNames;
				this.shutdownHandler = shutdownHandler;
			}

			boolean matches(DataSourceProperties properties) {
				String url = properties.getUrl();
				return (url == null || this.urlPrefix == null || url.startsWith(this.urlPrefix))
						&& this.driverClassNames.contains(properties.determineDriverClassName());
			}

			void shutdown(DataSource dataSource) throws SQLException {
				this.shutdownHandler.shutdown(dataSource);
			}

			@FunctionalInterface
			interface ShutdownHandler {

				void shutdown(DataSource dataSource) throws SQLException;

			}

		}

	}

	static class DevToolsDataSourceCondition extends SpringBootCondition implements ConfigurationCondition {

		@Override
		public ConfigurationPhase getConfigurationPhase() {
			return ConfigurationPhase.REGISTER_BEAN;
		}

		@Override
		public ConditionOutcome getMatchOutcome(ConditionContext context, AnnotatedTypeMetadata metadata) {
			ConditionMessage.Builder message = ConditionMessage.forCondition("DevTools DataSource Condition");
			ConfigurableListableBeanFactory beanFactory = context.getBeanFactory();
			Assert.state(beanFactory != null, "'beanFactory' must not be null");
			String[] dataSourceBeanNames = beanFactory.getBeanNamesForType(DataSource.class, true, false);
			if (dataSourceBeanNames.length != 1) {
				return ConditionOutcome.noMatch(message.didNotFind("a single DataSource bean").atAll());
			}
			if (beanFactory.getBeanNamesForType(DataSourceProperties.class, true, false).length != 1) {
				return ConditionOutcome.noMatch(message.didNotFind("a single DataSourceProperties bean").atAll());
			}
			BeanDefinition dataSourceDefinition = context.getRegistry().getBeanDefinition(dataSourceBeanNames[0]);
			if (dataSourceDefinition instanceof AnnotatedBeanDefinition annotatedBeanDefinition
					&& annotatedBeanDefinition.getFactoryMethodMetadata() != null
					&& annotatedBeanDefinition.getFactoryMethodMetadata()
						.getDeclaringClassName()
						.startsWith(DataSourceAutoConfiguration.class.getPackage().getName()
								+ ".DataSourceConfiguration$")) {
				return ConditionOutcome.match(message.foundExactly("auto-configured DataSource"));
			}
			return ConditionOutcome.noMatch(message.didNotFind("an auto-configured DataSource").atAll());
		}

	}

}
