/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.devtools.livereload;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * {@link InputStream} for a server connection.
 *
 * @author Phillip Webb
 */
class ConnectionInputStream extends FilterInputStream {

	private static final String HEADER_END = "\r\n\r\n";

	private static final int BUFFER_SIZE = 4096;

	private static final int MAX_HEADER_SIZE = 8192;

	ConnectionInputStream(InputStream in) {
		super(in);
	}

	/**
	 * Read the HTTP header from the {@link InputStream}. Note: This method doesn't expect
	 * any HTTP content after the header since the initial request is usually just a
	 * WebSocket upgrade.
	 * @return the HTTP header
	 * @throws IOException in case of I/O errors
	 */
	String readHeader() throws IOException {
		byte[] buffer = new byte[BUFFER_SIZE];
		StringBuilder content = new StringBuilder(BUFFER_SIZE);
		while (content.indexOf(HEADER_END) == -1 && content.length() < MAX_HEADER_SIZE) {
			int amountRead = checkedRead(buffer, 0, BUFFER_SIZE);
			content.append(new String(buffer, 0, amountRead));
		}

		int endIndex = content.indexOf(HEADER_END);
		if (endIndex == -1) {
			throw new IOException("Malformed header");
		}
		return content.substring(0, endIndex);
	}

	/**
	 * Repeatedly read the underlying {@link InputStream} until the requested number of
	 * bytes have been loaded.
	 * @param buffer the destination buffer
	 * @param offset the buffer offset
	 * @param length the amount of data to read
	 * @throws IOException in case of I/O errors
	 */
	void readFully(byte[] buffer, int offset, int length) throws IOException {
		while (length > 0) {
			int amountRead = checkedRead(buffer, offset, length);
			offset += amountRead;
			length -= amountRead;
		}
	}

	/**
	 * Read a single byte from the stream (checking that the end of the stream hasn't been
	 * reached).
	 * @return the content
	 * @throws IOException in case of I/O errors
	 */
	int checkedRead() throws IOException {
		int b = read();
		if (b == -1) {
			throw new IOException("End of stream");
		}
		return (b & 0xff);
	}

	/**
	 * Read a number of bytes from the stream (checking that the end of the stream hasn't
	 * been reached).
	 * @param buffer the destination buffer
	 * @param offset the buffer offset
	 * @param length the length to read
	 * @return the amount of data read
	 * @throws IOException in case of I/O errors
	 */
	int checkedRead(byte[] buffer, int offset, int length) throws IOException {
		int amountRead = read(buffer, offset, length);
		if (amountRead == -1) {
			throw new IOException("End of stream");
		}
		return amountRead;
	}

}
