/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.endpoint.web;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.endpoint.Producible;
import org.springframework.boot.actuate.endpoint.web.annotation.EndpointWebExtension;
import org.springframework.util.MimeType;

/**
 * A {@code WebEndpointResponse} can be returned by an operation on a
 * {@link EndpointWebExtension @EndpointWebExtension} to provide additional, web-specific
 * information such as the HTTP status code.
 *
 * @param <T> the type of the response body
 * @author Stephane Nicoll
 * @author Andy Wilkinson
 * @author Vedran Pavic
 * @since 2.0.0
 */
public final class WebEndpointResponse<T> {

	/**
	 * {@code 200 OK}.
	 */
	public static final int STATUS_OK = 200;

	/**
	 * {@code 204 No Content}.
	 */
	public static final int STATUS_NO_CONTENT = 204;

	/**
	 * {@code 400 Bad Request}.
	 */
	public static final int STATUS_BAD_REQUEST = 400;

	/**
	 * {@code 404 Not Found}.
	 */
	public static final int STATUS_NOT_FOUND = 404;

	/**
	 * {@code 429 Too Many Requests}.
	 */
	public static final int STATUS_TOO_MANY_REQUESTS = 429;

	/**
	 * {@code 500 Internal Server Error}.
	 */
	public static final int STATUS_INTERNAL_SERVER_ERROR = 500;

	/**
	 * {@code 503 Service Unavailable}.
	 */
	public static final int STATUS_SERVICE_UNAVAILABLE = 503;

	private final @Nullable T body;

	private final int status;

	private final @Nullable MimeType contentType;

	/**
	 * Creates a new {@code WebEndpointResponse} with no body and a 200 (OK) status.
	 */
	public WebEndpointResponse() {
		this(null);
	}

	/**
	 * Creates a new {@code WebEndpointResponse} with no body and the given
	 * {@code status}.
	 * @param status the HTTP status
	 */
	public WebEndpointResponse(int status) {
		this(null, status);
	}

	/**
	 * Creates a new {@code WebEndpointResponse} with the given body and a 200 (OK)
	 * status.
	 * @param body the body
	 */
	public WebEndpointResponse(@Nullable T body) {
		this(body, STATUS_OK);
	}

	/**
	 * Creates a new {@code WebEndpointResponse} with the given body and content type and
	 * a 200 (OK) status.
	 * @param body the body
	 * @param producible the producible providing the content type
	 * @since 2.5.0
	 */
	public WebEndpointResponse(@Nullable T body, Producible<?> producible) {
		this(body, STATUS_OK, producible.getProducedMimeType());
	}

	/**
	 * Creates a new {@code WebEndpointResponse} with the given body and content type and
	 * a 200 (OK) status.
	 * @param body the body
	 * @param contentType the content type of the response
	 * @since 2.5.0
	 */
	public WebEndpointResponse(@Nullable T body, MimeType contentType) {
		this(body, STATUS_OK, contentType);
	}

	/**
	 * Creates a new {@code WebEndpointResponse} with the given body and status.
	 * @param body the body
	 * @param status the HTTP status
	 */
	public WebEndpointResponse(@Nullable T body, int status) {
		this(body, status, null);
	}

	/**
	 * Creates a new {@code WebEndpointResponse} with the given body and status.
	 * @param body the body
	 * @param status the HTTP status
	 * @param contentType the content type of the response
	 * @since 2.5.0
	 */
	public WebEndpointResponse(@Nullable T body, int status, @Nullable MimeType contentType) {
		this.body = body;
		this.status = status;
		this.contentType = contentType;
	}

	/**
	 * Returns the content type of the response.
	 * @return the content type;
	 */
	public @Nullable MimeType getContentType() {
		return this.contentType;
	}

	/**
	 * Returns the body for the response.
	 * @return the body
	 */
	public @Nullable T getBody() {
		return this.body;
	}

	/**
	 * Returns the status for the response.
	 * @return the status
	 */
	public int getStatus() {
		return this.status;
	}

}
