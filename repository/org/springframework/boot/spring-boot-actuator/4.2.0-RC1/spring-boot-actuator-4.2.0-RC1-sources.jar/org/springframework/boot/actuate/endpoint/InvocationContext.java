/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.endpoint;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.endpoint.invoke.OperationInvoker;
import org.springframework.util.Assert;

/**
 * The context for the {@link OperationInvoker invocation of an operation}.
 *
 * @author Andy Wilkinson
 * @author Phillip Webb
 * @since 2.0.0
 */
public class InvocationContext {

	private final Map<String, Object> arguments;

	private final List<OperationArgumentResolver> argumentResolvers;

	/**
	 * Creates a new context for an operation being invoked by the given
	 * {@code securityContext} with the given available {@code arguments}.
	 * @param securityContext the current security context. Never {@code null}
	 * @param arguments the arguments available to the operation. Never {@code null}
	 * @param argumentResolvers resolvers for additional arguments should be available to
	 * the operation.
	 */
	public InvocationContext(SecurityContext securityContext, Map<String, Object> arguments,
			OperationArgumentResolver @Nullable ... argumentResolvers) {
		Assert.notNull(securityContext, "'securityContext' must not be null");
		Assert.notNull(arguments, "'arguments' must not be null");
		this.arguments = arguments;
		this.argumentResolvers = new ArrayList<>();
		if (argumentResolvers != null) {
			this.argumentResolvers.addAll(Arrays.asList(argumentResolvers));
		}
		this.argumentResolvers.add(OperationArgumentResolver.of(SecurityContext.class, () -> securityContext));
		this.argumentResolvers.add(OperationArgumentResolver.of(Principal.class, securityContext::getPrincipal));
		this.argumentResolvers.add(OperationArgumentResolver.of(ApiVersion.class, () -> ApiVersion.LATEST));
	}

	/**
	 * Return the invocation arguments.
	 * @return the arguments
	 */
	public Map<String, Object> getArguments() {
		return this.arguments;
	}

	/**
	 * Resolves an argument with the given {@code argumentType}.
	 * @param <T> type of the argument
	 * @param argumentType type of the argument
	 * @return resolved argument of the required type or {@code null}
	 * @since 2.5.0
	 * @see #canResolve(Class)
	 */
	public <T> @Nullable T resolveArgument(Class<T> argumentType) {
		for (OperationArgumentResolver argumentResolver : this.argumentResolvers) {
			if (argumentResolver.canResolve(argumentType)) {
				T result = argumentResolver.resolve(argumentType);
				if (result != null) {
					return result;
				}
			}
		}
		return null;
	}

	/**
	 * Returns whether the context is capable of resolving an argument of the given
	 * {@code type}. Note that, even when {@code true} is returned,
	 * {@link #resolveArgument argument resolution} will return {@code null} if no
	 * argument of the required type is available.
	 * @param type argument type
	 * @return {@code true} if resolution of arguments of the given type is possible,
	 * otherwise {@code false}.
	 * @since 2.5.0
	 * @see #resolveArgument(Class)
	 */
	public boolean canResolve(Class<?> type) {
		for (OperationArgumentResolver argumentResolver : this.argumentResolvers) {
			if (argumentResolver.canResolve(type)) {
				return true;
			}
		}
		return false;
	}

}
