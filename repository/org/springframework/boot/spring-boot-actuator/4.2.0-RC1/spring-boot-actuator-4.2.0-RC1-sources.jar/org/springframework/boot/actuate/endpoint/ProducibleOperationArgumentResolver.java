/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.endpoint;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MimeType;
import org.springframework.util.MimeTypeUtils;

/**
 * An {@link OperationArgumentResolver} for {@link Producible producible enums}.
 *
 * @author Andy Wilkinson
 * @author Phillip Webb
 * @since 2.5.0
 */
public class ProducibleOperationArgumentResolver implements OperationArgumentResolver {

	private final Supplier<@Nullable List<String>> accepts;

	/**
	 * Create a new {@link ProducibleOperationArgumentResolver} instance.
	 * @param accepts supplier that returns accepted mime types
	 */
	public ProducibleOperationArgumentResolver(Supplier<@Nullable List<String>> accepts) {
		this.accepts = accepts;
	}

	@Override
	public boolean canResolve(Class<?> type) {
		return Producible.class.isAssignableFrom(type) && Enum.class.isAssignableFrom(type);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> @Nullable T resolve(Class<T> type) {
		return (T) resolveProducible((Class<Enum<? extends Producible<?>>>) type);
	}

	private @Nullable Enum<? extends Producible<?>> resolveProducible(Class<Enum<? extends Producible<?>>> type) {
		List<String> accepts = this.accepts.get();
		List<Enum<? extends Producible<?>>> values = getValues(type);
		if (CollectionUtils.isEmpty(accepts)) {
			return getDefaultValue(values);
		}
		Enum<? extends Producible<?>> result = null;
		for (String accept : accepts) {
			for (MimeType mimeType : MimeTypeUtils.parseMimeTypes(accept)) {
				result = mostRecent(result, forMimeType(values, mimeType));
			}
		}
		return result;
	}

	private @Nullable Enum<? extends Producible<?>> mostRecent(@Nullable Enum<? extends Producible<?>> existing,
			@Nullable Enum<? extends Producible<?>> candidate) {
		int existingOrdinal = (existing != null) ? existing.ordinal() : -1;
		int candidateOrdinal = (candidate != null) ? candidate.ordinal() : -1;
		return (candidateOrdinal > existingOrdinal) ? candidate : existing;
	}

	private @Nullable Enum<? extends Producible<?>> forMimeType(List<Enum<? extends Producible<?>>> values,
			MimeType mimeType) {
		if (mimeType.isWildcardType() && mimeType.isWildcardSubtype()) {
			return getDefaultValue(values);
		}
		for (Enum<? extends Producible<?>> candidate : values) {
			if (mimeType.isCompatibleWith(((Producible<?>) candidate).getProducedMimeType())) {
				return candidate;
			}
		}
		return null;
	}

	private List<Enum<? extends Producible<?>>> getValues(Class<Enum<? extends Producible<?>>> type) {
		List<Enum<? extends Producible<?>>> values = Arrays.asList(type.getEnumConstants());
		Collections.reverse(values);
		Assert.state(values.stream().filter(this::isDefault).count() <= 1,
				"Multiple default values declared in " + type.getName());
		return values;
	}

	private Enum<? extends Producible<?>> getDefaultValue(List<Enum<? extends Producible<?>>> values) {
		return values.stream().filter(this::isDefault).findFirst().orElseGet(() -> values.get(0));
	}

	private boolean isDefault(Enum<? extends Producible<?>> value) {
		return ((Producible<?>) value).isDefault();
	}

}
