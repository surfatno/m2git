/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.endpoint;

import org.springframework.boot.actuate.endpoint.annotation.DeleteOperation;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.util.MimeType;

/**
 * Interface that can be implemented by any {@link Enum} that represents a finite set of
 * producible mime-types.
 * <p>
 * Can be used with {@link ReadOperation @ReadOperation},
 * {@link WriteOperation @WriteOperation} and {@link DeleteOperation @DeleteOperation}
 * annotations to quickly define a list of {@code produces} values.
 * <p>
 * {@link Producible} types can also be injected into operations when the underlying
 * technology supports content negotiation. For example, with web based endpoints, the
 * value of the {@code Producible} enum is resolved using the {@code Accept} header of the
 * request. When multiple values are equally acceptable, the value with the highest
 * {@link Enum#ordinal() ordinal} is used.
 *
 * @param <E> enum type that implements this interface
 * @author Andy Wilkinson
 * @since 2.5.0
 */
public interface Producible<E extends Enum<E> & Producible<E>> {

	/**
	 * Mime type that can be produced.
	 * @return the producible mime type
	 */
	MimeType getProducedMimeType();

	/**
	 * Return if this enum value should be used as the default value when an accept header
	 * of &#42;&#47;&#42; is provided, or if the {@code Accept} header is missing. Only
	 * one value can be marked as default. If no value is marked, then the value with the
	 * highest {@link Enum#ordinal() ordinal} is used as the default.
	 * @return if this value should be used as the default value
	 * @since 2.5.6
	 */
	default boolean isDefault() {
		return false;
	}

}
