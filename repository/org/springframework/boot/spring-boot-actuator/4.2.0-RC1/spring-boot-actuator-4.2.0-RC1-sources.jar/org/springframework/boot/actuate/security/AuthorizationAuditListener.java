/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.security;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.audit.AuditEvent;
import org.springframework.security.authorization.event.AuthorizationDeniedEvent;
import org.springframework.security.authorization.event.AuthorizationEvent;
import org.springframework.security.core.Authentication;

/**
 * Default implementation of {@link AbstractAuthorizationAuditListener}.
 *
 * @author Dave Syer
 * @author Vedran Pavic
 * @since 1.0.0
 */
public class AuthorizationAuditListener extends AbstractAuthorizationAuditListener {

	/**
	 * Authorization failure event type.
	 */
	public static final String AUTHORIZATION_FAILURE = "AUTHORIZATION_FAILURE";

	@Override
	public void onApplicationEvent(AuthorizationEvent event) {
		if (event instanceof AuthorizationDeniedEvent<?> authorizationDeniedEvent) {
			onAuthorizationDeniedEvent(authorizationDeniedEvent);
		}
	}

	private void onAuthorizationDeniedEvent(AuthorizationDeniedEvent<?> event) {
		String name = getName(event.getAuthentication());
		Map<String, @Nullable Object> data = new LinkedHashMap<>();
		Object details = getDetails(event.getAuthentication());
		if (details != null) {
			data.put("details", details);
		}
		publish(new AuditEvent(name, AUTHORIZATION_FAILURE, data));
	}

	private String getName(Supplier<Authentication> authentication) {
		try {
			return authentication.get().getName();
		}
		catch (Exception ex) {
			return "<unknown>";
		}
	}

	private @Nullable Object getDetails(Supplier<Authentication> authentication) {
		try {
			return authentication.get().getDetails();
		}
		catch (Exception ex) {
			return null;
		}
	}

}
