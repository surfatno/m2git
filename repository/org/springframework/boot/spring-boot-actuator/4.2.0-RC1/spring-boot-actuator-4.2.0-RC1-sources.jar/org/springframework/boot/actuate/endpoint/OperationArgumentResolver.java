/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.endpoint;

import java.util.function.Supplier;

import org.jspecify.annotations.Nullable;

import org.springframework.util.Assert;

/**
 * Resolver for an argument of an {@link Operation}.
 *
 * @author Andy Wilkinson
 * @since 2.5.0
 */
public interface OperationArgumentResolver {

	/**
	 * Return whether an argument of the given {@code type} can be resolved.
	 * @param type argument type
	 * @return {@code true} if an argument of the required type can be resolved, otherwise
	 * {@code false}
	 */
	boolean canResolve(Class<?> type);

	/**
	 * Resolves an argument of the given {@code type}.
	 * @param <T> required type of the argument
	 * @param type argument type
	 * @return an argument of the required type, or {@code null}
	 */
	<T> @Nullable T resolve(Class<T> type);

	/**
	 * Factory method that creates an {@link OperationArgumentResolver} for a specific
	 * type using a {@link Supplier}.
	 * @param <T> the resolvable type
	 * @param type the resolvable type
	 * @param supplier the value supplier
	 * @return an {@link OperationArgumentResolver} instance
	 */
	static <T> OperationArgumentResolver of(Class<T> type, Supplier<? extends @Nullable T> supplier) {
		Assert.notNull(type, "'type' must not be null");
		Assert.notNull(supplier, "'supplier' must not be null");
		return new OperationArgumentResolver() {

			@Override
			public boolean canResolve(Class<?> actualType) {
				return actualType.equals(type);
			}

			@Override
			@SuppressWarnings("unchecked")
			public <R> @Nullable R resolve(Class<R> argumentType) {
				return (R) supplier.get();
			}

		};
	}

}
