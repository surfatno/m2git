/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.audit.listener;

import java.time.Instant;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.audit.AuditEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.util.Assert;

/**
 * Spring {@link ApplicationEvent} to encapsulate {@link AuditEvent}s.
 *
 * @author Dave Syer
 * @since 1.0.0
 */
public class AuditApplicationEvent extends ApplicationEvent {

	private final AuditEvent auditEvent;

	/**
	 * Create a new {@link AuditApplicationEvent} that wraps a newly created
	 * {@link AuditEvent}.
	 * @param principal the principal
	 * @param type the event type
	 * @param data the event data
	 * @see AuditEvent#AuditEvent(String, String, Map)
	 */
	public AuditApplicationEvent(String principal, String type, Map<String, @Nullable Object> data) {
		this(new AuditEvent(principal, type, data));
	}

	/**
	 * Create a new {@link AuditApplicationEvent} that wraps a newly created
	 * {@link AuditEvent}.
	 * @param principal the principal
	 * @param type the event type
	 * @param data the event data
	 * @see AuditEvent#AuditEvent(String, String, String...)
	 */
	public AuditApplicationEvent(String principal, String type, String... data) {
		this(new AuditEvent(principal, type, data));
	}

	/**
	 * Create a new {@link AuditApplicationEvent} that wraps a newly created
	 * {@link AuditEvent}.
	 * @param timestamp the timestamp
	 * @param principal the principal
	 * @param type the event type
	 * @param data the event data
	 * @see AuditEvent#AuditEvent(Instant, String, String, Map)
	 */
	public AuditApplicationEvent(Instant timestamp, String principal, String type, Map<String, @Nullable Object> data) {
		this(new AuditEvent(timestamp, principal, type, data));
	}

	/**
	 * Create a new {@link AuditApplicationEvent} that wraps the specified
	 * {@link AuditEvent}.
	 * @param auditEvent the source of this event
	 */
	public AuditApplicationEvent(AuditEvent auditEvent) {
		super(auditEvent);
		Assert.notNull(auditEvent, "'auditEvent' must not be null");
		this.auditEvent = auditEvent;
	}

	/**
	 * Get the audit event.
	 * @return the audit event
	 */
	public AuditEvent getAuditEvent() {
		return this.auditEvent;
	}

}
