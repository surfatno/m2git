/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.health.actuate.endpoint;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.endpoint.SecurityContext;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthContributor;

/**
 * A logical grouping of {@link HealthContributor health contributors} that can be exposed
 * by the {@link HealthEndpoint}.
 *
 * @author Phillip Webb
 * @author Madhura Bhave
 * @since 4.0.0
 */
public interface HealthEndpointGroup {

	/**
	 * Returns {@code true} if the given contributor is a member of this group.
	 * @param name the contributor name
	 * @return {@code true} if the contributor is a member of this group
	 */
	boolean isMember(String name);

	/**
	 * Returns if {@link CompositeHealthDescriptor#getComponents() health components}
	 * should be shown in the response.
	 * @param securityContext the endpoint security context
	 * @return {@code true} to shown details or {@code false} to hide them
	 */
	boolean showComponents(SecurityContext securityContext);

	/**
	 * Returns if {@link Health#getDetails() health details} should be shown in the
	 * response.
	 * @param securityContext the endpoint security context
	 * @return {@code true} to shown details or {@code false} to hide them
	 */
	boolean showDetails(SecurityContext securityContext);

	/**
	 * Returns the status aggregator that should be used for this group.
	 * @return the status aggregator for this group
	 */
	StatusAggregator getStatusAggregator();

	/**
	 * Returns the {@link HttpCodeStatusMapper} that should be used for this group.
	 * @return the HTTP code status mapper
	 */
	HttpCodeStatusMapper getHttpCodeStatusMapper();

	/**
	 * Return an additional path that can be used to map the health group to an
	 * alternative location.
	 * @return the additional health path or {@code null}
	 */
	@Nullable AdditionalHealthEndpointPath getAdditionalPath();

}
