/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.health.autoconfigure.actuate.endpoint;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.actuate.endpoint.Show;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.health.actuate.endpoint.HealthEndpoint;

/**
 * Configuration properties for {@link HealthEndpoint}.
 *
 * @author Phillip Webb
 * @author Leo Li
 * @since 4.0.0
 */
@ConfigurationProperties("management.endpoint.health")
public class HealthEndpointProperties extends HealthProperties {

	/**
	 * When to show full health details.
	 */
	private Show showDetails = Show.NEVER;

	/**
	 * Health endpoint groups.
	 */
	private final Map<String, Group> group = new LinkedHashMap<>();

	private final Logging logging = new Logging();

	@Override
	public Show getShowDetails() {
		return this.showDetails;
	}

	public void setShowDetails(Show showDetails) {
		this.showDetails = showDetails;
	}

	public Map<String, Group> getGroup() {
		return this.group;
	}

	public Logging getLogging() {
		return this.logging;
	}

	/**
	 * A health endpoint group.
	 */
	public static class Group extends HealthProperties {

		public static final String SERVER_PREFIX = "server:";

		public static final String MANAGEMENT_PREFIX = "management:";

		/**
		 * Health indicator IDs that should be included or '*' for all.
		 */
		private @Nullable Set<String> include;

		/**
		 * Health indicator IDs that should be excluded or '*' for all.
		 */
		private @Nullable Set<String> exclude;

		/**
		 * When to show full health details. Defaults to the value of
		 * 'management.endpoint.health.show-details'.
		 */
		private @Nullable Show showDetails;

		/**
		 * Additional path that this group can be made available on. The additional path
		 * must start with a valid prefix, either `server` or `management` to indicate if
		 * it will be available on the main port or the management port. For instance,
		 * `server:/healthz` will configure the group on the main port at `/healthz`.
		 */
		private @Nullable String additionalPath;

		public @Nullable Set<String> getInclude() {
			return this.include;
		}

		public void setInclude(@Nullable Set<String> include) {
			this.include = include;
		}

		public @Nullable Set<String> getExclude() {
			return this.exclude;
		}

		public void setExclude(@Nullable Set<String> exclude) {
			this.exclude = exclude;
		}

		@Override
		public @Nullable Show getShowDetails() {
			return this.showDetails;
		}

		public void setShowDetails(@Nullable Show showDetails) {
			this.showDetails = showDetails;
		}

		public @Nullable String getAdditionalPath() {
			return this.additionalPath;
		}

		public void setAdditionalPath(@Nullable String additionalPath) {
			this.additionalPath = additionalPath;
		}

	}

	/**
	 * Health logging properties.
	 */
	public static class Logging {

		/**
		 * Threshold after which a warning will be logged for slow health indicators.
		 */
		private Duration slowIndicatorThreshold = Duration.ofSeconds(10);

		public Duration getSlowIndicatorThreshold() {
			return this.slowIndicatorThreshold;
		}

		public void setSlowIndicatorThreshold(Duration slowIndicatorThreshold) {
			this.slowIndicatorThreshold = slowIndicatorThreshold;
		}

	}

}
