/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.actuate.autoconfigure.endpoint.web;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.PropertyMapper;
import org.springframework.boot.convert.DurationUnit;
import org.springframework.util.CollectionUtils;
import org.springframework.web.cors.CorsConfiguration;

/**
 * Configuration properties for web endpoints' CORS support.
 *
 * @author Andy Wilkinson
 * @since 2.0.0
 */
@ConfigurationProperties("management.endpoints.web.cors")
public class CorsEndpointProperties {

	/**
	 * List of origins to allow. '*' allows all origins. When credentials are allowed, '*'
	 * cannot be used and origin patterns should be configured instead. When no allowed
	 * origins or allowed origin patterns are set, CORS support is disabled.
	 */
	private List<String> allowedOrigins = new ArrayList<>();

	/**
	 * List of origin patterns to allow. Unlike allowed origins which only supports '*',
	 * origin patterns are more flexible (for example 'https://*.example.com') and can be
	 * used when credentials are allowed. When no allowed origin patterns or allowed
	 * origins are set, CORS support is disabled.
	 */
	private List<String> allowedOriginPatterns = new ArrayList<>();

	/**
	 * List of methods to allow. '*' allows all methods. When not set, defaults to GET.
	 */
	private List<String> allowedMethods = new ArrayList<>();

	/**
	 * List of headers to allow in a request. '*' allows all headers.
	 */
	private List<String> allowedHeaders = new ArrayList<>();

	/**
	 * List of headers to include in a response.
	 */
	private List<String> exposedHeaders = new ArrayList<>();

	/**
	 * Whether credentials are supported. When not set, credentials are not supported.
	 */
	private @Nullable Boolean allowCredentials;

	/**
	 * How long the response from a pre-flight request can be cached by clients. If a
	 * duration suffix is not specified, seconds will be used.
	 */
	@DurationUnit(ChronoUnit.SECONDS)
	private Duration maxAge = Duration.ofSeconds(1800);

	public List<String> getAllowedOrigins() {
		return this.allowedOrigins;
	}

	public void setAllowedOrigins(List<String> allowedOrigins) {
		this.allowedOrigins = allowedOrigins;
	}

	public List<String> getAllowedOriginPatterns() {
		return this.allowedOriginPatterns;
	}

	public void setAllowedOriginPatterns(List<String> allowedOriginPatterns) {
		this.allowedOriginPatterns = allowedOriginPatterns;
	}

	public List<String> getAllowedMethods() {
		return this.allowedMethods;
	}

	public void setAllowedMethods(List<String> allowedMethods) {
		this.allowedMethods = allowedMethods;
	}

	public List<String> getAllowedHeaders() {
		return this.allowedHeaders;
	}

	public void setAllowedHeaders(List<String> allowedHeaders) {
		this.allowedHeaders = allowedHeaders;
	}

	public List<String> getExposedHeaders() {
		return this.exposedHeaders;
	}

	public void setExposedHeaders(List<String> exposedHeaders) {
		this.exposedHeaders = exposedHeaders;
	}

	public @Nullable Boolean getAllowCredentials() {
		return this.allowCredentials;
	}

	public void setAllowCredentials(@Nullable Boolean allowCredentials) {
		this.allowCredentials = allowCredentials;
	}

	public Duration getMaxAge() {
		return this.maxAge;
	}

	public void setMaxAge(Duration maxAge) {
		this.maxAge = maxAge;
	}

	public @Nullable CorsConfiguration toCorsConfiguration() {
		if (CollectionUtils.isEmpty(this.allowedOrigins) && CollectionUtils.isEmpty(this.allowedOriginPatterns)) {
			return null;
		}
		PropertyMapper map = PropertyMapper.get();
		CorsConfiguration configuration = new CorsConfiguration();
		map.from(this::getAllowedOrigins).to(configuration::setAllowedOrigins);
		map.from(this::getAllowedOriginPatterns).to(configuration::setAllowedOriginPatterns);
		map.from(this::getAllowedHeaders).whenNot(CollectionUtils::isEmpty).to(configuration::setAllowedHeaders);
		map.from(this::getAllowedMethods).whenNot(CollectionUtils::isEmpty).to(configuration::setAllowedMethods);
		map.from(this::getExposedHeaders).whenNot(CollectionUtils::isEmpty).to(configuration::setExposedHeaders);
		map.from(this::getMaxAge).as(Duration::getSeconds).to(configuration::setMaxAge);
		map.from(this::getAllowCredentials).to(configuration::setAllowCredentials);
		return configuration;
	}

}
