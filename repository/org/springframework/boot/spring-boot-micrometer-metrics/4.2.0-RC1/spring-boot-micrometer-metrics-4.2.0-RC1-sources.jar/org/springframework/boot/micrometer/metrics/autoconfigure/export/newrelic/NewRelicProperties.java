/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.micrometer.metrics.autoconfigure.export.newrelic;

import io.micrometer.newrelic.ClientProviderType;
import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.micrometer.metrics.autoconfigure.export.properties.StepRegistryProperties;

/**
 * {@link ConfigurationProperties @ConfigurationProperties} for configuring New Relic
 * metrics export.
 *
 * @author Jon Schneider
 * @author Andy Wilkinson
 * @author Stephane Nicoll
 * @author Neil Powell
 * @since 4.0.0
 */
@ConfigurationProperties("management.newrelic.metrics.export")
public class NewRelicProperties extends StepRegistryProperties {

	/**
	 * Whether to send the meter name as the event type instead of using the 'event-type'
	 * configuration property value. Can be set to 'true' if New Relic guidelines are not
	 * being followed or event types consistent with previous Spring Boot releases are
	 * required.
	 */
	private boolean meterNameEventTypeEnabled;

	/**
	 * The event type that should be published. This property will be ignored if
	 * 'meter-name-event-type-enabled' is set to 'true'.
	 */
	private String eventType = "SpringBootSample";

	/**
	 * Client provider type to use.
	 */
	private ClientProviderType clientProviderType = ClientProviderType.INSIGHTS_API;

	/**
	 * New Relic API key.
	 */
	private @Nullable String apiKey;

	/**
	 * New Relic account ID.
	 */
	private @Nullable String accountId;

	/**
	 * URI to ship metrics to.
	 */
	private String uri = "https://insights-collector.newrelic.com";

	public boolean isMeterNameEventTypeEnabled() {
		return this.meterNameEventTypeEnabled;
	}

	public void setMeterNameEventTypeEnabled(boolean meterNameEventTypeEnabled) {
		this.meterNameEventTypeEnabled = meterNameEventTypeEnabled;
	}

	public String getEventType() {
		return this.eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public ClientProviderType getClientProviderType() {
		return this.clientProviderType;
	}

	public void setClientProviderType(ClientProviderType clientProviderType) {
		this.clientProviderType = clientProviderType;
	}

	public @Nullable String getApiKey() {
		return this.apiKey;
	}

	public void setApiKey(@Nullable String apiKey) {
		this.apiKey = apiKey;
	}

	public @Nullable String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(@Nullable String accountId) {
		this.accountId = accountId;
	}

	public String getUri() {
		return this.uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}
