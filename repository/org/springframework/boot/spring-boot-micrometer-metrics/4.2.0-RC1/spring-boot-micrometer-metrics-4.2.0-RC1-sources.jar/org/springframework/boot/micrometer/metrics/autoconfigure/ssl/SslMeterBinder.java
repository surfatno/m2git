/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.micrometer.metrics.autoconfigure.ssl;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.MultiGauge;
import io.micrometer.core.instrument.MultiGauge.Row;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.MeterBinder;
import org.jspecify.annotations.Nullable;

import org.springframework.boot.info.SslInfo;
import org.springframework.boot.info.SslInfo.BundleInfo;
import org.springframework.boot.info.SslInfo.CertificateChainInfo;
import org.springframework.boot.info.SslInfo.CertificateInfo;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.util.Assert;

/**
 * {@link MeterBinder} which registers the SSL chain expiry (soonest to expire certificate
 * in the chain) for certificate chains in the bundle's key store and trust store as a
 * {@link MultiGauge}.
 *
 * @author Moritz Halbritter
 */
class SslMeterBinder implements MeterBinder {

	private static final String CHAIN_EXPIRY_METRIC_NAME = "ssl.chain.expiry";

	private static final String SOURCE_TAG_NAME = "source";

	private static final String KEY_STORE_SOURCE_TAG_VALUE = "keystore";

	private static final String TRUST_STORE_SOURCE_TAG_VALUE = "truststore";

	private final Clock clock;

	private final SslInfo sslInfo;

	private final BundleMetrics bundleMetrics = new BundleMetrics();

	private final Set<MeterRegistry> boundMeterRegistries = ConcurrentHashMap.newKeySet();

	SslMeterBinder(SslInfo sslInfo, SslBundles sslBundles) {
		this(sslInfo, sslBundles, Clock.systemDefaultZone());
	}

	SslMeterBinder(SslInfo sslInfo, SslBundles sslBundles, Clock clock) {
		this.clock = clock;
		this.sslInfo = sslInfo;
		sslBundles.addBundleRegisterHandler((bundleName, ignored) -> {
			onBundleChange(bundleName);
			sslBundles.addBundleUpdateHandler(bundleName, (ignoredBundle) -> onBundleChange(bundleName));
		});
		for (String bundleName : sslBundles.getBundleNames()) {
			sslBundles.addBundleUpdateHandler(bundleName, (ignored) -> onBundleChange(bundleName));
		}
	}

	private void onBundleChange(String bundleName) {
		BundleInfo bundle = this.sslInfo.getBundle(bundleName);
		this.bundleMetrics.updateBundle(bundle);
		for (MeterRegistry meterRegistry : this.boundMeterRegistries) {
			createOrUpdateBundleMetrics(meterRegistry, bundle);
		}
	}

	@Override
	public void bindTo(MeterRegistry meterRegistry) {
		this.boundMeterRegistries.add(meterRegistry);
		for (BundleInfo bundle : this.sslInfo.getBundles()) {
			createOrUpdateBundleMetrics(meterRegistry, bundle);
		}
	}

	private void createOrUpdateBundleMetrics(MeterRegistry meterRegistry, BundleInfo bundle) {
		MultiGauge multiGauge = this.bundleMetrics.getGauge(bundle, meterRegistry);
		List<Row<CertificateInfo>> rows = new ArrayList<>();
		addRows(rows, bundle, bundle.getCertificateChains(), KEY_STORE_SOURCE_TAG_VALUE);
		addRows(rows, bundle, bundle.getTrustStoreCertificateChains(), TRUST_STORE_SOURCE_TAG_VALUE);
		multiGauge.register(rows, true);
	}

	private void addRows(List<Row<CertificateInfo>> rows, BundleInfo bundle, List<CertificateChainInfo> chains,
			String source) {
		for (CertificateChainInfo chain : chains) {
			Row<CertificateInfo> row = createRowForChain(bundle, chain, source);
			if (row != null) {
				rows.add(row);
			}
		}
	}

	private @Nullable Row<CertificateInfo> createRowForChain(BundleInfo bundle, CertificateChainInfo chain,
			String source) {
		CertificateInfo leastValidCertificate = chain.getCertificates()
			.stream()
			.filter((c) -> c.getValidityEnds() != null)
			.min(Comparator.comparing(this::getValidityEnds))
			.orElse(null);
		if (leastValidCertificate == null) {
			return null;
		}
		String serialNumber = leastValidCertificate.getSerialNumber();
		Tags tags = Tags.of("chain", chain.getAlias(), "bundle", bundle.getName(), SOURCE_TAG_NAME, source,
				"certificate", (serialNumber != null) ? serialNumber : "");
		return Row.of(tags, leastValidCertificate, this::getChainExpiry);
	}

	private long getChainExpiry(CertificateInfo certificate) {
		Duration valid = Duration.between(Instant.now(this.clock), getValidityEnds(certificate));
		return valid.get(ChronoUnit.SECONDS);
	}

	private Instant getValidityEnds(CertificateInfo certificate) {
		Instant validityEnds = certificate.getValidityEnds();
		Assert.state(validityEnds != null, "'validityEnds' must not be null");
		return validityEnds;
	}

	/**
	 * Manages bundles and their metrics.
	 */
	private static final class BundleMetrics {

		private final Map<String, Gauges> gauges = new ConcurrentHashMap<>();

		/**
		 * Gets (or creates) a {@link MultiGauge} for the given bundle and meter registry.
		 * @param bundleInfo the bundle
		 * @param meterRegistry the meter registry
		 * @return the {@link MultiGauge}
		 */
		MultiGauge getGauge(BundleInfo bundleInfo, MeterRegistry meterRegistry) {
			Gauges gauges = this.gauges.computeIfAbsent(bundleInfo.getName(),
					(ignored) -> Gauges.emptyGauges(bundleInfo));
			return gauges.getGauge(meterRegistry);
		}

		/**
		 * Updates the given bundle.
		 * @param bundle the updated bundle
		 */
		void updateBundle(BundleInfo bundle) {
			this.gauges.computeIfPresent(bundle.getName(), (key, oldValue) -> oldValue.withBundle(bundle));
		}

		/**
		 * Manages the {@link MultiGauge MultiGauges} associated to a bundle.
		 *
		 * @param bundle the bundle
		 * @param multiGauges mapping from meter registry to {@link MultiGauge}
		 */
		private record Gauges(BundleInfo bundle, Map<MeterRegistry, MultiGauge> multiGauges) {

			/**
			 * Gets (or creates) the {@link MultiGauge} for the given meter registry.
			 * @param meterRegistry the meter registry
			 * @return the {@link MultiGauge}
			 */
			MultiGauge getGauge(MeterRegistry meterRegistry) {
				return this.multiGauges.computeIfAbsent(meterRegistry, (ignored) -> createGauge(meterRegistry));
			}

			/**
			 * Returns a copy of this bundle with an updated {@link BundleInfo}.
			 * @param bundle the updated {@link BundleInfo}
			 * @return the copy of this bundle with an updated {@link BundleInfo}
			 */
			Gauges withBundle(BundleInfo bundle) {
				return new Gauges(bundle, this.multiGauges);
			}

			private MultiGauge createGauge(MeterRegistry meterRegistry) {
				return MultiGauge.builder(CHAIN_EXPIRY_METRIC_NAME)
					.baseUnit("seconds")
					.description("SSL certificate chain expiry for key store and trust store chains")
					.register(meterRegistry);
			}

			/**
			 * Creates an instance with an empty gauge mapping.
			 * @param bundle the {@link BundleInfo} associated with the new instance
			 * @return the new instance
			 */
			static Gauges emptyGauges(BundleInfo bundle) {
				return new Gauges(bundle, new ConcurrentHashMap<>());
			}
		}

	}

}
