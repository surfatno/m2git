/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.micrometer.metrics.autoconfigure.export.prometheus;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.micrometer.metrics.export.prometheus.PrometheusPushGatewayManager.ShutdownOperation;

/**
 * {@link ConfigurationProperties @ConfigurationProperties} for configuring metrics export
 * to Prometheus.
 *
 * @author Jon Schneider
 * @author Stephane Nicoll
 * @since 4.0.0
 */
@ConfigurationProperties("management.prometheus.metrics.export")
public class PrometheusProperties {

	/**
	 * Whether exporting of metrics to this backend is enabled.
	 */
	private boolean enabled = true;

	/**
	 * Whether to enable publishing descriptions as part of the scrape payload to
	 * Prometheus. Turn this off to minimize the amount of data sent on each scrape.
	 */
	private boolean descriptions = true;

	/**
	 * Configuration options for using Prometheus Pushgateway, allowing metrics to be
	 * pushed when they cannot be scraped.
	 */
	private final Pushgateway pushgateway = new Pushgateway();

	/**
	 * Additional properties to pass to the Prometheus client.
	 */
	private final Map<String, String> properties = new LinkedHashMap<>();

	/**
	 * Step size (i.e. reporting frequency) to use.
	 */
	private Duration step = Duration.ofMinutes(1);

	public boolean isDescriptions() {
		return this.descriptions;
	}

	public void setDescriptions(boolean descriptions) {
		this.descriptions = descriptions;
	}

	public Duration getStep() {
		return this.step;
	}

	public void setStep(Duration step) {
		this.step = step;
	}

	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Pushgateway getPushgateway() {
		return this.pushgateway;
	}

	public Map<String, String> getProperties() {
		return this.properties;
	}

	/**
	 * Configuration options for push-based interaction with Prometheus.
	 */
	public static class Pushgateway {

		/**
		 * Enable publishing over a Prometheus Pushgateway.
		 */
		private boolean enabled;

		/**
		 * Address (host:port) for the Pushgateway.
		 */
		private String address = "localhost:9091";

		/**
		 * Scheme to use when pushing metrics.
		 */
		private Scheme scheme = Scheme.HTTP;

		/**
		 * Login user of the Prometheus Pushgateway.
		 */
		private @Nullable String username;

		/**
		 * Login password of the Prometheus Pushgateway.
		 */
		private @Nullable String password;

		/**
		 * Token to use for authentication with the Prometheus Pushgateway.
		 */
		private @Nullable String token;

		/**
		 * Format to use when pushing metrics.
		 */
		private Format format = Format.PROTOBUF;

		/**
		 * Frequency with which to push metrics.
		 */
		private Duration pushRate = Duration.ofMinutes(1);

		/**
		 * Job identifier for this application instance.
		 */
		private @Nullable String job;

		/**
		 * Grouping key for the pushed metrics.
		 */
		private Map<String, String> groupingKey = new LinkedHashMap<>();

		/**
		 * Operation that should be performed on shutdown.
		 */
		private ShutdownOperation shutdownOperation = ShutdownOperation.NONE;

		public boolean isEnabled() {
			return this.enabled;
		}

		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}

		public String getAddress() {
			return this.address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public @Nullable String getUsername() {
			return this.username;
		}

		public void setUsername(@Nullable String username) {
			this.username = username;
		}

		public @Nullable String getPassword() {
			return this.password;
		}

		public void setPassword(@Nullable String password) {
			this.password = password;
		}

		public Duration getPushRate() {
			return this.pushRate;
		}

		public void setPushRate(Duration pushRate) {
			this.pushRate = pushRate;
		}

		public @Nullable String getJob() {
			return this.job;
		}

		public void setJob(@Nullable String job) {
			this.job = job;
		}

		public Map<String, String> getGroupingKey() {
			return this.groupingKey;
		}

		public void setGroupingKey(Map<String, String> groupingKey) {
			this.groupingKey = groupingKey;
		}

		public ShutdownOperation getShutdownOperation() {
			return this.shutdownOperation;
		}

		public void setShutdownOperation(ShutdownOperation shutdownOperation) {
			this.shutdownOperation = shutdownOperation;
		}

		public Scheme getScheme() {
			return this.scheme;
		}

		public void setScheme(Scheme scheme) {
			this.scheme = scheme;
		}

		public @Nullable String getToken() {
			return this.token;
		}

		public void setToken(@Nullable String token) {
			this.token = token;
		}

		public Format getFormat() {
			return this.format;
		}

		public void setFormat(Format format) {
			this.format = format;
		}

		public enum Format {

			/**
			 * Push metrics in text format.
			 */
			TEXT,

			/**
			 * Push metrics in protobuf format.
			 */
			PROTOBUF

		}

		public enum Scheme {

			/**
			 * Use HTTP to push metrics.
			 */
			HTTP,

			/**
			 * Use HTTPS to push metrics.
			 */
			HTTPS

		}

	}

}
