/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.micrometer.metrics.autoconfigure.export.otlp;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import io.micrometer.registry.otlp.AggregationTemporality;
import io.micrometer.registry.otlp.CompressionMode;
import io.micrometer.registry.otlp.HistogramFlavor;
import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.micrometer.metrics.autoconfigure.export.properties.StepRegistryProperties;

/**
 * {@link ConfigurationProperties @ConfigurationProperties} for configuring OTLP metrics
 * export.
 *
 * @author Eddú Meléndez
 * @author Jonatan Ivanov
 * @since 4.0.0
 */
@ConfigurationProperties("management.otlp.metrics.export")
public class OtlpMetricsProperties extends StepRegistryProperties {

	/**
	 * URI of the OTLP server.
	 */
	private @Nullable String url;

	/**
	 * Aggregation temporality of sums. It defines the way additive values are expressed.
	 * This setting depends on the backend you use, some only support one temporality.
	 */
	private AggregationTemporality aggregationTemporality = AggregationTemporality.CUMULATIVE;

	/**
	 * Compression mode to use when exporting metrics.
	 */
	private @Nullable CompressionMode compressionMode;

	/**
	 * Headers for the exported metrics.
	 */
	private @Nullable Map<String, String> headers;

	/**
	 * Default histogram type when histogram publishing is enabled.
	 */
	private HistogramFlavor histogramFlavor = HistogramFlavor.EXPLICIT_BUCKET_HISTOGRAM;

	/**
	 * Whether to publish a separate gauge for the max value of histogram-based meters.
	 */
	private @Nullable Boolean publishMaxGaugeForHistograms;

	/**
	 * Max scale to use for exponential histograms, if configured.
	 */
	private int maxScale = 20;

	/**
	 * Default maximum number of buckets to be used for exponential histograms, if
	 * configured. This has no effect on explicit bucket histograms.
	 */
	private int maxBucketCount = 160;

	/**
	 * Time unit for exported metrics.
	 */
	private TimeUnit baseTimeUnit = TimeUnit.MILLISECONDS;

	/**
	 * Per-meter properties that can be used to override defaults.
	 */
	private final Map<String, Meter> meter = new LinkedHashMap<>();

	private final Ssl ssl = new Ssl();

	public @Nullable String getUrl() {
		return this.url;
	}

	public void setUrl(@Nullable String url) {
		this.url = url;
	}

	public AggregationTemporality getAggregationTemporality() {
		return this.aggregationTemporality;
	}

	public void setAggregationTemporality(AggregationTemporality aggregationTemporality) {
		this.aggregationTemporality = aggregationTemporality;
	}

	public @Nullable CompressionMode getCompressionMode() {
		return this.compressionMode;
	}

	public void setCompressionMode(@Nullable CompressionMode compressionMode) {
		this.compressionMode = compressionMode;
	}

	public @Nullable Map<String, String> getHeaders() {
		return this.headers;
	}

	public void setHeaders(@Nullable Map<String, String> headers) {
		this.headers = headers;
	}

	public HistogramFlavor getHistogramFlavor() {
		return this.histogramFlavor;
	}

	public void setHistogramFlavor(HistogramFlavor histogramFlavor) {
		this.histogramFlavor = histogramFlavor;
	}

	public @Nullable Boolean getPublishMaxGaugeForHistograms() {
		return this.publishMaxGaugeForHistograms;
	}

	public void setPublishMaxGaugeForHistograms(@Nullable Boolean publishMaxGaugeForHistograms) {
		this.publishMaxGaugeForHistograms = publishMaxGaugeForHistograms;
	}

	public int getMaxScale() {
		return this.maxScale;
	}

	public void setMaxScale(int maxScale) {
		this.maxScale = maxScale;
	}

	public int getMaxBucketCount() {
		return this.maxBucketCount;
	}

	public void setMaxBucketCount(int maxBucketCount) {
		this.maxBucketCount = maxBucketCount;
	}

	public TimeUnit getBaseTimeUnit() {
		return this.baseTimeUnit;
	}

	public void setBaseTimeUnit(TimeUnit baseTimeUnit) {
		this.baseTimeUnit = baseTimeUnit;
	}

	public Map<String, Meter> getMeter() {
		return this.meter;
	}

	public Ssl getSsl() {
		return this.ssl;
	}

	public static class Ssl {

		/**
		 * SSL bundle name.
		 */
		private @Nullable String bundle;

		public @Nullable String getBundle() {
			return this.bundle;
		}

		public void setBundle(@Nullable String bundle) {
			this.bundle = bundle;
		}

	}

	/**
	 * Per-meter settings.
	 */
	public static class Meter {

		/**
		 * Maximum number of buckets to be used for exponential histograms, if configured.
		 * This has no effect on explicit bucket histograms.
		 */
		private @Nullable Integer maxBucketCount;

		/**
		 * Histogram type when histogram publishing is enabled.
		 */
		private @Nullable HistogramFlavor histogramFlavor;

		public @Nullable Integer getMaxBucketCount() {
			return this.maxBucketCount;
		}

		public void setMaxBucketCount(@Nullable Integer maxBucketCount) {
			this.maxBucketCount = maxBucketCount;
		}

		public @Nullable HistogramFlavor getHistogramFlavor() {
			return this.histogramFlavor;
		}

		public void setHistogramFlavor(@Nullable HistogramFlavor histogramFlavor) {
			this.histogramFlavor = histogramFlavor;
		}

	}

}
