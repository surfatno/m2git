/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.micrometer.metrics.autoconfigure.export.ganglia;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import info.ganglia.gmetric4j.gmetric.GMetric;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * {@link ConfigurationProperties @ConfigurationProperties} for configuring Ganglia
 * metrics export.
 *
 * @author Jon Schneider
 * @author Stephane Nicoll
 * @since 4.0.0
 */
@ConfigurationProperties("management.ganglia.metrics.export")
public class GangliaProperties {

	/**
	 * Whether exporting of metrics to Ganglia is enabled.
	 */
	private boolean enabled = true;

	/**
	 * Step size (i.e. reporting frequency) to use.
	 */
	private Duration step = Duration.ofMinutes(1);

	/**
	 * Base time unit used to report durations.
	 */
	private TimeUnit durationUnits = TimeUnit.MILLISECONDS;

	/**
	 * UDP addressing mode, either unicast or multicast.
	 */
	private GMetric.UDPAddressingMode addressingMode = GMetric.UDPAddressingMode.MULTICAST;

	/**
	 * Time to live for metrics on Ganglia. Set the multicast Time-To-Live to be one
	 * greater than the number of hops (routers) between the hosts.
	 */
	private Integer timeToLive = 1;

	/**
	 * Host of the Ganglia server to receive exported metrics.
	 */
	private String host = "localhost";

	/**
	 * Port of the Ganglia server to receive exported metrics.
	 */
	private Integer port = 8649;

	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Duration getStep() {
		return this.step;
	}

	public void setStep(Duration step) {
		this.step = step;
	}

	public TimeUnit getDurationUnits() {
		return this.durationUnits;
	}

	public void setDurationUnits(TimeUnit durationUnits) {
		this.durationUnits = durationUnits;
	}

	public GMetric.UDPAddressingMode getAddressingMode() {
		return this.addressingMode;
	}

	public void setAddressingMode(GMetric.UDPAddressingMode addressingMode) {
		this.addressingMode = addressingMode;
	}

	public Integer getTimeToLive() {
		return this.timeToLive;
	}

	public void setTimeToLive(Integer timeToLive) {
		this.timeToLive = timeToLive;
	}

	public String getHost() {
		return this.host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Integer getPort() {
		return this.port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

}
