/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.micrometer.metrics.autoconfigure.export.humio;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.micrometer.metrics.autoconfigure.export.properties.StepRegistryProperties;

/**
 * {@link ConfigurationProperties @ConfigurationProperties} for configuring Humio metrics
 * export.
 *
 * @author Andy Wilkinson
 * @since 4.0.0
 */
@ConfigurationProperties("management.humio.metrics.export")
public class HumioProperties extends StepRegistryProperties {

	/**
	 * Humio API token.
	 */
	private @Nullable String apiToken;

	/**
	 * Connection timeout for requests to this backend.
	 */
	private Duration connectTimeout = Duration.ofSeconds(5);

	/**
	 * Humio tags describing the data source in which metrics will be stored. Humio tags
	 * are a distinct concept from Micrometer's tags. Micrometer's tags are used to divide
	 * metrics along dimensional boundaries.
	 */
	private Map<String, String> tags = new LinkedHashMap<>();

	/**
	 * URI to ship metrics to. If you need to publish metrics to an internal proxy
	 * en-route to Humio, you can define the location of the proxy with this.
	 */
	private String uri = "https://cloud.humio.com";

	public @Nullable String getApiToken() {
		return this.apiToken;
	}

	public void setApiToken(@Nullable String apiToken) {
		this.apiToken = apiToken;
	}

	@Override
	public Duration getConnectTimeout() {
		return this.connectTimeout;
	}

	@Override
	public void setConnectTimeout(Duration connectTimeout) {
		this.connectTimeout = connectTimeout;
	}

	public Map<String, String> getTags() {
		return this.tags;
	}

	public void setTags(Map<String, String> tags) {
		this.tags = tags;
	}

	public String getUri() {
		return this.uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}
