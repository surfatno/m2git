/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.data.metrics;

import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import io.micrometer.core.annotation.Timed;
import org.jspecify.annotations.Nullable;

import org.springframework.core.annotation.MergedAnnotationCollectors;
import org.springframework.core.annotation.MergedAnnotations;
import org.springframework.util.ConcurrentReferenceHashMap;

/**
 * Utility used to obtain {@link Timed @Timed} annotations from bean methods.
 *
 * @author Phillip Webb
 * @since 4.0.0
 */
public final class TimedAnnotations {

	private static final Map<AnnotatedElement, Set<Timed>> cache = new ConcurrentReferenceHashMap<>();

	private TimedAnnotations() {
	}

	/**
	 * Return {@link Timed} annotations that should be used for the given {@code method}
	 * and {@code type}.
	 * @param method the source method
	 * @param type the source type
	 * @return the {@link Timed} annotations to use or an empty set
	 */
	public static Set<Timed> get(Method method, Class<?> type) {
		Set<Timed> methodAnnotations = findTimedAnnotations(method);
		if (!methodAnnotations.isEmpty()) {
			return methodAnnotations;
		}
		return findTimedAnnotations(type);
	}

	private static Set<Timed> findTimedAnnotations(@Nullable AnnotatedElement element) {
		if (element == null) {
			return Collections.emptySet();
		}
		Set<Timed> result = cache.get(element);
		if (result != null) {
			return result;
		}
		MergedAnnotations annotations = MergedAnnotations.from(element);
		result = (!annotations.isPresent(Timed.class)) ? Collections.emptySet()
				: annotations.stream(Timed.class).collect(MergedAnnotationCollectors.toAnnotationSet());
		cache.put(element, result);
		return result;
	}

}
