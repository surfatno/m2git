/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.jpa.autoconfigure;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.orm.jpa.vendor.Database;

/**
 * External configuration properties for a JPA EntityManagerFactory created by Spring.
 *
 * @author Dave Syer
 * @author Andy Wilkinson
 * @author Stephane Nicoll
 * @author Eddú Meléndez
 * @author Madhura Bhave
 * @since 4.0.0
 */
@ConfigurationProperties("spring.jpa")
public class JpaProperties {

	/**
	 * Additional native properties to set on the JPA provider.
	 */
	private Map<String, String> properties = new LinkedHashMap<>();

	/**
	 * Mapping resources (equivalent to "mapping-file" entries in persistence.xml).
	 */
	private final List<String> mappingResources = new ArrayList<>();

	/**
	 * Name of the target database to operate on, auto-detected by default. Can be
	 * alternatively set using the "Database" enum.
	 */
	private @Nullable String databasePlatform;

	/**
	 * Target database to operate on, auto-detected by default. Can be alternatively set
	 * using the "databasePlatform" property.
	 */
	private @Nullable Database database;

	/**
	 * Whether to initialize the schema on startup.
	 */
	private boolean generateDdl;

	/**
	 * Whether to enable logging of SQL statements.
	 */
	private boolean showSql;

	/**
	 * Register OpenEntityManagerInViewInterceptor. Binds a JPA EntityManager to the
	 * thread for the entire processing of the request.
	 */
	private @Nullable Boolean openInView;

	/**
	 * Bootstrap method to use.
	 */
	private Bootstrap bootstrap = Bootstrap.DEFAULT;

	public Map<String, String> getProperties() {
		return this.properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}

	public List<String> getMappingResources() {
		return this.mappingResources;
	}

	public @Nullable String getDatabasePlatform() {
		return this.databasePlatform;
	}

	public void setDatabasePlatform(@Nullable String databasePlatform) {
		this.databasePlatform = databasePlatform;
	}

	public @Nullable Database getDatabase() {
		return this.database;
	}

	public void setDatabase(@Nullable Database database) {
		this.database = database;
	}

	public boolean isGenerateDdl() {
		return this.generateDdl;
	}

	public void setGenerateDdl(boolean generateDdl) {
		this.generateDdl = generateDdl;
	}

	public boolean isShowSql() {
		return this.showSql;
	}

	public void setShowSql(boolean showSql) {
		this.showSql = showSql;
	}

	public @Nullable Boolean getOpenInView() {
		return this.openInView;
	}

	public void setOpenInView(@Nullable Boolean openInView) {
		this.openInView = openInView;
	}

	public Bootstrap getBootstrap() {
		return this.bootstrap;
	}

	public void setBootstrap(Bootstrap bootstrap) {
		this.bootstrap = bootstrap;
	}

	/**
	 * Bootstrap methods that can be used with JPA.
	 */
	public enum Bootstrap {

		/**
		 * Default JPA bootstrapping.
		 */
		DEFAULT,

		/**
		 * Asynchronous JPA bootstrapping. The ApplicationContext must either have a
		 * single AsyncTaskExecutor bean, or an AsyncTaskExecutor bean named
		 * 'applicationTaskExecutor'.
		 */
		ASYNC

	}

}
