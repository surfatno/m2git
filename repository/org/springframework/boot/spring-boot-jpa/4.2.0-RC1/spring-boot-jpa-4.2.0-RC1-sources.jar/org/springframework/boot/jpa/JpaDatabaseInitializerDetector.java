/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.jpa;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import jakarta.persistence.EntityManagerFactory;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.boot.sql.init.dependency.AbstractBeansOfTypeDatabaseInitializerDetector;
import org.springframework.boot.sql.init.dependency.DatabaseInitializerDetector;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

/**
 * A {@link DatabaseInitializerDetector} for JPA.
 *
 * @author Andy Wilkinson
 */
class JpaDatabaseInitializerDetector extends AbstractBeansOfTypeDatabaseInitializerDetector {

	private final Environment environment;

	JpaDatabaseInitializerDetector(Environment environment) {
		this.environment = environment;
	}

	@Override
	protected Set<Class<?>> getDatabaseInitializerBeanTypes() {
		boolean deferred = this.environment.getProperty("spring.jpa.defer-datasource-initialization", boolean.class,
				false);
		return deferred ? Collections.singleton(EntityManagerFactory.class) : Collections.emptySet();
	}

	@Override
	public void detectionComplete(ConfigurableListableBeanFactory beanFactory, Set<String> dataSourceInitializerNames) {
		configureOtherInitializersToDependOnJpaInitializers(beanFactory, dataSourceInitializerNames);
	}

	private void configureOtherInitializersToDependOnJpaInitializers(ConfigurableListableBeanFactory beanFactory,
			Set<String> dataSourceInitializerNames) {
		Set<String> jpaInitializers = new HashSet<>();
		Set<String> otherInitializers = new HashSet<>(dataSourceInitializerNames);
		Iterator<String> iterator = otherInitializers.iterator();
		while (iterator.hasNext()) {
			String initializerName = iterator.next();
			BeanDefinition initializerDefinition = beanFactory.getBeanDefinition(initializerName);
			if (JpaDatabaseInitializerDetector.class.getName()
				.equals(initializerDefinition.getAttribute(DatabaseInitializerDetector.class.getName()))) {
				iterator.remove();
				jpaInitializers.add(initializerName);
			}
		}
		for (String otherInitializerName : otherInitializers) {
			BeanDefinition definition = beanFactory.getBeanDefinition(otherInitializerName);
			String[] dependencies = definition.getDependsOn();
			for (String dependencyName : jpaInitializers) {
				dependencies = StringUtils.addStringToArray(dependencies, dependencyName);
			}
			definition.setDependsOn(dependencies);
		}
	}

}
