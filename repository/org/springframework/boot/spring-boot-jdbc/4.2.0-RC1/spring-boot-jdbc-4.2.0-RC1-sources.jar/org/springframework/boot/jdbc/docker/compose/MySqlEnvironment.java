/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.jdbc.docker.compose;

import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * MySQL environment details.
 *
 * @author Moritz Halbritter
 * @author Andy Wilkinson
 * @author Phillip Webb
 * @author Scott Frederick
 */
class MySqlEnvironment {

	private final String username;

	private final String password;

	private final String database;

	MySqlEnvironment(Map<String, @Nullable String> env) {
		this.username = extractUsername(env);
		this.password = extractPassword(env);
		this.database = extractDatabase(env);
	}

	private static String extractUsername(Map<String, @Nullable String> env) {
		String result = env.get("MYSQL_USER");
		return (result != null) ? result : "root";
	}

	private String extractPassword(Map<String, @Nullable String> env) {
		Assert.state(!env.containsKey("MYSQL_RANDOM_ROOT_PASSWORD") || hasUserAndPassword(env),
				"MYSQL_RANDOM_ROOT_PASSWORD is not supported without MYSQL_USER and MYSQL_PASSWORD");
		boolean allowEmpty = env.containsKey("MYSQL_ALLOW_EMPTY_PASSWORD") || env.containsKey("ALLOW_EMPTY_PASSWORD");
		String password = env.get("MYSQL_PASSWORD");
		password = (password != null) ? password : env.get("MYSQL_ROOT_PASSWORD");
		Assert.state(StringUtils.hasLength(password) || allowEmpty, "No MySQL password found");
		return (password != null) ? password : "";
	}

	private boolean hasUserAndPassword(Map<String, @Nullable String> env) {
		return StringUtils.hasLength(env.get("MYSQL_USER")) && StringUtils.hasLength(env.get("MYSQL_PASSWORD"));
	}

	private String extractDatabase(Map<String, @Nullable String> env) {
		String database = env.get("MYSQL_DATABASE");
		Assert.state(database != null, "No MYSQL_DATABASE defined");
		return database;
	}

	String getUsername() {
		return this.username;
	}

	String getPassword() {
		return this.password;
	}

	String getDatabase() {
		return this.database;
	}

}
