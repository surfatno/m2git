/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.jdbc.autoconfigure;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;

/**
 * Abstract base class for DataSource bean post processors which apply values from
 * {@link JdbcConnectionDetails}. Property-based connection details
 * ({@link PropertiesJdbcConnectionDetails} are ignored as the expectation is that they
 * will have already been applied by configuration property binding. Acts on beans named
 * 'dataSource' of type {@code T}.
 *
 * @param <T> type of the datasource
 * @author Moritz Halbritter
 * @author Andy Wilkinson
 * @author Phillip Webb
 */
abstract class JdbcConnectionDetailsBeanPostProcessor<T> implements BeanPostProcessor, PriorityOrdered {

	private final Class<T> dataSourceClass;

	private final ObjectProvider<JdbcConnectionDetails> connectionDetailsProvider;

	JdbcConnectionDetailsBeanPostProcessor(Class<T> dataSourceClass,
			ObjectProvider<JdbcConnectionDetails> connectionDetailsProvider) {
		this.dataSourceClass = dataSourceClass;
		this.connectionDetailsProvider = connectionDetailsProvider;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		if (this.dataSourceClass.isInstance(bean) && "dataSource".equals(beanName)) {
			JdbcConnectionDetails connectionDetails = this.connectionDetailsProvider.getObject();
			if (!(connectionDetails instanceof PropertiesJdbcConnectionDetails)) {
				return processDataSource((T) bean, connectionDetails);
			}
		}
		return bean;
	}

	protected abstract Object processDataSource(T dataSource, JdbcConnectionDetails connectionDetails);

	@Override
	public int getOrder() {
		// Runs after ConfigurationPropertiesBindingPostProcessor
		return Ordered.HIGHEST_PRECEDENCE + 2;
	}

}
