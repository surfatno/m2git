/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.jdbc.docker.compose;

import java.util.Map;

import org.jspecify.annotations.Nullable;

import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

/**
 * Postgres environment details.
 *
 * @author Moritz Halbritter
 * @author Andy Wilkinson
 * @author Phillip Webb
 * @author Scott Frederick
 * @author Sidmar Theodoro
 * @author He Zean
 */
class PostgresEnvironment {

	private static final String[] USERNAME_KEYS = new String[] { "POSTGRES_USER", "POSTGRESQL_USER",
			"POSTGRESQL_USERNAME" };

	private static final String DEFAULT_USERNAME = "postgres";

	private static final String[] DATABASE_KEYS = new String[] { "POSTGRES_DB", "POSTGRESQL_DB",
			"POSTGRESQL_DATABASE" };

	private final String username;

	private final @Nullable String password;

	private final String database;

	PostgresEnvironment(Map<String, @Nullable String> env) {
		this.username = extract(env, USERNAME_KEYS, DEFAULT_USERNAME);
		this.password = extractPassword(env);
		this.database = extract(env, DATABASE_KEYS, this.username);
	}

	private String extract(Map<String, @Nullable String> env, String[] keys, String defaultValue) {
		for (String key : keys) {
			String value = env.get(key);
			if (value != null) {
				return value;
			}
		}
		return defaultValue;
	}

	private @Nullable String extractPassword(Map<String, @Nullable String> env) {
		if (isUsingTrustHostAuthMethod(env)) {
			return null;
		}
		String password = env.getOrDefault("POSTGRES_PASSWORD", env.get("POSTGRESQL_PASSWORD"));
		boolean allowEmpty = env.containsKey("ALLOW_EMPTY_PASSWORD");
		Assert.state(allowEmpty || StringUtils.hasLength(password), "No PostgreSQL password found");
		return (password != null) ? password : "";
	}

	private boolean isUsingTrustHostAuthMethod(Map<String, @Nullable String> env) {
		String hostAuthMethod = env.get("POSTGRES_HOST_AUTH_METHOD");
		return "trust".equals(hostAuthMethod);
	}

	String getUsername() {
		return this.username;
	}

	@Nullable String getPassword() {
		return this.password;
	}

	String getDatabase() {
		return this.database;
	}

}
