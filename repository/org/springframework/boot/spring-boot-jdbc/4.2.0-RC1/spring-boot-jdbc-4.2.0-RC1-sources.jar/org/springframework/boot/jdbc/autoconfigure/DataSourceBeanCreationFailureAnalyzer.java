/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.jdbc.autoconfigure;

import org.springframework.boot.diagnostics.AbstractFailureAnalyzer;
import org.springframework.boot.diagnostics.FailureAnalysis;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.jdbc.autoconfigure.DataSourceProperties.DataSourceBeanCreationException;
import org.springframework.core.env.Environment;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

/**
 * An {@link AbstractFailureAnalyzer} for failures caused by a
 * {@link DataSourceBeanCreationException}.
 *
 * @author Andy Wilkinson
 * @author Patryk Kostrzewa
 * @author Stephane Nicoll
 */
class DataSourceBeanCreationFailureAnalyzer extends AbstractFailureAnalyzer<DataSourceBeanCreationException> {

	private final Environment environment;

	DataSourceBeanCreationFailureAnalyzer(Environment environment) {
		this.environment = environment;
	}

	@Override
	protected FailureAnalysis analyze(Throwable rootFailure, DataSourceBeanCreationException cause) {
		return getFailureAnalysis(cause);
	}

	private FailureAnalysis getFailureAnalysis(DataSourceBeanCreationException cause) {
		String description = getDescription(cause);
		String action = getAction(cause);
		return new FailureAnalysis(description, action, cause);
	}

	private String getDescription(DataSourceBeanCreationException cause) {
		StringBuilder description = new StringBuilder();
		description.append("Failed to configure a DataSource: ");
		if (!StringUtils.hasText(cause.getProperties().getUrl())) {
			description.append("'url' attribute is not specified and ");
		}
		description.append(String.format("no embedded datasource could be configured.%n"));
		description.append(String.format("%nReason: %s%n", cause.getMessage()));
		return description.toString();
	}

	private String getAction(DataSourceBeanCreationException cause) {
		StringBuilder action = new StringBuilder();
		action.append(String.format("Consider the following:%n"));
		if (EmbeddedDatabaseConnection.NONE == cause.getConnection()) {
			action.append(String
				.format("\tIf you want an embedded database (H2, HSQL or Derby), please put it on the classpath.%n"));
		}
		else {
			action.append(String.format("\tReview the configuration of %s%n.", cause.getConnection()));
		}
		action
			.append("\tIf you have database settings to be loaded from a particular "
					+ "profile you may need to activate it")
			.append(getActiveProfiles());
		return action.toString();
	}

	private String getActiveProfiles() {
		StringBuilder message = new StringBuilder();
		String[] profiles = this.environment.getActiveProfiles();
		if (ObjectUtils.isEmpty(profiles)) {
			message.append(" (no profiles are currently active).");
		}
		else {
			message.append(" (the profiles ");
			message.append(StringUtils.arrayToCommaDelimitedString(profiles));
			message.append(" are currently active).");
		}
		return message.toString();
	}

}
