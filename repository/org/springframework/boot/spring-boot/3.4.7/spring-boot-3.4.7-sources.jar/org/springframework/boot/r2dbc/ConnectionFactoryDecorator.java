/*
 * Copyright 2012-2023 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.boot.r2dbc;

import io.r2dbc.spi.ConnectionFactory;

/**
 * Decorator for {@link ConnectionFactory connection factories}.
 *
 * @author Moritz Halbritter
 * @since 3.2.0
 * @see ConnectionFactoryBuilder
 */
@FunctionalInterface
public interface ConnectionFactoryDecorator {

	/**
	 * Decorates the given {@link ConnectionFactory}.
	 * @param delegate the connection factory which should be decorated
	 * @return the decorated connection factory
	 */
	ConnectionFactory decorate(ConnectionFactory delegate);

}
