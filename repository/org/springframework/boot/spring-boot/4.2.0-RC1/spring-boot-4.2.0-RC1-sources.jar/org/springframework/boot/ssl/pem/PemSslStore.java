/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.ssl.pem;

import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.List;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.io.ApplicationResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.Assert;

/**
 * An individual trust or key store that has been loaded from PEM content.
 *
 * @author Phillip Webb
 * @since 3.2.0
 * @see PemSslStoreDetails
 * @see PemContent
 */
public interface PemSslStore {

	/**
	 * The key store type, for example {@code JKS} or {@code PKCS11}. A {@code null} value
	 * will use {@link KeyStore#getDefaultType()}).
	 * @return the key store type
	 */
	@Nullable String type();

	/**
	 * The alias used when setting entries in the {@link KeyStore}.
	 * @return the alias
	 */
	@Nullable String alias();

	/**
	 * The password used when
	 * {@link KeyStore#setKeyEntry(String, java.security.Key, char[], java.security.cert.Certificate[])
	 * setting key entries} in the {@link KeyStore}.
	 * @return the password
	 */
	@Nullable String password();

	/**
	 * The certificates for this store. When a {@link #privateKey() private key} is
	 * present the returned value is treated as a certificate chain, otherwise it is
	 * treated a list of certificates that should all be registered.
	 * @return the X509 certificates
	 */
	@Nullable List<X509Certificate> certificates();

	/**
	 * The private key for this store or {@code null}.
	 * @return the private key
	 */
	@Nullable PrivateKey privateKey();

	/**
	 * Return a new {@link PemSslStore} instance with a new alias.
	 * @param alias the new alias
	 * @return a new {@link PemSslStore} instance
	 */
	default PemSslStore withAlias(@Nullable String alias) {
		List<X509Certificate> certificates = certificates();
		Assert.notNull(certificates, "'certificates' must not be null");
		return of(type(), alias, password(), certificates, privateKey());
	}

	/**
	 * Return a new {@link PemSslStore} instance with a new password.
	 * @param password the new password
	 * @return a new {@link PemSslStore} instance
	 */
	default PemSslStore withPassword(@Nullable String password) {
		List<X509Certificate> certificates = certificates();
		Assert.notNull(certificates, "'certificates' must not be null");
		return of(type(), alias(), password, certificates, privateKey());
	}

	/**
	 * Return a {@link PemSslStore} instance loaded using the given
	 * {@link PemSslStoreDetails}.
	 * @param details the PEM store details
	 * @return a loaded {@link PemSslStore} or {@code null}.
	 */
	static @Nullable PemSslStore load(@Nullable PemSslStoreDetails details) {
		return load(details, ApplicationResourceLoader.get());
	}

	/**
	 * Return a {@link PemSslStore} instance loaded using the given
	 * {@link PemSslStoreDetails}.
	 * @param details the PEM store details
	 * @param resourceLoader the resource loader used to load content
	 * @return a loaded {@link PemSslStore} or {@code null}.
	 * @since 3.3.5
	 */
	static @Nullable PemSslStore load(@Nullable PemSslStoreDetails details, ResourceLoader resourceLoader) {
		if (details == null || details.isEmpty()) {
			return null;
		}
		return new LoadedPemSslStore(details, resourceLoader);
	}

	/**
	 * Factory method that can be used to create a new {@link PemSslStore} with the given
	 * values.
	 * @param type the key store type
	 * @param certificates the certificates for this store
	 * @param privateKey the private key
	 * @return a new {@link PemSslStore} instance
	 */
	static PemSslStore of(@Nullable String type, List<X509Certificate> certificates, @Nullable PrivateKey privateKey) {
		return of(type, null, null, certificates, privateKey);
	}

	/**
	 * Factory method that can be used to create a new {@link PemSslStore} with the given
	 * values.
	 * @param certificates the certificates for this store
	 * @param privateKey the private key
	 * @return a new {@link PemSslStore} instance
	 */
	static PemSslStore of(List<X509Certificate> certificates, @Nullable PrivateKey privateKey) {
		return of(null, null, null, certificates, privateKey);
	}

	/**
	 * Factory method that can be used to create a new {@link PemSslStore} with the given
	 * values.
	 * @param type the key store type
	 * @param alias the alias used when setting entries in the {@link KeyStore}
	 * @param password the password used
	 * {@link KeyStore#setKeyEntry(String, java.security.Key, char[], java.security.cert.Certificate[])
	 * setting key entries} in the {@link KeyStore}
	 * @param certificates the certificates for this store
	 * @param privateKey the private key
	 * @return a new {@link PemSslStore} instance
	 */
	static PemSslStore of(@Nullable String type, @Nullable String alias, @Nullable String password,
			List<X509Certificate> certificates, @Nullable PrivateKey privateKey) {
		Assert.notEmpty(certificates, "'certificates' must not be empty");
		return new PemSslStore() {

			@Override
			public @Nullable String type() {
				return type;
			}

			@Override
			public @Nullable String alias() {
				return alias;
			}

			@Override
			public @Nullable String password() {
				return password;
			}

			@Override
			public List<X509Certificate> certificates() {
				return certificates;
			}

			@Override
			public @Nullable PrivateKey privateKey() {
				return privateKey;
			}

		};
	}

}
