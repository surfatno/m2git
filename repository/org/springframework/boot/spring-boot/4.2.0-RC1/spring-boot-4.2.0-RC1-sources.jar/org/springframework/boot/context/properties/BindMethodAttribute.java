/*
 * Copyright 2012-present the original author or authors.
 */

package org.springframework.boot.context.properties;

import org.jspecify.annotations.Nullable;

import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.context.properties.bind.BindMethod;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.AttributeAccessor;

/**
 * Allows a {@link BindMethod} value to be stored and retrieved from an
 * {@link AttributeAccessor}.
 *
 * @author Phillip Webb
 */
final class BindMethodAttribute {

	static final String NAME = BindMethod.class.getName();

	private BindMethodAttribute() {
	}

	static @Nullable BindMethod get(ApplicationContext applicationContext, String beanName) {
		return (applicationContext instanceof ConfigurableApplicationContext configurableApplicationContext)
				? get(configurableApplicationContext.getBeanFactory(), beanName) : null;
	}

	static @Nullable BindMethod get(ConfigurableListableBeanFactory beanFactory, String beanName) {
		return (!beanFactory.containsBeanDefinition(beanName)) ? null : get(beanFactory.getBeanDefinition(beanName));
	}

	static @Nullable BindMethod get(BeanDefinitionRegistry beanDefinitionRegistry, String beanName) {
		return (!beanDefinitionRegistry.containsBeanDefinition(beanName)) ? null
				: get(beanDefinitionRegistry.getBeanDefinition(beanName));
	}

	static @Nullable BindMethod get(AttributeAccessor attributes) {
		return (BindMethod) attributes.getAttribute(NAME);
	}

	static void set(AttributeAccessor attributes, BindMethod bindMethod) {
		attributes.setAttribute(NAME, bindMethod);
	}

}
