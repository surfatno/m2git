/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.orm.jpa.persistenceunit;

/**
 * Callback interface for post-processing a {@link MutablePersistenceUnitInfo}
 * configuration that Spring prepares for JPA persistence unit bootstrapping.
 *
 * <p>Implementations can be registered with a {@link DefaultPersistenceUnitManager}
 * or via a {@link org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean}.
 *
 * @author Juergen Hoeller
 * @since 2.0
 * @see DefaultPersistenceUnitManager#setPersistenceUnitPostProcessors
 * @see org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean#setPersistenceUnitPostProcessors
 */
public interface PersistenceUnitPostProcessor {

	/**
	 * Post-process the given {@link MutablePersistenceUnitInfo},
	 * for example registering further entity classes and jar files.
	 * @param pui the chosen persistence unit configuration, as read from
	 * {@code persistence.xml}. Passed in as MutablePersistenceUnitInfo.
	 */
	void postProcessPersistenceUnitInfo(MutablePersistenceUnitInfo pui);

}
