/*
 * Copyright 2014-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.data.jpa.repository.support;

import static org.springframework.data.jpa.util.BeanDefinitionUtils.*;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.util.function.BiPredicate;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.AutowireCandidateQualifier;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.Ordered;
import org.springframework.orm.jpa.SharedEntityManagerCreator;

/**
 * {@link BeanFactoryPostProcessor} to register a {@link SharedEntityManagerCreator} for every
 * {@link EntityManagerFactory} bean definition found in the application context to enable autowiring
 * {@link EntityManager} instances into constructor arguments. Adds the {@link EntityManagerFactory} bean name as
 * qualifier to the {@link EntityManager} {@link BeanDefinition} to enable explicit references in case of multiple
 * {@link EntityManagerFactory} instances.
 *
 * @author Oliver Gierke
 * @author Réda Housni Alaoui
 * @author Mark Paluch
 * @author Donghun Shin
 * @deprecated since 4.0, in favor of using either {@link org.springframework.orm.jpa.AbstractEntityManagerFactoryBean}
 *             that provides a shared {@link EntityManager} or using {@link SharedEntityManagerCreator} directly in your
 *             configuration.
 */
@Deprecated(since = "4.0")
public class EntityManagerBeanDefinitionRegistrarPostProcessor implements BeanFactoryPostProcessor, Ordered {

	private final BiPredicate<String, BeanDefinition> decoratorPredicate;

	public EntityManagerBeanDefinitionRegistrarPostProcessor() {
		this((beanName, beanDefinition) -> true);
	}

	/**
	 * Creates a new {@code EntityManagerBeanDefinitionRegistrarPostProcessor} allowing to filter which
	 * {@link EntityManagerFactory} beans should be decorated with a {@code SharedEntityManagerCreator}.
	 *
	 * @param decoratorPredicate the predicate to determine whether a given named {@link BeanDefinition} should be
	 *          decorated with a {@code SharedEntityManagerCreator}.
	 * @since 4.0
	 */
	public EntityManagerBeanDefinitionRegistrarPostProcessor(BiPredicate<String, BeanDefinition> decoratorPredicate) {
		this.decoratorPredicate = decoratorPredicate;
	}

	@Override
	public int getOrder() {
		return Ordered.HIGHEST_PRECEDENCE + 10;
	}

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {

		for (EntityManagerFactoryBeanDefinition definition : getEntityManagerFactoryBeanDefinitions(beanFactory,
				decoratorPredicate)) {

			BeanFactory definitionFactory = definition.getBeanFactory();

			if (!(definitionFactory instanceof BeanDefinitionRegistry definitionRegistry)) {
				continue;
			}

			String entityManagerBeanName = "jpaSharedEM_AWC_" + definition.getBeanName();

			if (!beanFactory.containsBeanDefinition(entityManagerBeanName)
					&& !definitionRegistry.containsBeanDefinition(entityManagerBeanName)) {

				BeanDefinitionBuilder builder = BeanDefinitionBuilder
						.rootBeanDefinition("org.springframework.orm.jpa.SharedEntityManagerCreator");
				builder.setFactoryMethod("createSharedEntityManager");
				builder.addConstructorArgReference(definition.getBeanName());

				AbstractBeanDefinition emBeanDefinition = builder.getRawBeanDefinition();

				emBeanDefinition.setPrimary(definition.getBeanDefinition().isPrimary());
				emBeanDefinition.addQualifier(new AutowireCandidateQualifier(Qualifier.class, definition.getBeanName()));
				emBeanDefinition.setScope(definition.getBeanDefinition().getScope());
				emBeanDefinition.setSource(definition.getBeanDefinition().getSource());
				emBeanDefinition.setLazyInit(true);

				definitionRegistry.registerBeanDefinition(entityManagerBeanName, emBeanDefinition);
			}
		}
	}
}
