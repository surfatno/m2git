// Generated from org/springframework/data/jpa/repository/query/Jpql.g4 by ANTLR 4.13.2
package org.springframework.data.jpa.repository.query;

/**
 * JPQL per https://jakarta.ee/specifications/persistence/3.1/jakarta-persistence-spec-3.1.html#bnf
 *
 * This is JPA BNF for JPQL. There are gaps and inconsistencies in the BNF itself, explained by other fragments of the spec.
 *
 * @see https://github.com/jakartaee/persistence/blob/master/spec/src/main/asciidoc/ch04-query-language.adoc#bnf
 * @author Greg Turnquist
 * @author Christoph Strobl
 * @author Jewoo Shin
 * @author Wantaek Choi
 * @since 3.1
 */


import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import org.jspecify.annotations.NullUnmarked;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import jakarta.annotation.Generated;


@NullUnmarked
@Generated("JpqlParser")
@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "NullAway"})
class JpqlParser extends Parser {
	// Customization: Suppress version check
	// static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, WS=17, 
		COMMENT=18, ABS=19, ALL=20, AND=21, ANY=22, AS=23, ASC=24, AVG=25, BETWEEN=26, 
		BOTH=27, BY=28, CASE=29, CAST=30, CEILING=31, COALESCE=32, CONCAT=33, 
		COUNT=34, CURRENT_DATE=35, CURRENT_TIME=36, CURRENT_TIMESTAMP=37, DATE=38, 
		DATETIME=39, DELETE=40, DESC=41, DISTINCT=42, DOUBLE=43, END=44, ELSE=45, 
		EMPTY=46, ENTRY=47, ESCAPE=48, EXCEPT=49, EXISTS=50, EXP=51, EXTRACT=52, 
		FALSE=53, FETCH=54, FIRST=55, FLOAT=56, FLOOR=57, FROM=58, FUNCTION=59, 
		GROUP=60, HAVING=61, ID=62, IN=63, INDEX=64, INNER=65, INTEGER=66, INTERSECT=67, 
		IS=68, JOIN=69, KEY=70, LAST=71, LEADING=72, LEFT=73, LENGTH=74, LIKE=75, 
		LN=76, LOCAL=77, LOCATE=78, LONG=79, LOWER=80, MAX=81, MEMBER=82, MIN=83, 
		MOD=84, NEW=85, NOT=86, NULL=87, NULLIF=88, NULLS=89, OBJECT=90, OF=91, 
		ON=92, OR=93, ORDER=94, OUTER=95, POWER=96, REGEXP=97, REPLACE=98, RIGHT=99, 
		ROUND=100, SELECT=101, SET=102, SIGN=103, SIZE=104, SOME=105, SQRT=106, 
		STRING=107, SUBSTRING=108, SUM=109, THEN=110, TIME=111, TRAILING=112, 
		TREAT=113, TRIM=114, TRUE=115, TYPE=116, UNION=117, UPDATE=118, UPPER=119, 
		VALUE=120, VERSION=121, WHEN=122, WHERE=123, EQUAL=124, NOT_EQUAL=125, 
		CHARACTER=126, IDENTIFICATION_VARIABLE=127, STRINGLITERAL=128, JAVASTRINGLITERAL=129, 
		FLOATLITERAL=130, INTLITERAL=131, LONGLITERAL=132, TIMESTAMP_ESCAPE_START=133, 
		DATE_ESCAPE_START=134, TIME_ESCAPE_START=135;
	public static final int
		RULE_start = 0, RULE_ql_statement = 1, RULE_select_statement = 2, RULE_setOperator = 3, 
		RULE_set_fuction = 4, RULE_update_statement = 5, RULE_delete_statement = 6, 
		RULE_from_clause = 7, RULE_identificationVariableDeclarationOrCollectionMemberDeclaration = 8, 
		RULE_identification_variable_declaration = 9, RULE_range_variable_declaration = 10, 
		RULE_join = 11, RULE_fetch_join = 12, RULE_join_spec = 13, RULE_join_condition = 14, 
		RULE_join_association_path_expression = 15, RULE_join_path_expression = 16, 
		RULE_collection_member_declaration = 17, RULE_qualified_identification_variable = 18, 
		RULE_map_field_identification_variable = 19, RULE_single_valued_path_expression = 20, 
		RULE_general_identification_variable = 21, RULE_general_subpath = 22, 
		RULE_simple_subpath = 23, RULE_treated_subpath = 24, RULE_state_field_path_expression = 25, 
		RULE_state_valued_path_expression = 26, RULE_single_valued_object_path_expression = 27, 
		RULE_collection_valued_path_expression = 28, RULE_update_clause = 29, 
		RULE_update_item = 30, RULE_new_value = 31, RULE_delete_clause = 32, RULE_select_clause = 33, 
		RULE_select_item = 34, RULE_select_expression = 35, RULE_constructor_expression = 36, 
		RULE_constructor_item = 37, RULE_aggregate_expression = 38, RULE_where_clause = 39, 
		RULE_groupby_clause = 40, RULE_groupby_item = 41, RULE_having_clause = 42, 
		RULE_orderby_clause = 43, RULE_orderby_item = 44, RULE_orderby_expression = 45, 
		RULE_nullsPrecedence = 46, RULE_subquery = 47, RULE_subquery_from_clause = 48, 
		RULE_subselect_identification_variable_declaration = 49, RULE_derived_path_expression = 50, 
		RULE_general_derived_path = 51, RULE_simple_derived_path = 52, RULE_treated_derived_path = 53, 
		RULE_derived_collection_member_declaration = 54, RULE_simple_select_clause = 55, 
		RULE_simple_select_expression = 56, RULE_scalar_expression = 57, RULE_conditional_expression = 58, 
		RULE_conditional_term = 59, RULE_conditional_factor = 60, RULE_conditional_primary = 61, 
		RULE_simple_cond_expression = 62, RULE_between_expression = 63, RULE_in_expression = 64, 
		RULE_in_item = 65, RULE_like_expression = 66, RULE_null_comparison_expression = 67, 
		RULE_empty_collection_comparison_expression = 68, RULE_collection_member_expression = 69, 
		RULE_entity_or_value_expression = 70, RULE_simple_entity_or_value_expression = 71, 
		RULE_exists_expression = 72, RULE_all_or_any_expression = 73, RULE_comparison_expression = 74, 
		RULE_comparison_operator = 75, RULE_arithmetic_expression = 76, RULE_arithmetic_term = 77, 
		RULE_arithmetic_factor = 78, RULE_arithmetic_primary = 79, RULE_string_expression = 80, 
		RULE_datetime_expression = 81, RULE_boolean_expression = 82, RULE_enum_expression = 83, 
		RULE_entity_expression = 84, RULE_simple_entity_expression = 85, RULE_entity_type_expression = 86, 
		RULE_type_discriminator = 87, RULE_functions_returning_numerics = 88, 
		RULE_functions_returning_datetime = 89, RULE_functions_returning_strings = 90, 
		RULE_trim_specification = 91, RULE_arithmetic_cast_function = 92, RULE_type_cast_function = 93, 
		RULE_string_cast_function = 94, RULE_entity_id_or_version_function = 95, 
		RULE_id_function = 96, RULE_version_function = 97, RULE_function_invocation = 98, 
		RULE_extract_datetime_field = 99, RULE_datetime_field = 100, RULE_extract_datetime_part = 101, 
		RULE_datetime_part = 102, RULE_function_arg = 103, RULE_case_expression = 104, 
		RULE_general_case_expression = 105, RULE_when_clause = 106, RULE_simple_case_expression = 107, 
		RULE_case_operand = 108, RULE_simple_when_clause = 109, RULE_coalesce_expression = 110, 
		RULE_nullif_expression = 111, RULE_trim_character = 112, RULE_identification_variable = 113, 
		RULE_constructor_name = 114, RULE_literal = 115, RULE_input_parameter = 116, 
		RULE_pattern_value = 117, RULE_date_time_timestamp_literal = 118, RULE_jdbc_date_literal = 119, 
		RULE_jdbc_time_literal = 120, RULE_jdbc_timestamp_literal = 121, RULE_jdbc_temporal_literal_text = 122, 
		RULE_entity_type_literal = 123, RULE_escape_character = 124, RULE_numeric_literal = 125, 
		RULE_type_literal = 126, RULE_boolean_literal = 127, RULE_enum_literal = 128, 
		RULE_string_literal = 129, RULE_single_valued_embeddable_object_field = 130, 
		RULE_subtype = 131, RULE_collection_valued_field = 132, RULE_single_valued_object_field = 133, 
		RULE_state_field = 134, RULE_collection_value_field = 135, RULE_entity_name = 136, 
		RULE_result_variable = 137, RULE_superquery_identification_variable = 138, 
		RULE_collection_valued_input_parameter = 139, RULE_single_valued_input_parameter = 140, 
		RULE_function_name = 141, RULE_character_valued_input_parameter = 142, 
		RULE_reserved_word = 143;
	private static String[] makeRuleNames() {
		return new String[] {
			"start", "ql_statement", "select_statement", "setOperator", "set_fuction", 
			"update_statement", "delete_statement", "from_clause", "identificationVariableDeclarationOrCollectionMemberDeclaration", 
			"identification_variable_declaration", "range_variable_declaration", 
			"join", "fetch_join", "join_spec", "join_condition", "join_association_path_expression", 
			"join_path_expression", "collection_member_declaration", "qualified_identification_variable", 
			"map_field_identification_variable", "single_valued_path_expression", 
			"general_identification_variable", "general_subpath", "simple_subpath", 
			"treated_subpath", "state_field_path_expression", "state_valued_path_expression", 
			"single_valued_object_path_expression", "collection_valued_path_expression", 
			"update_clause", "update_item", "new_value", "delete_clause", "select_clause", 
			"select_item", "select_expression", "constructor_expression", "constructor_item", 
			"aggregate_expression", "where_clause", "groupby_clause", "groupby_item", 
			"having_clause", "orderby_clause", "orderby_item", "orderby_expression", 
			"nullsPrecedence", "subquery", "subquery_from_clause", "subselect_identification_variable_declaration", 
			"derived_path_expression", "general_derived_path", "simple_derived_path", 
			"treated_derived_path", "derived_collection_member_declaration", "simple_select_clause", 
			"simple_select_expression", "scalar_expression", "conditional_expression", 
			"conditional_term", "conditional_factor", "conditional_primary", "simple_cond_expression", 
			"between_expression", "in_expression", "in_item", "like_expression", 
			"null_comparison_expression", "empty_collection_comparison_expression", 
			"collection_member_expression", "entity_or_value_expression", "simple_entity_or_value_expression", 
			"exists_expression", "all_or_any_expression", "comparison_expression", 
			"comparison_operator", "arithmetic_expression", "arithmetic_term", "arithmetic_factor", 
			"arithmetic_primary", "string_expression", "datetime_expression", "boolean_expression", 
			"enum_expression", "entity_expression", "simple_entity_expression", "entity_type_expression", 
			"type_discriminator", "functions_returning_numerics", "functions_returning_datetime", 
			"functions_returning_strings", "trim_specification", "arithmetic_cast_function", 
			"type_cast_function", "string_cast_function", "entity_id_or_version_function", 
			"id_function", "version_function", "function_invocation", "extract_datetime_field", 
			"datetime_field", "extract_datetime_part", "datetime_part", "function_arg", 
			"case_expression", "general_case_expression", "when_clause", "simple_case_expression", 
			"case_operand", "simple_when_clause", "coalesce_expression", "nullif_expression", 
			"trim_character", "identification_variable", "constructor_name", "literal", 
			"input_parameter", "pattern_value", "date_time_timestamp_literal", "jdbc_date_literal", 
			"jdbc_time_literal", "jdbc_timestamp_literal", "jdbc_temporal_literal_text", 
			"entity_type_literal", "escape_character", "numeric_literal", "type_literal", 
			"boolean_literal", "enum_literal", "string_literal", "single_valued_embeddable_object_field", 
			"subtype", "collection_valued_field", "single_valued_object_field", "state_field", 
			"collection_value_field", "entity_name", "result_variable", "superquery_identification_variable", 
			"collection_valued_input_parameter", "single_valued_input_parameter", 
			"function_name", "character_valued_input_parameter", "reserved_word"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'('", "')'", "'.'", "'>'", "'>='", "'<'", "'<='", "'+'", 
			"'-'", "'*'", "'/'", "'||'", "'?'", "':'", "'}'", null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, "'='"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, "WS", "COMMENT", "ABS", "ALL", "AND", "ANY", 
			"AS", "ASC", "AVG", "BETWEEN", "BOTH", "BY", "CASE", "CAST", "CEILING", 
			"COALESCE", "CONCAT", "COUNT", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", 
			"DATE", "DATETIME", "DELETE", "DESC", "DISTINCT", "DOUBLE", "END", "ELSE", 
			"EMPTY", "ENTRY", "ESCAPE", "EXCEPT", "EXISTS", "EXP", "EXTRACT", "FALSE", 
			"FETCH", "FIRST", "FLOAT", "FLOOR", "FROM", "FUNCTION", "GROUP", "HAVING", 
			"ID", "IN", "INDEX", "INNER", "INTEGER", "INTERSECT", "IS", "JOIN", "KEY", 
			"LAST", "LEADING", "LEFT", "LENGTH", "LIKE", "LN", "LOCAL", "LOCATE", 
			"LONG", "LOWER", "MAX", "MEMBER", "MIN", "MOD", "NEW", "NOT", "NULL", 
			"NULLIF", "NULLS", "OBJECT", "OF", "ON", "OR", "ORDER", "OUTER", "POWER", 
			"REGEXP", "REPLACE", "RIGHT", "ROUND", "SELECT", "SET", "SIGN", "SIZE", 
			"SOME", "SQRT", "STRING", "SUBSTRING", "SUM", "THEN", "TIME", "TRAILING", 
			"TREAT", "TRIM", "TRUE", "TYPE", "UNION", "UPDATE", "UPPER", "VALUE", 
			"VERSION", "WHEN", "WHERE", "EQUAL", "NOT_EQUAL", "CHARACTER", "IDENTIFICATION_VARIABLE", 
			"STRINGLITERAL", "JAVASTRINGLITERAL", "FLOATLITERAL", "INTLITERAL", "LONGLITERAL", 
			"TIMESTAMP_ESCAPE_START", "DATE_ESCAPE_START", "TIME_ESCAPE_START"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Jpql.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public JpqlParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StartContext extends ParserRuleContext {
		public Ql_statementContext ql_statement() {
			return getRuleContext(Ql_statementContext.class,0);
		}
		public TerminalNode EOF() { return getToken(JpqlParser.EOF, 0); }
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(288);
			ql_statement();
			setState(289);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Ql_statementContext extends ParserRuleContext {
		public Select_statementContext select_statement() {
			return getRuleContext(Select_statementContext.class,0);
		}
		public Update_statementContext update_statement() {
			return getRuleContext(Update_statementContext.class,0);
		}
		public Delete_statementContext delete_statement() {
			return getRuleContext(Delete_statementContext.class,0);
		}
		public Ql_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ql_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterQl_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitQl_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitQl_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ql_statementContext ql_statement() throws RecognitionException {
		Ql_statementContext _localctx = new Ql_statementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_ql_statement);
		try {
			setState(294);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case FROM:
			case SELECT:
				enterOuterAlt(_localctx, 1);
				{
				setState(291);
				select_statement();
				}
				break;
			case UPDATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(292);
				update_statement();
				}
				break;
			case DELETE:
				enterOuterAlt(_localctx, 3);
				{
				setState(293);
				delete_statement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_statementContext extends ParserRuleContext {
		public Select_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_statement; }
	 
		public Select_statementContext() { }
		public void copyFrom(Select_statementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class SelectQueryContext extends Select_statementContext {
		public Select_clauseContext select_clause() {
			return getRuleContext(Select_clauseContext.class,0);
		}
		public From_clauseContext from_clause() {
			return getRuleContext(From_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Groupby_clauseContext groupby_clause() {
			return getRuleContext(Groupby_clauseContext.class,0);
		}
		public Having_clauseContext having_clause() {
			return getRuleContext(Having_clauseContext.class,0);
		}
		public Orderby_clauseContext orderby_clause() {
			return getRuleContext(Orderby_clauseContext.class,0);
		}
		public Set_fuctionContext set_fuction() {
			return getRuleContext(Set_fuctionContext.class,0);
		}
		public SelectQueryContext(Select_statementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelectQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelectQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelectQuery(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class FromQueryContext extends Select_statementContext {
		public From_clauseContext from_clause() {
			return getRuleContext(From_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Groupby_clauseContext groupby_clause() {
			return getRuleContext(Groupby_clauseContext.class,0);
		}
		public Having_clauseContext having_clause() {
			return getRuleContext(Having_clauseContext.class,0);
		}
		public Orderby_clauseContext orderby_clause() {
			return getRuleContext(Orderby_clauseContext.class,0);
		}
		public Set_fuctionContext set_fuction() {
			return getRuleContext(Set_fuctionContext.class,0);
		}
		public FromQueryContext(Select_statementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFromQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFromQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFromQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_statementContext select_statement() throws RecognitionException {
		Select_statementContext _localctx = new Select_statementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_select_statement);
		int _la;
		try {
			setState(329);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SELECT:
				_localctx = new SelectQueryContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(296);
				select_clause();
				setState(297);
				from_clause();
				setState(299);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(298);
					where_clause();
					}
				}

				setState(302);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GROUP) {
					{
					setState(301);
					groupby_clause();
					}
				}

				setState(305);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(304);
					having_clause();
					}
				}

				setState(308);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ORDER) {
					{
					setState(307);
					orderby_clause();
					}
				}

				setState(311);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXCEPT || _la==INTERSECT || _la==UNION) {
					{
					setState(310);
					set_fuction();
					}
				}

				}
				break;
			case FROM:
				_localctx = new FromQueryContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(313);
				from_clause();
				setState(315);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHERE) {
					{
					setState(314);
					where_clause();
					}
				}

				setState(318);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==GROUP) {
					{
					setState(317);
					groupby_clause();
					}
				}

				setState(321);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==HAVING) {
					{
					setState(320);
					having_clause();
					}
				}

				setState(324);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ORDER) {
					{
					setState(323);
					orderby_clause();
					}
				}

				setState(327);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==EXCEPT || _la==INTERSECT || _la==UNION) {
					{
					setState(326);
					set_fuction();
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SetOperatorContext extends ParserRuleContext {
		public TerminalNode UNION() { return getToken(JpqlParser.UNION, 0); }
		public TerminalNode ALL() { return getToken(JpqlParser.ALL, 0); }
		public TerminalNode INTERSECT() { return getToken(JpqlParser.INTERSECT, 0); }
		public TerminalNode EXCEPT() { return getToken(JpqlParser.EXCEPT, 0); }
		public SetOperatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_setOperator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSetOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSetOperator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSetOperator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SetOperatorContext setOperator() throws RecognitionException {
		SetOperatorContext _localctx = new SetOperatorContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_setOperator);
		int _la;
		try {
			setState(343);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case UNION:
				enterOuterAlt(_localctx, 1);
				{
				setState(331);
				match(UNION);
				setState(333);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(332);
					match(ALL);
					}
				}

				}
				break;
			case INTERSECT:
				enterOuterAlt(_localctx, 2);
				{
				setState(335);
				match(INTERSECT);
				setState(337);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(336);
					match(ALL);
					}
				}

				}
				break;
			case EXCEPT:
				enterOuterAlt(_localctx, 3);
				{
				setState(339);
				match(EXCEPT);
				setState(341);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==ALL) {
					{
					setState(340);
					match(ALL);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Set_fuctionContext extends ParserRuleContext {
		public SetOperatorContext setOperator() {
			return getRuleContext(SetOperatorContext.class,0);
		}
		public Select_statementContext select_statement() {
			return getRuleContext(Select_statementContext.class,0);
		}
		public Set_fuctionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_set_fuction; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSet_fuction(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSet_fuction(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSet_fuction(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Set_fuctionContext set_fuction() throws RecognitionException {
		Set_fuctionContext _localctx = new Set_fuctionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_set_fuction);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(345);
			setOperator();
			setState(346);
			select_statement();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Update_statementContext extends ParserRuleContext {
		public Update_clauseContext update_clause() {
			return getRuleContext(Update_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Update_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_update_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterUpdate_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitUpdate_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitUpdate_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Update_statementContext update_statement() throws RecognitionException {
		Update_statementContext _localctx = new Update_statementContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_update_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(348);
			update_clause();
			setState(350);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(349);
				where_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Delete_statementContext extends ParserRuleContext {
		public Delete_clauseContext delete_clause() {
			return getRuleContext(Delete_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Delete_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delete_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDelete_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDelete_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDelete_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Delete_statementContext delete_statement() throws RecognitionException {
		Delete_statementContext _localctx = new Delete_statementContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_delete_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(352);
			delete_clause();
			setState(354);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(353);
				where_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class From_clauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Identification_variable_declarationContext identification_variable_declaration() {
			return getRuleContext(Identification_variable_declarationContext.class,0);
		}
		public List<IdentificationVariableDeclarationOrCollectionMemberDeclarationContext> identificationVariableDeclarationOrCollectionMemberDeclaration() {
			return getRuleContexts(IdentificationVariableDeclarationOrCollectionMemberDeclarationContext.class);
		}
		public IdentificationVariableDeclarationOrCollectionMemberDeclarationContext identificationVariableDeclarationOrCollectionMemberDeclaration(int i) {
			return getRuleContext(IdentificationVariableDeclarationOrCollectionMemberDeclarationContext.class,i);
		}
		public From_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_from_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFrom_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFrom_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFrom_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final From_clauseContext from_clause() throws RecognitionException {
		From_clauseContext _localctx = new From_clauseContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_from_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(356);
			match(FROM);
			setState(357);
			identification_variable_declaration();
			setState(362);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(358);
				match(T__0);
				setState(359);
				identificationVariableDeclarationOrCollectionMemberDeclaration();
				}
				}
				setState(364);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentificationVariableDeclarationOrCollectionMemberDeclarationContext extends ParserRuleContext {
		public Identification_variable_declarationContext identification_variable_declaration() {
			return getRuleContext(Identification_variable_declarationContext.class,0);
		}
		public Collection_member_declarationContext collection_member_declaration() {
			return getRuleContext(Collection_member_declarationContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public IdentificationVariableDeclarationOrCollectionMemberDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identificationVariableDeclarationOrCollectionMemberDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIdentificationVariableDeclarationOrCollectionMemberDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIdentificationVariableDeclarationOrCollectionMemberDeclaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIdentificationVariableDeclarationOrCollectionMemberDeclaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentificationVariableDeclarationOrCollectionMemberDeclarationContext identificationVariableDeclarationOrCollectionMemberDeclaration() throws RecognitionException {
		IdentificationVariableDeclarationOrCollectionMemberDeclarationContext _localctx = new IdentificationVariableDeclarationOrCollectionMemberDeclarationContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_identificationVariableDeclarationOrCollectionMemberDeclaration);
		try {
			setState(376);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(365);
				identification_variable_declaration();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(366);
				collection_member_declaration();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(367);
				match(T__1);
				setState(368);
				subquery();
				setState(369);
				match(T__2);
				setState(374);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,20,_ctx) ) {
				case 1:
					{
					setState(371);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,19,_ctx) ) {
					case 1:
						{
						setState(370);
						match(AS);
						}
						break;
					}
					setState(373);
					identification_variable();
					}
					break;
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Identification_variable_declarationContext extends ParserRuleContext {
		public Range_variable_declarationContext range_variable_declaration() {
			return getRuleContext(Range_variable_declarationContext.class,0);
		}
		public List<JoinContext> join() {
			return getRuleContexts(JoinContext.class);
		}
		public JoinContext join(int i) {
			return getRuleContext(JoinContext.class,i);
		}
		public List<Fetch_joinContext> fetch_join() {
			return getRuleContexts(Fetch_joinContext.class);
		}
		public Fetch_joinContext fetch_join(int i) {
			return getRuleContext(Fetch_joinContext.class,i);
		}
		public Identification_variable_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identification_variable_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIdentification_variable_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIdentification_variable_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIdentification_variable_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Identification_variable_declarationContext identification_variable_declaration() throws RecognitionException {
		Identification_variable_declarationContext _localctx = new Identification_variable_declarationContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_identification_variable_declaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(378);
			range_variable_declaration();
			setState(383);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 273L) != 0)) {
				{
				setState(381);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
				case 1:
					{
					setState(379);
					join();
					}
					break;
				case 2:
					{
					setState(380);
					fetch_join();
					}
					break;
				}
				}
				setState(385);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Range_variable_declarationContext extends ParserRuleContext {
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Range_variable_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_range_variable_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterRange_variable_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitRange_variable_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitRange_variable_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Range_variable_declarationContext range_variable_declaration() throws RecognitionException {
		Range_variable_declarationContext _localctx = new Range_variable_declarationContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_range_variable_declaration);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(386);
			entity_name();
			setState(391);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,25,_ctx) ) {
			case 1:
				{
				setState(388);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
				case 1:
					{
					setState(387);
					match(AS);
					}
					break;
				}
				setState(390);
				identification_variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinContext extends ParserRuleContext {
		public Join_specContext join_spec() {
			return getRuleContext(Join_specContext.class,0);
		}
		public Join_association_path_expressionContext join_association_path_expression() {
			return getRuleContext(Join_association_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Join_conditionContext join_condition() {
			return getRuleContext(Join_conditionContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public JoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinContext join() throws RecognitionException {
		JoinContext _localctx = new JoinContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_join);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(393);
			join_spec();
			setState(394);
			join_association_path_expression();
			setState(399);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
			case 1:
				{
				setState(396);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,26,_ctx) ) {
				case 1:
					{
					setState(395);
					match(AS);
					}
					break;
				}
				setState(398);
				identification_variable();
				}
				break;
			}
			setState(402);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(401);
				join_condition();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Fetch_joinContext extends ParserRuleContext {
		public Join_specContext join_spec() {
			return getRuleContext(Join_specContext.class,0);
		}
		public TerminalNode FETCH() { return getToken(JpqlParser.FETCH, 0); }
		public Join_association_path_expressionContext join_association_path_expression() {
			return getRuleContext(Join_association_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Join_conditionContext join_condition() {
			return getRuleContext(Join_conditionContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Fetch_joinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fetch_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFetch_join(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFetch_join(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFetch_join(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Fetch_joinContext fetch_join() throws RecognitionException {
		Fetch_joinContext _localctx = new Fetch_joinContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_fetch_join);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(404);
			join_spec();
			setState(405);
			match(FETCH);
			setState(406);
			join_association_path_expression();
			setState(411);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,30,_ctx) ) {
			case 1:
				{
				setState(408);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,29,_ctx) ) {
				case 1:
					{
					setState(407);
					match(AS);
					}
					break;
				}
				setState(410);
				identification_variable();
				}
				break;
			}
			setState(414);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(413);
				join_condition();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_specContext extends ParserRuleContext {
		public TerminalNode JOIN() { return getToken(JpqlParser.JOIN, 0); }
		public TerminalNode INNER() { return getToken(JpqlParser.INNER, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode OUTER() { return getToken(JpqlParser.OUTER, 0); }
		public Join_specContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_spec; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_spec(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_spec(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_spec(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_specContext join_spec() throws RecognitionException {
		Join_specContext _localctx = new Join_specContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_join_spec);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(421);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LEFT:
				{
				{
				setState(416);
				match(LEFT);
				setState(418);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==OUTER) {
					{
					setState(417);
					match(OUTER);
					}
				}

				}
				}
				break;
			case INNER:
				{
				setState(420);
				match(INNER);
				}
				break;
			case JOIN:
				break;
			default:
				break;
			}
			setState(423);
			match(JOIN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_conditionContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(JpqlParser.ON, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Join_conditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_condition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_condition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_condition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_condition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_conditionContext join_condition() throws RecognitionException {
		Join_conditionContext _localctx = new Join_conditionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_join_condition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(425);
			match(ON);
			setState(426);
			conditional_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_association_path_expressionContext extends ParserRuleContext {
		public Join_path_expressionContext join_path_expression() {
			return getRuleContext(Join_path_expressionContext.class,0);
		}
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public Join_association_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_association_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_association_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_association_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_association_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_association_path_expressionContext join_association_path_expression() throws RecognitionException {
		Join_association_path_expressionContext _localctx = new Join_association_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_join_association_path_expression);
		try {
			setState(436);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,34,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(428);
				join_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(429);
				match(TREAT);
				setState(430);
				match(T__1);
				setState(431);
				join_path_expression();
				setState(432);
				match(AS);
				setState(433);
				subtype();
				setState(434);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_path_expressionContext extends ParserRuleContext {
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public List<Single_valued_embeddable_object_fieldContext> single_valued_embeddable_object_field() {
			return getRuleContexts(Single_valued_embeddable_object_fieldContext.class);
		}
		public Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field(int i) {
			return getRuleContext(Single_valued_embeddable_object_fieldContext.class,i);
		}
		public Join_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_path_expressionContext join_path_expression() throws RecognitionException {
		Join_path_expressionContext _localctx = new Join_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_join_path_expression);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(441);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,35,_ctx) ) {
			case 1:
				{
				setState(438);
				identification_variable();
				setState(439);
				match(T__3);
				}
				break;
			}
			setState(448);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,36,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(443);
					single_valued_embeddable_object_field();
					setState(444);
					match(T__3);
					}
					} 
				}
				setState(450);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,36,_ctx);
			}
			setState(451);
			single_valued_object_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_member_declarationContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Collection_member_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_member_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_member_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_member_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_member_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_member_declarationContext collection_member_declaration() throws RecognitionException {
		Collection_member_declarationContext _localctx = new Collection_member_declarationContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_collection_member_declaration);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(453);
			match(IN);
			setState(454);
			match(T__1);
			setState(455);
			collection_valued_path_expression();
			setState(456);
			match(T__2);
			setState(461);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,38,_ctx) ) {
			case 1:
				{
				setState(458);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
				case 1:
					{
					setState(457);
					match(AS);
					}
					break;
				}
				setState(460);
				identification_variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Qualified_identification_variableContext extends ParserRuleContext {
		public Map_field_identification_variableContext map_field_identification_variable() {
			return getRuleContext(Map_field_identification_variableContext.class,0);
		}
		public TerminalNode ENTRY() { return getToken(JpqlParser.ENTRY, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Qualified_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_qualified_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterQualified_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitQualified_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitQualified_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Qualified_identification_variableContext qualified_identification_variable() throws RecognitionException {
		Qualified_identification_variableContext _localctx = new Qualified_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_qualified_identification_variable);
		try {
			setState(469);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KEY:
			case VALUE:
				enterOuterAlt(_localctx, 1);
				{
				setState(463);
				map_field_identification_variable();
				}
				break;
			case ENTRY:
				enterOuterAlt(_localctx, 2);
				{
				setState(464);
				match(ENTRY);
				setState(465);
				match(T__1);
				setState(466);
				identification_variable();
				setState(467);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Map_field_identification_variableContext extends ParserRuleContext {
		public TerminalNode KEY() { return getToken(JpqlParser.KEY, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode VALUE() { return getToken(JpqlParser.VALUE, 0); }
		public Map_field_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_map_field_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterMap_field_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitMap_field_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitMap_field_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Map_field_identification_variableContext map_field_identification_variable() throws RecognitionException {
		Map_field_identification_variableContext _localctx = new Map_field_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_map_field_identification_variable);
		try {
			setState(481);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KEY:
				enterOuterAlt(_localctx, 1);
				{
				setState(471);
				match(KEY);
				setState(472);
				match(T__1);
				setState(473);
				identification_variable();
				setState(474);
				match(T__2);
				}
				break;
			case VALUE:
				enterOuterAlt(_localctx, 2);
				{
				setState(476);
				match(VALUE);
				setState(477);
				match(T__1);
				setState(478);
				identification_variable();
				setState(479);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_path_expressionContext extends ParserRuleContext {
		public Qualified_identification_variableContext qualified_identification_variable() {
			return getRuleContext(Qualified_identification_variableContext.class,0);
		}
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Single_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_path_expressionContext single_valued_path_expression() throws RecognitionException {
		Single_valued_path_expressionContext _localctx = new Single_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_single_valued_path_expression);
		try {
			setState(493);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(483);
				qualified_identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(484);
				match(TREAT);
				setState(485);
				match(T__1);
				setState(486);
				qualified_identification_variable();
				setState(487);
				match(AS);
				setState(488);
				subtype();
				setState(489);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(491);
				state_field_path_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(492);
				single_valued_object_path_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_identification_variableContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Map_field_identification_variableContext map_field_identification_variable() {
			return getRuleContext(Map_field_identification_variableContext.class,0);
		}
		public General_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_identification_variableContext general_identification_variable() throws RecognitionException {
		General_identification_variableContext _localctx = new General_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_general_identification_variable);
		try {
			setState(497);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,42,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(495);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(496);
				map_field_identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_subpathContext extends ParserRuleContext {
		public Simple_subpathContext simple_subpath() {
			return getRuleContext(Simple_subpathContext.class,0);
		}
		public Treated_subpathContext treated_subpath() {
			return getRuleContext(Treated_subpathContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public General_subpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_subpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_subpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_subpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_subpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_subpathContext general_subpath() throws RecognitionException {
		General_subpathContext _localctx = new General_subpathContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_general_subpath);
		try {
			int _alt;
			setState(508);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AS:
			case COUNT:
			case DATE:
			case DOUBLE:
			case FLOAT:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case INTEGER:
			case KEY:
			case LEFT:
			case LONG:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case STRING:
			case TIME:
			case TYPE:
			case VALUE:
			case VERSION:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(499);
				simple_subpath();
				}
				break;
			case TREAT:
				enterOuterAlt(_localctx, 2);
				{
				setState(500);
				treated_subpath();
				setState(505);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,43,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(501);
						match(T__3);
						setState(502);
						single_valued_object_field();
						}
						} 
					}
					setState(507);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,43,_ctx);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_subpathContext extends ParserRuleContext {
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public Simple_subpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_subpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_subpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_subpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_subpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_subpathContext simple_subpath() throws RecognitionException {
		Simple_subpathContext _localctx = new Simple_subpathContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_simple_subpath);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(510);
			general_identification_variable();
			setState(515);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,45,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(511);
					match(T__3);
					setState(512);
					single_valued_object_field();
					}
					} 
				}
				setState(517);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,45,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Treated_subpathContext extends ParserRuleContext {
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public Treated_subpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_treated_subpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTreated_subpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTreated_subpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTreated_subpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Treated_subpathContext treated_subpath() throws RecognitionException {
		Treated_subpathContext _localctx = new Treated_subpathContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_treated_subpath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(518);
			match(TREAT);
			setState(519);
			match(T__1);
			setState(520);
			general_subpath();
			setState(521);
			match(AS);
			setState(522);
			subtype();
			setState(523);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_field_path_expressionContext extends ParserRuleContext {
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public State_fieldContext state_field() {
			return getRuleContext(State_fieldContext.class,0);
		}
		public State_field_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_field_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterState_field_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitState_field_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitState_field_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_field_path_expressionContext state_field_path_expression() throws RecognitionException {
		State_field_path_expressionContext _localctx = new State_field_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_state_field_path_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(525);
			general_subpath();
			setState(526);
			match(T__3);
			setState(527);
			state_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_valued_path_expressionContext extends ParserRuleContext {
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public State_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterState_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitState_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitState_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_valued_path_expressionContext state_valued_path_expression() throws RecognitionException {
		State_valued_path_expressionContext _localctx = new State_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_state_valued_path_expression);
		try {
			setState(531);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,46,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(529);
				state_field_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(530);
				general_identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_object_path_expressionContext extends ParserRuleContext {
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Single_valued_object_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_object_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_object_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_object_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_object_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_object_path_expressionContext single_valued_object_path_expression() throws RecognitionException {
		Single_valued_object_path_expressionContext _localctx = new Single_valued_object_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_single_valued_object_path_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(533);
			general_subpath();
			setState(534);
			match(T__3);
			setState(535);
			single_valued_object_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_valued_path_expressionContext extends ParserRuleContext {
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public Collection_value_fieldContext collection_value_field() {
			return getRuleContext(Collection_value_fieldContext.class,0);
		}
		public Collection_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_valued_path_expressionContext collection_valued_path_expression() throws RecognitionException {
		Collection_valued_path_expressionContext _localctx = new Collection_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_collection_valued_path_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(537);
			general_subpath();
			setState(538);
			match(T__3);
			setState(539);
			collection_value_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Update_clauseContext extends ParserRuleContext {
		public TerminalNode UPDATE() { return getToken(JpqlParser.UPDATE, 0); }
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public TerminalNode SET() { return getToken(JpqlParser.SET, 0); }
		public List<Update_itemContext> update_item() {
			return getRuleContexts(Update_itemContext.class);
		}
		public Update_itemContext update_item(int i) {
			return getRuleContext(Update_itemContext.class,i);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Update_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_update_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterUpdate_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitUpdate_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitUpdate_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Update_clauseContext update_clause() throws RecognitionException {
		Update_clauseContext _localctx = new Update_clauseContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_update_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(541);
			match(UPDATE);
			setState(542);
			entity_name();
			setState(547);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 5116098264852070400L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 4722099271905591587L) != 0)) {
				{
				setState(544);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,47,_ctx) ) {
				case 1:
					{
					setState(543);
					match(AS);
					}
					break;
				}
				setState(546);
				identification_variable();
				}
			}

			setState(549);
			match(SET);
			setState(550);
			update_item();
			setState(555);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(551);
				match(T__0);
				setState(552);
				update_item();
				}
				}
				setState(557);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Update_itemContext extends ParserRuleContext {
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public New_valueContext new_value() {
			return getRuleContext(New_valueContext.class,0);
		}
		public State_fieldContext state_field() {
			return getRuleContext(State_fieldContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public List<Single_valued_embeddable_object_fieldContext> single_valued_embeddable_object_field() {
			return getRuleContexts(Single_valued_embeddable_object_fieldContext.class);
		}
		public Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field(int i) {
			return getRuleContext(Single_valued_embeddable_object_fieldContext.class,i);
		}
		public Update_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_update_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterUpdate_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitUpdate_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitUpdate_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Update_itemContext update_item() throws RecognitionException {
		Update_itemContext _localctx = new Update_itemContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_update_item);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(561);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,50,_ctx) ) {
			case 1:
				{
				setState(558);
				identification_variable();
				setState(559);
				match(T__3);
				}
				break;
			}
			setState(568);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,51,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(563);
					single_valued_embeddable_object_field();
					setState(564);
					match(T__3);
					}
					} 
				}
				setState(570);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,51,_ctx);
			}
			setState(573);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,52,_ctx) ) {
			case 1:
				{
				setState(571);
				state_field();
				}
				break;
			case 2:
				{
				setState(572);
				single_valued_object_field();
				}
				break;
			}
			setState(575);
			match(EQUAL);
			setState(576);
			new_value();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class New_valueContext extends ParserRuleContext {
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Simple_entity_expressionContext simple_entity_expression() {
			return getRuleContext(Simple_entity_expressionContext.class,0);
		}
		public TerminalNode NULL() { return getToken(JpqlParser.NULL, 0); }
		public New_valueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_new_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNew_value(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNew_value(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNew_value(this);
			else return visitor.visitChildren(this);
		}
	}

	public final New_valueContext new_value() throws RecognitionException {
		New_valueContext _localctx = new New_valueContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_new_value);
		try {
			setState(581);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,53,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(578);
				scalar_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(579);
				simple_entity_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(580);
				match(NULL);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Delete_clauseContext extends ParserRuleContext {
		public TerminalNode DELETE() { return getToken(JpqlParser.DELETE, 0); }
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Delete_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delete_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDelete_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDelete_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDelete_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Delete_clauseContext delete_clause() throws RecognitionException {
		Delete_clauseContext _localctx = new Delete_clauseContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_delete_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(583);
			match(DELETE);
			setState(584);
			match(FROM);
			setState(585);
			entity_name();
			setState(590);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 5116098264852070400L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 4722099271905591587L) != 0)) {
				{
				setState(587);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,54,_ctx) ) {
				case 1:
					{
					setState(586);
					match(AS);
					}
					break;
				}
				setState(589);
				identification_variable();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_clauseContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(JpqlParser.SELECT, 0); }
		public List<Select_itemContext> select_item() {
			return getRuleContexts(Select_itemContext.class);
		}
		public Select_itemContext select_item(int i) {
			return getRuleContext(Select_itemContext.class,i);
		}
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public Select_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_clauseContext select_clause() throws RecognitionException {
		Select_clauseContext _localctx = new Select_clauseContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_select_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(592);
			match(SELECT);
			setState(594);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DISTINCT) {
				{
				setState(593);
				match(DISTINCT);
				}
			}

			setState(596);
			select_item();
			setState(601);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(597);
				match(T__0);
				setState(598);
				select_item();
				}
				}
				setState(603);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_itemContext extends ParserRuleContext {
		public Select_expressionContext select_expression() {
			return getRuleContext(Select_expressionContext.class,0);
		}
		public Result_variableContext result_variable() {
			return getRuleContext(Result_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Select_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_itemContext select_item() throws RecognitionException {
		Select_itemContext _localctx = new Select_itemContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_select_item);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(604);
			select_expression();
			setState(609);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,59,_ctx) ) {
			case 1:
				{
				setState(606);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
				case 1:
					{
					setState(605);
					match(AS);
					}
					break;
				}
				setState(608);
				result_variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_expressionContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode OBJECT() { return getToken(JpqlParser.OBJECT, 0); }
		public Constructor_expressionContext constructor_expression() {
			return getRuleContext(Constructor_expressionContext.class,0);
		}
		public Select_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_expressionContext select_expression() throws RecognitionException {
		Select_expressionContext _localctx = new Select_expressionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_select_expression);
		try {
			setState(621);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,60,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(611);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(612);
				scalar_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(613);
				aggregate_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(614);
				identification_variable();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(615);
				match(OBJECT);
				setState(616);
				match(T__1);
				setState(617);
				identification_variable();
				setState(618);
				match(T__2);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(620);
				constructor_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Constructor_expressionContext extends ParserRuleContext {
		public TerminalNode NEW() { return getToken(JpqlParser.NEW, 0); }
		public Constructor_nameContext constructor_name() {
			return getRuleContext(Constructor_nameContext.class,0);
		}
		public List<Constructor_itemContext> constructor_item() {
			return getRuleContexts(Constructor_itemContext.class);
		}
		public Constructor_itemContext constructor_item(int i) {
			return getRuleContext(Constructor_itemContext.class,i);
		}
		public Constructor_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constructor_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConstructor_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConstructor_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConstructor_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constructor_expressionContext constructor_expression() throws RecognitionException {
		Constructor_expressionContext _localctx = new Constructor_expressionContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_constructor_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(623);
			match(NEW);
			setState(624);
			constructor_name();
			setState(625);
			match(T__1);
			setState(626);
			constructor_item();
			setState(631);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(627);
				match(T__0);
				setState(628);
				constructor_item();
				}
				}
				setState(633);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(634);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Constructor_itemContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public Constructor_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constructor_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConstructor_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConstructor_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConstructor_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constructor_itemContext constructor_item() throws RecognitionException {
		Constructor_itemContext _localctx = new Constructor_itemContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_constructor_item);
		try {
			setState(641);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,62,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(636);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(637);
				scalar_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(638);
				aggregate_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(639);
				identification_variable();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(640);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Aggregate_expressionContext extends ParserRuleContext {
		public Simple_select_expressionContext simple_select_expression() {
			return getRuleContext(Simple_select_expressionContext.class,0);
		}
		public TerminalNode AVG() { return getToken(JpqlParser.AVG, 0); }
		public TerminalNode MAX() { return getToken(JpqlParser.MAX, 0); }
		public TerminalNode MIN() { return getToken(JpqlParser.MIN, 0); }
		public TerminalNode SUM() { return getToken(JpqlParser.SUM, 0); }
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public TerminalNode COUNT() { return getToken(JpqlParser.COUNT, 0); }
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public Aggregate_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggregate_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterAggregate_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitAggregate_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitAggregate_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Aggregate_expressionContext aggregate_expression() throws RecognitionException {
		Aggregate_expressionContext _localctx = new Aggregate_expressionContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_aggregate_expression);
		int _la;
		try {
			setState(660);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AVG:
			case MAX:
			case MIN:
			case SUM:
				enterOuterAlt(_localctx, 1);
				{
				setState(643);
				_la = _input.LA(1);
				if ( !(_la==AVG || ((((_la - 81)) & ~0x3f) == 0 && ((1L << (_la - 81)) & 268435461L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(644);
				match(T__1);
				setState(646);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DISTINCT) {
					{
					setState(645);
					match(DISTINCT);
					}
				}

				setState(648);
				simple_select_expression();
				setState(649);
				match(T__2);
				}
				break;
			case COUNT:
				enterOuterAlt(_localctx, 2);
				{
				setState(651);
				match(COUNT);
				setState(652);
				match(T__1);
				setState(654);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DISTINCT) {
					{
					setState(653);
					match(DISTINCT);
					}
				}

				setState(656);
				simple_select_expression();
				setState(657);
				match(T__2);
				}
				break;
			case FUNCTION:
				enterOuterAlt(_localctx, 3);
				{
				setState(659);
				function_invocation();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Where_clauseContext extends ParserRuleContext {
		public TerminalNode WHERE() { return getToken(JpqlParser.WHERE, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Where_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_where_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterWhere_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitWhere_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitWhere_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Where_clauseContext where_clause() throws RecognitionException {
		Where_clauseContext _localctx = new Where_clauseContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_where_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(662);
			match(WHERE);
			setState(663);
			conditional_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Groupby_clauseContext extends ParserRuleContext {
		public TerminalNode GROUP() { return getToken(JpqlParser.GROUP, 0); }
		public TerminalNode BY() { return getToken(JpqlParser.BY, 0); }
		public List<Groupby_itemContext> groupby_item() {
			return getRuleContexts(Groupby_itemContext.class);
		}
		public Groupby_itemContext groupby_item(int i) {
			return getRuleContext(Groupby_itemContext.class,i);
		}
		public Groupby_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupby_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGroupby_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGroupby_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGroupby_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Groupby_clauseContext groupby_clause() throws RecognitionException {
		Groupby_clauseContext _localctx = new Groupby_clauseContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_groupby_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(665);
			match(GROUP);
			setState(666);
			match(BY);
			setState(667);
			groupby_item();
			setState(672);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(668);
				match(T__0);
				setState(669);
				groupby_item();
				}
				}
				setState(674);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Groupby_itemContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Groupby_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupby_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGroupby_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGroupby_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGroupby_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Groupby_itemContext groupby_item() throws RecognitionException {
		Groupby_itemContext _localctx = new Groupby_itemContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_groupby_item);
		try {
			setState(677);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,67,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(675);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(676);
				identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Having_clauseContext extends ParserRuleContext {
		public TerminalNode HAVING() { return getToken(JpqlParser.HAVING, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Having_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_having_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterHaving_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitHaving_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitHaving_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Having_clauseContext having_clause() throws RecognitionException {
		Having_clauseContext _localctx = new Having_clauseContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_having_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(679);
			match(HAVING);
			setState(680);
			conditional_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Orderby_clauseContext extends ParserRuleContext {
		public TerminalNode ORDER() { return getToken(JpqlParser.ORDER, 0); }
		public TerminalNode BY() { return getToken(JpqlParser.BY, 0); }
		public List<Orderby_itemContext> orderby_item() {
			return getRuleContexts(Orderby_itemContext.class);
		}
		public Orderby_itemContext orderby_item(int i) {
			return getRuleContext(Orderby_itemContext.class,i);
		}
		public Orderby_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderby_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterOrderby_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitOrderby_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitOrderby_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Orderby_clauseContext orderby_clause() throws RecognitionException {
		Orderby_clauseContext _localctx = new Orderby_clauseContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_orderby_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(682);
			match(ORDER);
			setState(683);
			match(BY);
			setState(684);
			orderby_item();
			setState(689);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(685);
				match(T__0);
				setState(686);
				orderby_item();
				}
				}
				setState(691);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Orderby_itemContext extends ParserRuleContext {
		public Orderby_expressionContext orderby_expression() {
			return getRuleContext(Orderby_expressionContext.class,0);
		}
		public NullsPrecedenceContext nullsPrecedence() {
			return getRuleContext(NullsPrecedenceContext.class,0);
		}
		public TerminalNode ASC() { return getToken(JpqlParser.ASC, 0); }
		public TerminalNode DESC() { return getToken(JpqlParser.DESC, 0); }
		public Orderby_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderby_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterOrderby_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitOrderby_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitOrderby_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Orderby_itemContext orderby_item() throws RecognitionException {
		Orderby_itemContext _localctx = new Orderby_itemContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_orderby_item);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(692);
			orderby_expression();
			setState(694);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(693);
				_la = _input.LA(1);
				if ( !(_la==ASC || _la==DESC) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			setState(697);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NULLS) {
				{
				setState(696);
				nullsPrecedence();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Orderby_expressionContext extends ParserRuleContext {
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Orderby_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderby_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterOrderby_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitOrderby_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitOrderby_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Orderby_expressionContext orderby_expression() throws RecognitionException {
		Orderby_expressionContext _localctx = new Orderby_expressionContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_orderby_expression);
		try {
			setState(703);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,71,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(699);
				state_field_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(700);
				general_identification_variable();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(701);
				string_expression(0);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(702);
				scalar_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NullsPrecedenceContext extends ParserRuleContext {
		public TerminalNode NULLS() { return getToken(JpqlParser.NULLS, 0); }
		public TerminalNode FIRST() { return getToken(JpqlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(JpqlParser.LAST, 0); }
		public NullsPrecedenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullsPrecedence; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNullsPrecedence(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNullsPrecedence(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNullsPrecedence(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NullsPrecedenceContext nullsPrecedence() throws RecognitionException {
		NullsPrecedenceContext _localctx = new NullsPrecedenceContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_nullsPrecedence);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(705);
			match(NULLS);
			setState(706);
			_la = _input.LA(1);
			if ( !(_la==FIRST || _la==LAST) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubqueryContext extends ParserRuleContext {
		public Simple_select_clauseContext simple_select_clause() {
			return getRuleContext(Simple_select_clauseContext.class,0);
		}
		public Subquery_from_clauseContext subquery_from_clause() {
			return getRuleContext(Subquery_from_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Groupby_clauseContext groupby_clause() {
			return getRuleContext(Groupby_clauseContext.class,0);
		}
		public Having_clauseContext having_clause() {
			return getRuleContext(Having_clauseContext.class,0);
		}
		public SubqueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subquery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubquery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubqueryContext subquery() throws RecognitionException {
		SubqueryContext _localctx = new SubqueryContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_subquery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(708);
			simple_select_clause();
			setState(709);
			subquery_from_clause();
			setState(711);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(710);
				where_clause();
				}
			}

			setState(714);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUP) {
				{
				setState(713);
				groupby_clause();
				}
			}

			setState(717);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==HAVING) {
				{
				setState(716);
				having_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Subquery_from_clauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public List<Subselect_identification_variable_declarationContext> subselect_identification_variable_declaration() {
			return getRuleContexts(Subselect_identification_variable_declarationContext.class);
		}
		public Subselect_identification_variable_declarationContext subselect_identification_variable_declaration(int i) {
			return getRuleContext(Subselect_identification_variable_declarationContext.class,i);
		}
		public List<Collection_member_declarationContext> collection_member_declaration() {
			return getRuleContexts(Collection_member_declarationContext.class);
		}
		public Collection_member_declarationContext collection_member_declaration(int i) {
			return getRuleContext(Collection_member_declarationContext.class,i);
		}
		public Subquery_from_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subquery_from_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubquery_from_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubquery_from_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubquery_from_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Subquery_from_clauseContext subquery_from_clause() throws RecognitionException {
		Subquery_from_clauseContext _localctx = new Subquery_from_clauseContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_subquery_from_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(719);
			match(FROM);
			setState(720);
			subselect_identification_variable_declaration();
			setState(728);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(721);
				match(T__0);
				setState(724);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,75,_ctx) ) {
				case 1:
					{
					setState(722);
					subselect_identification_variable_declaration();
					}
					break;
				case 2:
					{
					setState(723);
					collection_member_declaration();
					}
					break;
				}
				}
				}
				setState(730);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Subselect_identification_variable_declarationContext extends ParserRuleContext {
		public Identification_variable_declarationContext identification_variable_declaration() {
			return getRuleContext(Identification_variable_declarationContext.class,0);
		}
		public Derived_path_expressionContext derived_path_expression() {
			return getRuleContext(Derived_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public List<JoinContext> join() {
			return getRuleContexts(JoinContext.class);
		}
		public JoinContext join(int i) {
			return getRuleContext(JoinContext.class,i);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Derived_collection_member_declarationContext derived_collection_member_declaration() {
			return getRuleContext(Derived_collection_member_declarationContext.class,0);
		}
		public Subselect_identification_variable_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subselect_identification_variable_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubselect_identification_variable_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubselect_identification_variable_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubselect_identification_variable_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Subselect_identification_variable_declarationContext subselect_identification_variable_declaration() throws RecognitionException {
		Subselect_identification_variable_declarationContext _localctx = new Subselect_identification_variable_declarationContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_subselect_identification_variable_declaration);
		int _la;
		try {
			setState(746);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,80,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(731);
				identification_variable_declaration();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(732);
				derived_path_expression();
				setState(737);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,78,_ctx) ) {
				case 1:
					{
					setState(734);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,77,_ctx) ) {
					case 1:
						{
						setState(733);
						match(AS);
						}
						break;
					}
					setState(736);
					identification_variable();
					}
					break;
				}
				setState(742);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 273L) != 0)) {
					{
					{
					setState(739);
					join();
					}
					}
					setState(744);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(745);
				derived_collection_member_declaration();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Derived_path_expressionContext extends ParserRuleContext {
		public General_derived_pathContext general_derived_path() {
			return getRuleContext(General_derived_pathContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Collection_valued_fieldContext collection_valued_field() {
			return getRuleContext(Collection_valued_fieldContext.class,0);
		}
		public Derived_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_derived_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDerived_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDerived_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDerived_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Derived_path_expressionContext derived_path_expression() throws RecognitionException {
		Derived_path_expressionContext _localctx = new Derived_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_derived_path_expression);
		try {
			setState(756);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,81,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(748);
				general_derived_path();
				setState(749);
				match(T__3);
				setState(750);
				single_valued_object_field();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(752);
				general_derived_path();
				setState(753);
				match(T__3);
				setState(754);
				collection_valued_field();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_derived_pathContext extends ParserRuleContext {
		public Simple_derived_pathContext simple_derived_path() {
			return getRuleContext(Simple_derived_pathContext.class,0);
		}
		public Treated_derived_pathContext treated_derived_path() {
			return getRuleContext(Treated_derived_pathContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public General_derived_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_derived_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_derived_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_derived_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_derived_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_derived_pathContext general_derived_path() throws RecognitionException {
		General_derived_pathContext _localctx = new General_derived_pathContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_general_derived_path);
		try {
			int _alt;
			setState(767);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AS:
			case COUNT:
			case DATE:
			case DOUBLE:
			case FLOAT:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case INTEGER:
			case KEY:
			case LEFT:
			case LONG:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case STRING:
			case TIME:
			case TYPE:
			case VALUE:
			case VERSION:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(758);
				simple_derived_path();
				}
				break;
			case TREAT:
				enterOuterAlt(_localctx, 2);
				{
				setState(759);
				treated_derived_path();
				setState(764);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,82,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(760);
						match(T__3);
						setState(761);
						single_valued_object_field();
						}
						} 
					}
					setState(766);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,82,_ctx);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_derived_pathContext extends ParserRuleContext {
		public Superquery_identification_variableContext superquery_identification_variable() {
			return getRuleContext(Superquery_identification_variableContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public Simple_derived_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_derived_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_derived_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_derived_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_derived_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_derived_pathContext simple_derived_path() throws RecognitionException {
		Simple_derived_pathContext _localctx = new Simple_derived_pathContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_simple_derived_path);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(769);
			superquery_identification_variable();
			setState(774);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,84,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(770);
					match(T__3);
					setState(771);
					single_valued_object_field();
					}
					} 
				}
				setState(776);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,84,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Treated_derived_pathContext extends ParserRuleContext {
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public General_derived_pathContext general_derived_path() {
			return getRuleContext(General_derived_pathContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public Treated_derived_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_treated_derived_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTreated_derived_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTreated_derived_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTreated_derived_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Treated_derived_pathContext treated_derived_path() throws RecognitionException {
		Treated_derived_pathContext _localctx = new Treated_derived_pathContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_treated_derived_path);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(777);
			match(TREAT);
			setState(778);
			match(T__1);
			setState(779);
			general_derived_path();
			setState(780);
			match(AS);
			setState(781);
			subtype();
			setState(782);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Derived_collection_member_declarationContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public Superquery_identification_variableContext superquery_identification_variable() {
			return getRuleContext(Superquery_identification_variableContext.class,0);
		}
		public Collection_valued_fieldContext collection_valued_field() {
			return getRuleContext(Collection_valued_fieldContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public Derived_collection_member_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_derived_collection_member_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDerived_collection_member_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDerived_collection_member_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDerived_collection_member_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Derived_collection_member_declarationContext derived_collection_member_declaration() throws RecognitionException {
		Derived_collection_member_declarationContext _localctx = new Derived_collection_member_declarationContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_derived_collection_member_declaration);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(784);
			match(IN);
			setState(785);
			superquery_identification_variable();
			setState(786);
			match(T__3);
			setState(792);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,85,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(787);
					single_valued_object_field();
					setState(788);
					match(T__3);
					}
					} 
				}
				setState(794);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,85,_ctx);
			}
			setState(795);
			collection_valued_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_select_clauseContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(JpqlParser.SELECT, 0); }
		public Simple_select_expressionContext simple_select_expression() {
			return getRuleContext(Simple_select_expressionContext.class,0);
		}
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public Simple_select_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_select_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_select_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_select_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_select_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_select_clauseContext simple_select_clause() throws RecognitionException {
		Simple_select_clauseContext _localctx = new Simple_select_clauseContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_simple_select_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(797);
			match(SELECT);
			setState(799);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DISTINCT) {
				{
				setState(798);
				match(DISTINCT);
				}
			}

			setState(801);
			simple_select_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_select_expressionContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Simple_select_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_select_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_select_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_select_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_select_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_select_expressionContext simple_select_expression() throws RecognitionException {
		Simple_select_expressionContext _localctx = new Simple_select_expressionContext(_ctx, getState());
		enterRule(_localctx, 112, RULE_simple_select_expression);
		try {
			setState(807);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,87,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(803);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(804);
				scalar_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(805);
				aggregate_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(806);
				identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Scalar_expressionContext extends ParserRuleContext {
		public Arithmetic_expressionContext arithmetic_expression() {
			return getRuleContext(Arithmetic_expressionContext.class,0);
		}
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Enum_expressionContext enum_expression() {
			return getRuleContext(Enum_expressionContext.class,0);
		}
		public Datetime_expressionContext datetime_expression() {
			return getRuleContext(Datetime_expressionContext.class,0);
		}
		public Boolean_expressionContext boolean_expression() {
			return getRuleContext(Boolean_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Entity_type_expressionContext entity_type_expression() {
			return getRuleContext(Entity_type_expressionContext.class,0);
		}
		public Entity_id_or_version_functionContext entity_id_or_version_function() {
			return getRuleContext(Entity_id_or_version_functionContext.class,0);
		}
		public Scalar_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalar_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterScalar_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitScalar_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitScalar_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Scalar_expressionContext scalar_expression() throws RecognitionException {
		Scalar_expressionContext _localctx = new Scalar_expressionContext(_ctx, getState());
		enterRule(_localctx, 114, RULE_scalar_expression);
		try {
			setState(817);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,88,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(809);
				arithmetic_expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(810);
				string_expression(0);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(811);
				enum_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(812);
				datetime_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(813);
				boolean_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(814);
				case_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(815);
				entity_type_expression();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(816);
				entity_id_or_version_function();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_expressionContext extends ParserRuleContext {
		public Conditional_termContext conditional_term() {
			return getRuleContext(Conditional_termContext.class,0);
		}
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public TerminalNode OR() { return getToken(JpqlParser.OR, 0); }
		public Conditional_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_expressionContext conditional_expression() throws RecognitionException {
		return conditional_expression(0);
	}

	private Conditional_expressionContext conditional_expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Conditional_expressionContext _localctx = new Conditional_expressionContext(_ctx, _parentState);
		Conditional_expressionContext _prevctx = _localctx;
		int _startState = 116;
		enterRecursionRule(_localctx, 116, RULE_conditional_expression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(820);
			conditional_term(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(827);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,89,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Conditional_expressionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_conditional_expression);
					setState(822);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(823);
					match(OR);
					setState(824);
					conditional_term(0);
					}
					} 
				}
				setState(829);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,89,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_termContext extends ParserRuleContext {
		public Conditional_factorContext conditional_factor() {
			return getRuleContext(Conditional_factorContext.class,0);
		}
		public Conditional_termContext conditional_term() {
			return getRuleContext(Conditional_termContext.class,0);
		}
		public TerminalNode AND() { return getToken(JpqlParser.AND, 0); }
		public Conditional_termContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_term(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_term(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_termContext conditional_term() throws RecognitionException {
		return conditional_term(0);
	}

	private Conditional_termContext conditional_term(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Conditional_termContext _localctx = new Conditional_termContext(_ctx, _parentState);
		Conditional_termContext _prevctx = _localctx;
		int _startState = 118;
		enterRecursionRule(_localctx, 118, RULE_conditional_term, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(831);
			conditional_factor();
			}
			_ctx.stop = _input.LT(-1);
			setState(838);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,90,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Conditional_termContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_conditional_term);
					setState(833);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(834);
					match(AND);
					setState(835);
					conditional_factor();
					}
					} 
				}
				setState(840);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,90,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_factorContext extends ParserRuleContext {
		public Conditional_primaryContext conditional_primary() {
			return getRuleContext(Conditional_primaryContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Conditional_factorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_factor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_factor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_factorContext conditional_factor() throws RecognitionException {
		Conditional_factorContext _localctx = new Conditional_factorContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_conditional_factor);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(842);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,91,_ctx) ) {
			case 1:
				{
				setState(841);
				match(NOT);
				}
				break;
			}
			setState(844);
			conditional_primary();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_primaryContext extends ParserRuleContext {
		public Simple_cond_expressionContext simple_cond_expression() {
			return getRuleContext(Simple_cond_expressionContext.class,0);
		}
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Conditional_primaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_primary; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_primary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_primary(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_primary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_primaryContext conditional_primary() throws RecognitionException {
		Conditional_primaryContext _localctx = new Conditional_primaryContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_conditional_primary);
		try {
			setState(851);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,92,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(846);
				simple_cond_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(847);
				match(T__1);
				setState(848);
				conditional_expression(0);
				setState(849);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_cond_expressionContext extends ParserRuleContext {
		public Comparison_expressionContext comparison_expression() {
			return getRuleContext(Comparison_expressionContext.class,0);
		}
		public Between_expressionContext between_expression() {
			return getRuleContext(Between_expressionContext.class,0);
		}
		public In_expressionContext in_expression() {
			return getRuleContext(In_expressionContext.class,0);
		}
		public Like_expressionContext like_expression() {
			return getRuleContext(Like_expressionContext.class,0);
		}
		public Null_comparison_expressionContext null_comparison_expression() {
			return getRuleContext(Null_comparison_expressionContext.class,0);
		}
		public Empty_collection_comparison_expressionContext empty_collection_comparison_expression() {
			return getRuleContext(Empty_collection_comparison_expressionContext.class,0);
		}
		public Collection_member_expressionContext collection_member_expression() {
			return getRuleContext(Collection_member_expressionContext.class,0);
		}
		public Exists_expressionContext exists_expression() {
			return getRuleContext(Exists_expressionContext.class,0);
		}
		public Simple_cond_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_cond_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_cond_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_cond_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_cond_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_cond_expressionContext simple_cond_expression() throws RecognitionException {
		Simple_cond_expressionContext _localctx = new Simple_cond_expressionContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_simple_cond_expression);
		try {
			setState(861);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,93,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(853);
				comparison_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(854);
				between_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(855);
				in_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(856);
				like_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(857);
				null_comparison_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(858);
				empty_collection_comparison_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(859);
				collection_member_expression();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(860);
				exists_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Between_expressionContext extends ParserRuleContext {
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public TerminalNode BETWEEN() { return getToken(JpqlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(JpqlParser.AND, 0); }
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public List<Datetime_expressionContext> datetime_expression() {
			return getRuleContexts(Datetime_expressionContext.class);
		}
		public Datetime_expressionContext datetime_expression(int i) {
			return getRuleContext(Datetime_expressionContext.class,i);
		}
		public Between_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_between_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBetween_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBetween_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBetween_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Between_expressionContext between_expression() throws RecognitionException {
		Between_expressionContext _localctx = new Between_expressionContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_between_expression);
		int _la;
		try {
			setState(890);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,97,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(863);
				arithmetic_expression(0);
				setState(865);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(864);
					match(NOT);
					}
				}

				setState(867);
				match(BETWEEN);
				setState(868);
				arithmetic_expression(0);
				setState(869);
				match(AND);
				setState(870);
				arithmetic_expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(872);
				string_expression(0);
				setState(874);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(873);
					match(NOT);
					}
				}

				setState(876);
				match(BETWEEN);
				setState(877);
				string_expression(0);
				setState(878);
				match(AND);
				setState(879);
				string_expression(0);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(881);
				datetime_expression();
				setState(883);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(882);
					match(NOT);
					}
				}

				setState(885);
				match(BETWEEN);
				setState(886);
				datetime_expression();
				setState(887);
				match(AND);
				setState(888);
				datetime_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class In_expressionContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Type_discriminatorContext type_discriminator() {
			return getRuleContext(Type_discriminatorContext.class,0);
		}
		public Collection_valued_input_parameterContext collection_valued_input_parameter() {
			return getRuleContext(Collection_valued_input_parameterContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public List<In_itemContext> in_item() {
			return getRuleContexts(In_itemContext.class);
		}
		public In_itemContext in_item(int i) {
			return getRuleContext(In_itemContext.class,i);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public In_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_in_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIn_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIn_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIn_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final In_expressionContext in_expression() throws RecognitionException {
		In_expressionContext _localctx = new In_expressionContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_in_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(894);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,98,_ctx) ) {
			case 1:
				{
				setState(892);
				string_expression(0);
				}
				break;
			case 2:
				{
				setState(893);
				type_discriminator();
				}
				break;
			}
			setState(897);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(896);
				match(NOT);
				}
			}

			setState(899);
			match(IN);
			setState(916);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,101,_ctx) ) {
			case 1:
				{
				{
				setState(900);
				match(T__1);
				setState(901);
				in_item();
				setState(906);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(902);
					match(T__0);
					setState(903);
					in_item();
					}
					}
					setState(908);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(909);
				match(T__2);
				}
				}
				break;
			case 2:
				{
				{
				setState(911);
				match(T__1);
				setState(912);
				subquery();
				setState(913);
				match(T__2);
				}
				}
				break;
			case 3:
				{
				setState(915);
				collection_valued_input_parameter();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class In_itemContext extends ParserRuleContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Boolean_literalContext boolean_literal() {
			return getRuleContext(Boolean_literalContext.class,0);
		}
		public Numeric_literalContext numeric_literal() {
			return getRuleContext(Numeric_literalContext.class,0);
		}
		public Date_time_timestamp_literalContext date_time_timestamp_literal() {
			return getRuleContext(Date_time_timestamp_literalContext.class,0);
		}
		public Single_valued_input_parameterContext single_valued_input_parameter() {
			return getRuleContext(Single_valued_input_parameterContext.class,0);
		}
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public In_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_in_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIn_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIn_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIn_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final In_itemContext in_item() throws RecognitionException {
		In_itemContext _localctx = new In_itemContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_in_item);
		try {
			setState(925);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,102,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(918);
				literal();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(919);
				string_expression(0);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(920);
				boolean_literal();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(921);
				numeric_literal();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(922);
				date_time_timestamp_literal();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(923);
				single_valued_input_parameter();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(924);
				conditional_expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Like_expressionContext extends ParserRuleContext {
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public TerminalNode LIKE() { return getToken(JpqlParser.LIKE, 0); }
		public Pattern_valueContext pattern_value() {
			return getRuleContext(Pattern_valueContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public TerminalNode ESCAPE() { return getToken(JpqlParser.ESCAPE, 0); }
		public Escape_characterContext escape_character() {
			return getRuleContext(Escape_characterContext.class,0);
		}
		public Like_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_like_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterLike_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitLike_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitLike_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Like_expressionContext like_expression() throws RecognitionException {
		Like_expressionContext _localctx = new Like_expressionContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_like_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(927);
			string_expression(0);
			setState(929);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(928);
				match(NOT);
				}
			}

			setState(931);
			match(LIKE);
			setState(932);
			pattern_value();
			setState(935);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,104,_ctx) ) {
			case 1:
				{
				setState(933);
				match(ESCAPE);
				setState(934);
				escape_character();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Null_comparison_expressionContext extends ParserRuleContext {
		public TerminalNode IS() { return getToken(JpqlParser.IS, 0); }
		public TerminalNode NULL() { return getToken(JpqlParser.NULL, 0); }
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Null_comparison_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_null_comparison_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNull_comparison_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNull_comparison_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNull_comparison_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Null_comparison_expressionContext null_comparison_expression() throws RecognitionException {
		Null_comparison_expressionContext _localctx = new Null_comparison_expressionContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_null_comparison_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(939);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AS:
			case COUNT:
			case DATE:
			case DOUBLE:
			case ENTRY:
			case FLOAT:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case INTEGER:
			case KEY:
			case LEFT:
			case LONG:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case STRING:
			case TIME:
			case TREAT:
			case TYPE:
			case VALUE:
			case VERSION:
			case IDENTIFICATION_VARIABLE:
				{
				setState(937);
				single_valued_path_expression();
				}
				break;
			case T__13:
			case T__14:
				{
				setState(938);
				input_parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(941);
			match(IS);
			setState(943);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(942);
				match(NOT);
				}
			}

			setState(945);
			match(NULL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Empty_collection_comparison_expressionContext extends ParserRuleContext {
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public TerminalNode IS() { return getToken(JpqlParser.IS, 0); }
		public TerminalNode EMPTY() { return getToken(JpqlParser.EMPTY, 0); }
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Empty_collection_comparison_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_empty_collection_comparison_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEmpty_collection_comparison_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEmpty_collection_comparison_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEmpty_collection_comparison_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Empty_collection_comparison_expressionContext empty_collection_comparison_expression() throws RecognitionException {
		Empty_collection_comparison_expressionContext _localctx = new Empty_collection_comparison_expressionContext(_ctx, getState());
		enterRule(_localctx, 136, RULE_empty_collection_comparison_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(947);
			collection_valued_path_expression();
			setState(948);
			match(IS);
			setState(950);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(949);
				match(NOT);
				}
			}

			setState(952);
			match(EMPTY);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_member_expressionContext extends ParserRuleContext {
		public Entity_or_value_expressionContext entity_or_value_expression() {
			return getRuleContext(Entity_or_value_expressionContext.class,0);
		}
		public TerminalNode MEMBER() { return getToken(JpqlParser.MEMBER, 0); }
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public TerminalNode OF() { return getToken(JpqlParser.OF, 0); }
		public Collection_member_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_member_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_member_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_member_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_member_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_member_expressionContext collection_member_expression() throws RecognitionException {
		Collection_member_expressionContext _localctx = new Collection_member_expressionContext(_ctx, getState());
		enterRule(_localctx, 138, RULE_collection_member_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(954);
			entity_or_value_expression();
			setState(956);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(955);
				match(NOT);
				}
			}

			setState(958);
			match(MEMBER);
			setState(960);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==OF) {
				{
				setState(959);
				match(OF);
				}
			}

			setState(962);
			collection_valued_path_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_or_value_expressionContext extends ParserRuleContext {
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public Map_field_identification_variableContext map_field_identification_variable() {
			return getRuleContext(Map_field_identification_variableContext.class,0);
		}
		public Simple_entity_or_value_expressionContext simple_entity_or_value_expression() {
			return getRuleContext(Simple_entity_or_value_expressionContext.class,0);
		}
		public Entity_or_value_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_or_value_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_or_value_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_or_value_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_or_value_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_or_value_expressionContext entity_or_value_expression() throws RecognitionException {
		Entity_or_value_expressionContext _localctx = new Entity_or_value_expressionContext(_ctx, getState());
		enterRule(_localctx, 140, RULE_entity_or_value_expression);
		try {
			setState(968);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,110,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(964);
				single_valued_object_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(965);
				state_field_path_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(966);
				map_field_identification_variable();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(967);
				simple_entity_or_value_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_entity_or_value_expressionContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public Simple_entity_or_value_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_entity_or_value_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_entity_or_value_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_entity_or_value_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_entity_or_value_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_entity_or_value_expressionContext simple_entity_or_value_expression() throws RecognitionException {
		Simple_entity_or_value_expressionContext _localctx = new Simple_entity_or_value_expressionContext(_ctx, getState());
		enterRule(_localctx, 142, RULE_simple_entity_or_value_expression);
		try {
			setState(973);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,111,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(970);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(971);
				input_parameter();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(972);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Exists_expressionContext extends ParserRuleContext {
		public TerminalNode EXISTS() { return getToken(JpqlParser.EXISTS, 0); }
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Exists_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exists_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterExists_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitExists_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitExists_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Exists_expressionContext exists_expression() throws RecognitionException {
		Exists_expressionContext _localctx = new Exists_expressionContext(_ctx, getState());
		enterRule(_localctx, 144, RULE_exists_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(976);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(975);
				match(NOT);
				}
			}

			setState(978);
			match(EXISTS);
			setState(979);
			match(T__1);
			setState(980);
			subquery();
			setState(981);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class All_or_any_expressionContext extends ParserRuleContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode ALL() { return getToken(JpqlParser.ALL, 0); }
		public TerminalNode ANY() { return getToken(JpqlParser.ANY, 0); }
		public TerminalNode SOME() { return getToken(JpqlParser.SOME, 0); }
		public All_or_any_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_all_or_any_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterAll_or_any_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitAll_or_any_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitAll_or_any_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final All_or_any_expressionContext all_or_any_expression() throws RecognitionException {
		All_or_any_expressionContext _localctx = new All_or_any_expressionContext(_ctx, getState());
		enterRule(_localctx, 146, RULE_all_or_any_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(983);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==ANY || _la==SOME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(984);
			match(T__1);
			setState(985);
			subquery();
			setState(986);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Comparison_expressionContext extends ParserRuleContext {
		public Comparison_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparison_expression; }
	 
		public Comparison_expressionContext() { }
		public void copyFrom(Comparison_expressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BooleanComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Boolean_expressionContext> boolean_expression() {
			return getRuleContexts(Boolean_expressionContext.class);
		}
		public Boolean_expressionContext boolean_expression(int i) {
			return getRuleContext(Boolean_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public BooleanComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBooleanComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBooleanComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBooleanComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DirectBooleanCheckContext extends Comparison_expressionContext {
		public Boolean_expressionContext boolean_expression() {
			return getRuleContext(Boolean_expressionContext.class,0);
		}
		public DirectBooleanCheckContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDirectBooleanCheck(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDirectBooleanCheck(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDirectBooleanCheck(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StringComparisonContext extends Comparison_expressionContext {
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public Comparison_operatorContext comparison_operator() {
			return getRuleContext(Comparison_operatorContext.class,0);
		}
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public StringComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterStringComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitStringComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitStringComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Entity_expressionContext> entity_expression() {
			return getRuleContexts(Entity_expressionContext.class);
		}
		public Entity_expressionContext entity_expression(int i) {
			return getRuleContext(Entity_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public EntityComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntityComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntityComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntityComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DatetimeComparisonContext extends Comparison_expressionContext {
		public List<Datetime_expressionContext> datetime_expression() {
			return getRuleContexts(Datetime_expressionContext.class);
		}
		public Datetime_expressionContext datetime_expression(int i) {
			return getRuleContext(Datetime_expressionContext.class,i);
		}
		public Comparison_operatorContext comparison_operator() {
			return getRuleContext(Comparison_operatorContext.class,0);
		}
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public DatetimeComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetimeComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetimeComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetimeComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityIdOrVersionComparisonContext extends Comparison_expressionContext {
		public Token op;
		public Entity_id_or_version_functionContext entity_id_or_version_function() {
			return getRuleContext(Entity_id_or_version_functionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public EntityIdOrVersionComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntityIdOrVersionComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntityIdOrVersionComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntityIdOrVersionComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityTypeComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Entity_type_expressionContext> entity_type_expression() {
			return getRuleContexts(Entity_type_expressionContext.class);
		}
		public Entity_type_expressionContext entity_type_expression(int i) {
			return getRuleContext(Entity_type_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public EntityTypeComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntityTypeComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntityTypeComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntityTypeComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RegexpComparisonContext extends Comparison_expressionContext {
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public TerminalNode REGEXP() { return getToken(JpqlParser.REGEXP, 0); }
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public RegexpComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterRegexpComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitRegexpComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitRegexpComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EnumComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Enum_expressionContext> enum_expression() {
			return getRuleContexts(Enum_expressionContext.class);
		}
		public Enum_expressionContext enum_expression(int i) {
			return getRuleContext(Enum_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public EnumComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEnumComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEnumComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEnumComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArithmeticComparisonContext extends Comparison_expressionContext {
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public Comparison_operatorContext comparison_operator() {
			return getRuleContext(Comparison_operatorContext.class,0);
		}
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public ArithmeticComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmeticComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmeticComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmeticComparison(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Comparison_expressionContext comparison_expression() throws RecognitionException {
		Comparison_expressionContext _localctx = new Comparison_expressionContext(_ctx, getState());
		enterRule(_localctx, 148, RULE_comparison_expression);
		int _la;
		try {
			setState(1037);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,119,_ctx) ) {
			case 1:
				_localctx = new StringComparisonContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(988);
				string_expression(0);
				setState(989);
				comparison_operator();
				setState(992);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__13:
				case T__14:
				case AS:
				case AVG:
				case CASE:
				case CAST:
				case COALESCE:
				case CONCAT:
				case COUNT:
				case DATE:
				case DOUBLE:
				case FLOAT:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case ID:
				case INNER:
				case INTEGER:
				case KEY:
				case LEFT:
				case LONG:
				case LOWER:
				case MAX:
				case MIN:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case REPLACE:
				case RIGHT:
				case SIGN:
				case STRING:
				case SUBSTRING:
				case SUM:
				case TIME:
				case TREAT:
				case TRIM:
				case TYPE:
				case UPPER:
				case VALUE:
				case VERSION:
				case CHARACTER:
				case IDENTIFICATION_VARIABLE:
				case STRINGLITERAL:
					{
					setState(990);
					string_expression(0);
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(991);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 2:
				_localctx = new BooleanComparisonContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(994);
				boolean_expression();
				setState(995);
				((BooleanComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((BooleanComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(998);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__13:
				case T__14:
				case AS:
				case CASE:
				case COALESCE:
				case COUNT:
				case DATE:
				case DOUBLE:
				case FALSE:
				case FLOAT:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case ID:
				case INNER:
				case INTEGER:
				case KEY:
				case LEFT:
				case LONG:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case RIGHT:
				case SIGN:
				case STRING:
				case TIME:
				case TREAT:
				case TRUE:
				case TYPE:
				case VALUE:
				case VERSION:
				case IDENTIFICATION_VARIABLE:
					{
					setState(996);
					boolean_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(997);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 3:
				_localctx = new DirectBooleanCheckContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(1000);
				boolean_expression();
				}
				break;
			case 4:
				_localctx = new EnumComparisonContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(1001);
				enum_expression();
				setState(1002);
				((EnumComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EnumComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1005);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__13:
				case T__14:
				case AS:
				case CASE:
				case COALESCE:
				case COUNT:
				case DATE:
				case DOUBLE:
				case FLOAT:
				case FLOOR:
				case FROM:
				case ID:
				case INNER:
				case INTEGER:
				case KEY:
				case LEFT:
				case LONG:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case RIGHT:
				case SIGN:
				case STRING:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case VERSION:
				case IDENTIFICATION_VARIABLE:
					{
					setState(1003);
					enum_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(1004);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 5:
				_localctx = new DatetimeComparisonContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(1007);
				datetime_expression();
				setState(1008);
				comparison_operator();
				setState(1011);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__13:
				case T__14:
				case AS:
				case AVG:
				case CASE:
				case COALESCE:
				case COUNT:
				case CURRENT_DATE:
				case CURRENT_TIME:
				case CURRENT_TIMESTAMP:
				case DATE:
				case DOUBLE:
				case EXTRACT:
				case FLOAT:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case ID:
				case INNER:
				case INTEGER:
				case KEY:
				case LEFT:
				case LOCAL:
				case LONG:
				case MAX:
				case MIN:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case RIGHT:
				case SIGN:
				case STRING:
				case SUM:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case VERSION:
				case IDENTIFICATION_VARIABLE:
				case STRINGLITERAL:
				case TIMESTAMP_ESCAPE_START:
				case DATE_ESCAPE_START:
				case TIME_ESCAPE_START:
					{
					setState(1009);
					datetime_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(1010);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 6:
				_localctx = new EntityComparisonContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(1013);
				entity_expression();
				setState(1014);
				((EntityComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EntityComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1017);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__13:
				case T__14:
				case AS:
				case COUNT:
				case DATE:
				case DOUBLE:
				case FLOAT:
				case FLOOR:
				case FROM:
				case ID:
				case INNER:
				case INTEGER:
				case KEY:
				case LEFT:
				case LONG:
				case NEW:
				case ORDER:
				case OUTER:
				case POWER:
				case RIGHT:
				case SIGN:
				case STRING:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case VERSION:
				case IDENTIFICATION_VARIABLE:
					{
					setState(1015);
					entity_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(1016);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 7:
				_localctx = new ArithmeticComparisonContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(1019);
				arithmetic_expression(0);
				setState(1020);
				comparison_operator();
				setState(1023);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__8:
				case T__9:
				case T__13:
				case T__14:
				case ABS:
				case AS:
				case AVG:
				case CASE:
				case CAST:
				case CEILING:
				case COALESCE:
				case COUNT:
				case DATE:
				case DOUBLE:
				case EXP:
				case EXTRACT:
				case FLOAT:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case ID:
				case INDEX:
				case INNER:
				case INTEGER:
				case KEY:
				case LEFT:
				case LENGTH:
				case LN:
				case LOCATE:
				case LONG:
				case MAX:
				case MIN:
				case MOD:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case RIGHT:
				case ROUND:
				case SIGN:
				case SIZE:
				case SQRT:
				case STRING:
				case SUM:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case VERSION:
				case IDENTIFICATION_VARIABLE:
				case FLOATLITERAL:
				case INTLITERAL:
				case LONGLITERAL:
					{
					setState(1021);
					arithmetic_expression(0);
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(1022);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 8:
				_localctx = new EntityIdOrVersionComparisonContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(1025);
				entity_id_or_version_function();
				setState(1026);
				((EntityIdOrVersionComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EntityIdOrVersionComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1027);
				input_parameter();
				}
				break;
			case 9:
				_localctx = new EntityTypeComparisonContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(1029);
				entity_type_expression();
				setState(1030);
				((EntityTypeComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EntityTypeComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(1031);
				entity_type_expression();
				}
				break;
			case 10:
				_localctx = new RegexpComparisonContext(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(1033);
				string_expression(0);
				setState(1034);
				match(REGEXP);
				setState(1035);
				string_literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Comparison_operatorContext extends ParserRuleContext {
		public Token op;
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public Comparison_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparison_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterComparison_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitComparison_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitComparison_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Comparison_operatorContext comparison_operator() throws RecognitionException {
		Comparison_operatorContext _localctx = new Comparison_operatorContext(_ctx, getState());
		enterRule(_localctx, 150, RULE_comparison_operator);
		try {
			setState(1045);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EQUAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1039);
				((Comparison_operatorContext)_localctx).op = match(EQUAL);
				}
				break;
			case T__4:
				enterOuterAlt(_localctx, 2);
				{
				setState(1040);
				((Comparison_operatorContext)_localctx).op = match(T__4);
				}
				break;
			case T__5:
				enterOuterAlt(_localctx, 3);
				{
				setState(1041);
				((Comparison_operatorContext)_localctx).op = match(T__5);
				}
				break;
			case T__6:
				enterOuterAlt(_localctx, 4);
				{
				setState(1042);
				((Comparison_operatorContext)_localctx).op = match(T__6);
				}
				break;
			case T__7:
				enterOuterAlt(_localctx, 5);
				{
				setState(1043);
				((Comparison_operatorContext)_localctx).op = match(T__7);
				}
				break;
			case NOT_EQUAL:
				enterOuterAlt(_localctx, 6);
				{
				setState(1044);
				((Comparison_operatorContext)_localctx).op = match(NOT_EQUAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_expressionContext extends ParserRuleContext {
		public Token op;
		public Arithmetic_termContext arithmetic_term() {
			return getRuleContext(Arithmetic_termContext.class,0);
		}
		public Arithmetic_expressionContext arithmetic_expression() {
			return getRuleContext(Arithmetic_expressionContext.class,0);
		}
		public Arithmetic_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_expressionContext arithmetic_expression() throws RecognitionException {
		return arithmetic_expression(0);
	}

	private Arithmetic_expressionContext arithmetic_expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Arithmetic_expressionContext _localctx = new Arithmetic_expressionContext(_ctx, _parentState);
		Arithmetic_expressionContext _prevctx = _localctx;
		int _startState = 152;
		enterRecursionRule(_localctx, 152, RULE_arithmetic_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(1048);
			arithmetic_term(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(1055);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,121,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Arithmetic_expressionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_arithmetic_expression);
					setState(1050);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(1051);
					((Arithmetic_expressionContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==T__8 || _la==T__9) ) {
						((Arithmetic_expressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(1052);
					arithmetic_term(0);
					}
					} 
				}
				setState(1057);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,121,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_termContext extends ParserRuleContext {
		public Token op;
		public Arithmetic_factorContext arithmetic_factor() {
			return getRuleContext(Arithmetic_factorContext.class,0);
		}
		public Arithmetic_termContext arithmetic_term() {
			return getRuleContext(Arithmetic_termContext.class,0);
		}
		public Arithmetic_termContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_term(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_term(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_termContext arithmetic_term() throws RecognitionException {
		return arithmetic_term(0);
	}

	private Arithmetic_termContext arithmetic_term(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Arithmetic_termContext _localctx = new Arithmetic_termContext(_ctx, _parentState);
		Arithmetic_termContext _prevctx = _localctx;
		int _startState = 154;
		enterRecursionRule(_localctx, 154, RULE_arithmetic_term, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(1059);
			arithmetic_factor();
			}
			_ctx.stop = _input.LT(-1);
			setState(1066);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,122,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Arithmetic_termContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_arithmetic_term);
					setState(1061);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(1062);
					((Arithmetic_termContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==T__10 || _la==T__11) ) {
						((Arithmetic_termContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(1063);
					arithmetic_factor();
					}
					} 
				}
				setState(1068);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,122,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_factorContext extends ParserRuleContext {
		public Token op;
		public Arithmetic_primaryContext arithmetic_primary() {
			return getRuleContext(Arithmetic_primaryContext.class,0);
		}
		public Arithmetic_factorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_factor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_factor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_factorContext arithmetic_factor() throws RecognitionException {
		Arithmetic_factorContext _localctx = new Arithmetic_factorContext(_ctx, getState());
		enterRule(_localctx, 156, RULE_arithmetic_factor);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1070);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__8 || _la==T__9) {
				{
				setState(1069);
				((Arithmetic_factorContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==T__8 || _la==T__9) ) {
					((Arithmetic_factorContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			setState(1072);
			arithmetic_primary();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_primaryContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Numeric_literalContext numeric_literal() {
			return getRuleContext(Numeric_literalContext.class,0);
		}
		public Arithmetic_expressionContext arithmetic_expression() {
			return getRuleContext(Arithmetic_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Functions_returning_numericsContext functions_returning_numerics() {
			return getRuleContext(Functions_returning_numericsContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Arithmetic_cast_functionContext arithmetic_cast_function() {
			return getRuleContext(Arithmetic_cast_functionContext.class,0);
		}
		public Type_cast_functionContext type_cast_function() {
			return getRuleContext(Type_cast_functionContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Arithmetic_primaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_primary; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_primary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_primary(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_primary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_primaryContext arithmetic_primary() throws RecognitionException {
		Arithmetic_primaryContext _localctx = new Arithmetic_primaryContext(_ctx, getState());
		enterRule(_localctx, 158, RULE_arithmetic_primary);
		try {
			setState(1090);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,124,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1074);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1075);
				numeric_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1076);
				match(T__1);
				setState(1077);
				arithmetic_expression(0);
				setState(1078);
				match(T__2);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1080);
				input_parameter();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1081);
				functions_returning_numerics();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1082);
				aggregate_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1083);
				case_expression();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1084);
				arithmetic_cast_function();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1085);
				type_cast_function();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(1086);
				match(T__1);
				setState(1087);
				subquery();
				setState(1088);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class String_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Functions_returning_stringsContext functions_returning_strings() {
			return getRuleContext(Functions_returning_stringsContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public String_cast_functionContext string_cast_function() {
			return getRuleContext(String_cast_functionContext.class,0);
		}
		public Type_cast_functionContext type_cast_function() {
			return getRuleContext(Type_cast_functionContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public String_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterString_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitString_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitString_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final String_expressionContext string_expression() throws RecognitionException {
		return string_expression(0);
	}

	private String_expressionContext string_expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		String_expressionContext _localctx = new String_expressionContext(_ctx, _parentState);
		String_expressionContext _prevctx = _localctx;
		int _startState = 160;
		enterRecursionRule(_localctx, 160, RULE_string_expression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(1105);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,125,_ctx) ) {
			case 1:
				{
				setState(1093);
				state_valued_path_expression();
				}
				break;
			case 2:
				{
				setState(1094);
				string_literal();
				}
				break;
			case 3:
				{
				setState(1095);
				input_parameter();
				}
				break;
			case 4:
				{
				setState(1096);
				functions_returning_strings();
				}
				break;
			case 5:
				{
				setState(1097);
				aggregate_expression();
				}
				break;
			case 6:
				{
				setState(1098);
				case_expression();
				}
				break;
			case 7:
				{
				setState(1099);
				string_cast_function();
				}
				break;
			case 8:
				{
				setState(1100);
				type_cast_function();
				}
				break;
			case 9:
				{
				setState(1101);
				match(T__1);
				setState(1102);
				subquery();
				setState(1103);
				match(T__2);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(1112);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,126,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new String_expressionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_string_expression);
					setState(1107);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(1108);
					match(T__12);
					setState(1109);
					string_expression(2);
					}
					} 
				}
				setState(1114);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,126,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Datetime_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Functions_returning_datetimeContext functions_returning_datetime() {
			return getRuleContext(Functions_returning_datetimeContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Date_time_timestamp_literalContext date_time_timestamp_literal() {
			return getRuleContext(Date_time_timestamp_literalContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Datetime_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetime_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetime_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetime_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetime_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Datetime_expressionContext datetime_expression() throws RecognitionException {
		Datetime_expressionContext _localctx = new Datetime_expressionContext(_ctx, getState());
		enterRule(_localctx, 162, RULE_datetime_expression);
		try {
			setState(1125);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,127,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1115);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1116);
				input_parameter();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1117);
				functions_returning_datetime();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1118);
				aggregate_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1119);
				case_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1120);
				date_time_timestamp_literal();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1121);
				match(T__1);
				setState(1122);
				subquery();
				setState(1123);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Boolean_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Boolean_literalContext boolean_literal() {
			return getRuleContext(Boolean_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Boolean_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolean_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBoolean_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBoolean_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBoolean_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Boolean_expressionContext boolean_expression() throws RecognitionException {
		Boolean_expressionContext _localctx = new Boolean_expressionContext(_ctx, getState());
		enterRule(_localctx, 164, RULE_boolean_expression);
		try {
			setState(1136);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AS:
			case COUNT:
			case DATE:
			case DOUBLE:
			case FLOAT:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case INTEGER:
			case KEY:
			case LEFT:
			case LONG:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case STRING:
			case TIME:
			case TREAT:
			case TYPE:
			case VALUE:
			case VERSION:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1127);
				state_valued_path_expression();
				}
				break;
			case FALSE:
			case TRUE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1128);
				boolean_literal();
				}
				break;
			case T__13:
			case T__14:
				enterOuterAlt(_localctx, 3);
				{
				setState(1129);
				input_parameter();
				}
				break;
			case CASE:
			case COALESCE:
			case NULLIF:
				enterOuterAlt(_localctx, 4);
				{
				setState(1130);
				case_expression();
				}
				break;
			case FUNCTION:
				enterOuterAlt(_localctx, 5);
				{
				setState(1131);
				function_invocation();
				}
				break;
			case T__1:
				enterOuterAlt(_localctx, 6);
				{
				setState(1132);
				match(T__1);
				setState(1133);
				subquery();
				setState(1134);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Enum_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Enum_literalContext enum_literal() {
			return getRuleContext(Enum_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Enum_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_enum_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEnum_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEnum_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEnum_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Enum_expressionContext enum_expression() throws RecognitionException {
		Enum_expressionContext _localctx = new Enum_expressionContext(_ctx, getState());
		enterRule(_localctx, 166, RULE_enum_expression);
		try {
			setState(1146);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,129,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1138);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1139);
				enum_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1140);
				input_parameter();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1141);
				case_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1142);
				match(T__1);
				setState(1143);
				subquery();
				setState(1144);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_expressionContext extends ParserRuleContext {
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Simple_entity_expressionContext simple_entity_expression() {
			return getRuleContext(Simple_entity_expressionContext.class,0);
		}
		public Entity_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_expressionContext entity_expression() throws RecognitionException {
		Entity_expressionContext _localctx = new Entity_expressionContext(_ctx, getState());
		enterRule(_localctx, 168, RULE_entity_expression);
		try {
			setState(1150);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,130,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1148);
				single_valued_object_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1149);
				simple_entity_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_entity_expressionContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Simple_entity_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_entity_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_entity_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_entity_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_entity_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_entity_expressionContext simple_entity_expression() throws RecognitionException {
		Simple_entity_expressionContext _localctx = new Simple_entity_expressionContext(_ctx, getState());
		enterRule(_localctx, 170, RULE_simple_entity_expression);
		try {
			setState(1154);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AS:
			case COUNT:
			case DATE:
			case DOUBLE:
			case FLOAT:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case INTEGER:
			case KEY:
			case LEFT:
			case LONG:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case STRING:
			case TIME:
			case TYPE:
			case VALUE:
			case VERSION:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1152);
				identification_variable();
				}
				break;
			case T__13:
			case T__14:
				enterOuterAlt(_localctx, 2);
				{
				setState(1153);
				input_parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_type_expressionContext extends ParserRuleContext {
		public Type_discriminatorContext type_discriminator() {
			return getRuleContext(Type_discriminatorContext.class,0);
		}
		public Entity_type_literalContext entity_type_literal() {
			return getRuleContext(Entity_type_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Entity_type_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_type_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_type_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_type_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_type_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_type_expressionContext entity_type_expression() throws RecognitionException {
		Entity_type_expressionContext _localctx = new Entity_type_expressionContext(_ctx, getState());
		enterRule(_localctx, 172, RULE_entity_type_expression);
		try {
			setState(1159);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,132,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1156);
				type_discriminator();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1157);
				entity_type_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1158);
				input_parameter();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Type_discriminatorContext extends ParserRuleContext {
		public TerminalNode TYPE() { return getToken(JpqlParser.TYPE, 0); }
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Type_discriminatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_discriminator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterType_discriminator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitType_discriminator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitType_discriminator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Type_discriminatorContext type_discriminator() throws RecognitionException {
		Type_discriminatorContext _localctx = new Type_discriminatorContext(_ctx, getState());
		enterRule(_localctx, 174, RULE_type_discriminator);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1161);
			match(TYPE);
			setState(1162);
			match(T__1);
			setState(1166);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,133,_ctx) ) {
			case 1:
				{
				setState(1163);
				general_identification_variable();
				}
				break;
			case 2:
				{
				setState(1164);
				single_valued_object_path_expression();
				}
				break;
			case 3:
				{
				setState(1165);
				input_parameter();
				}
				break;
			}
			setState(1168);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Functions_returning_numericsContext extends ParserRuleContext {
		public TerminalNode LENGTH() { return getToken(JpqlParser.LENGTH, 0); }
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public TerminalNode LOCATE() { return getToken(JpqlParser.LOCATE, 0); }
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public TerminalNode ABS() { return getToken(JpqlParser.ABS, 0); }
		public TerminalNode CEILING() { return getToken(JpqlParser.CEILING, 0); }
		public TerminalNode EXP() { return getToken(JpqlParser.EXP, 0); }
		public TerminalNode FLOOR() { return getToken(JpqlParser.FLOOR, 0); }
		public TerminalNode LN() { return getToken(JpqlParser.LN, 0); }
		public TerminalNode SIGN() { return getToken(JpqlParser.SIGN, 0); }
		public TerminalNode SQRT() { return getToken(JpqlParser.SQRT, 0); }
		public TerminalNode MOD() { return getToken(JpqlParser.MOD, 0); }
		public TerminalNode POWER() { return getToken(JpqlParser.POWER, 0); }
		public TerminalNode ROUND() { return getToken(JpqlParser.ROUND, 0); }
		public TerminalNode SIZE() { return getToken(JpqlParser.SIZE, 0); }
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public TerminalNode INDEX() { return getToken(JpqlParser.INDEX, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Extract_datetime_fieldContext extract_datetime_field() {
			return getRuleContext(Extract_datetime_fieldContext.class,0);
		}
		public Functions_returning_numericsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions_returning_numerics; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunctions_returning_numerics(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunctions_returning_numerics(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunctions_returning_numerics(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Functions_returning_numericsContext functions_returning_numerics() throws RecognitionException {
		Functions_returning_numericsContext _localctx = new Functions_returning_numericsContext(_ctx, getState());
		enterRule(_localctx, 176, RULE_functions_returning_numerics);
		int _la;
		try {
			setState(1253);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LENGTH:
				enterOuterAlt(_localctx, 1);
				{
				setState(1170);
				match(LENGTH);
				setState(1171);
				match(T__1);
				setState(1172);
				string_expression(0);
				setState(1173);
				match(T__2);
				}
				break;
			case LOCATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1175);
				match(LOCATE);
				setState(1176);
				match(T__1);
				setState(1177);
				string_expression(0);
				setState(1178);
				match(T__0);
				setState(1179);
				string_expression(0);
				setState(1182);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1180);
					match(T__0);
					setState(1181);
					arithmetic_expression(0);
					}
				}

				setState(1184);
				match(T__2);
				}
				break;
			case ABS:
				enterOuterAlt(_localctx, 3);
				{
				setState(1186);
				match(ABS);
				setState(1187);
				match(T__1);
				setState(1188);
				arithmetic_expression(0);
				setState(1189);
				match(T__2);
				}
				break;
			case CEILING:
				enterOuterAlt(_localctx, 4);
				{
				setState(1191);
				match(CEILING);
				setState(1192);
				match(T__1);
				setState(1193);
				arithmetic_expression(0);
				setState(1194);
				match(T__2);
				}
				break;
			case EXP:
				enterOuterAlt(_localctx, 5);
				{
				setState(1196);
				match(EXP);
				setState(1197);
				match(T__1);
				setState(1198);
				arithmetic_expression(0);
				setState(1199);
				match(T__2);
				}
				break;
			case FLOOR:
				enterOuterAlt(_localctx, 6);
				{
				setState(1201);
				match(FLOOR);
				setState(1202);
				match(T__1);
				setState(1203);
				arithmetic_expression(0);
				setState(1204);
				match(T__2);
				}
				break;
			case LN:
				enterOuterAlt(_localctx, 7);
				{
				setState(1206);
				match(LN);
				setState(1207);
				match(T__1);
				setState(1208);
				arithmetic_expression(0);
				setState(1209);
				match(T__2);
				}
				break;
			case SIGN:
				enterOuterAlt(_localctx, 8);
				{
				setState(1211);
				match(SIGN);
				setState(1212);
				match(T__1);
				setState(1213);
				arithmetic_expression(0);
				setState(1214);
				match(T__2);
				}
				break;
			case SQRT:
				enterOuterAlt(_localctx, 9);
				{
				setState(1216);
				match(SQRT);
				setState(1217);
				match(T__1);
				setState(1218);
				arithmetic_expression(0);
				setState(1219);
				match(T__2);
				}
				break;
			case MOD:
				enterOuterAlt(_localctx, 10);
				{
				setState(1221);
				match(MOD);
				setState(1222);
				match(T__1);
				setState(1223);
				arithmetic_expression(0);
				setState(1224);
				match(T__0);
				setState(1225);
				arithmetic_expression(0);
				setState(1226);
				match(T__2);
				}
				break;
			case POWER:
				enterOuterAlt(_localctx, 11);
				{
				setState(1228);
				match(POWER);
				setState(1229);
				match(T__1);
				setState(1230);
				arithmetic_expression(0);
				setState(1231);
				match(T__0);
				setState(1232);
				arithmetic_expression(0);
				setState(1233);
				match(T__2);
				}
				break;
			case ROUND:
				enterOuterAlt(_localctx, 12);
				{
				setState(1235);
				match(ROUND);
				setState(1236);
				match(T__1);
				setState(1237);
				arithmetic_expression(0);
				setState(1238);
				match(T__0);
				setState(1239);
				arithmetic_expression(0);
				setState(1240);
				match(T__2);
				}
				break;
			case SIZE:
				enterOuterAlt(_localctx, 13);
				{
				setState(1242);
				match(SIZE);
				setState(1243);
				match(T__1);
				setState(1244);
				collection_valued_path_expression();
				setState(1245);
				match(T__2);
				}
				break;
			case INDEX:
				enterOuterAlt(_localctx, 14);
				{
				setState(1247);
				match(INDEX);
				setState(1248);
				match(T__1);
				setState(1249);
				identification_variable();
				setState(1250);
				match(T__2);
				}
				break;
			case EXTRACT:
				enterOuterAlt(_localctx, 15);
				{
				setState(1252);
				extract_datetime_field();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Functions_returning_datetimeContext extends ParserRuleContext {
		public TerminalNode CURRENT_DATE() { return getToken(JpqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT_TIME() { return getToken(JpqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(JpqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode LOCAL() { return getToken(JpqlParser.LOCAL, 0); }
		public TerminalNode DATE() { return getToken(JpqlParser.DATE, 0); }
		public TerminalNode TIME() { return getToken(JpqlParser.TIME, 0); }
		public TerminalNode DATETIME() { return getToken(JpqlParser.DATETIME, 0); }
		public Extract_datetime_partContext extract_datetime_part() {
			return getRuleContext(Extract_datetime_partContext.class,0);
		}
		public Functions_returning_datetimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions_returning_datetime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunctions_returning_datetime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunctions_returning_datetime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunctions_returning_datetime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Functions_returning_datetimeContext functions_returning_datetime() throws RecognitionException {
		Functions_returning_datetimeContext _localctx = new Functions_returning_datetimeContext(_ctx, getState());
		enterRule(_localctx, 178, RULE_functions_returning_datetime);
		try {
			setState(1265);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,136,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1255);
				match(CURRENT_DATE);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1256);
				match(CURRENT_TIME);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1257);
				match(CURRENT_TIMESTAMP);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1258);
				match(LOCAL);
				setState(1259);
				match(DATE);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1260);
				match(LOCAL);
				setState(1261);
				match(TIME);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1262);
				match(LOCAL);
				setState(1263);
				match(DATETIME);
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1264);
				extract_datetime_part();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Functions_returning_stringsContext extends ParserRuleContext {
		public TerminalNode CONCAT() { return getToken(JpqlParser.CONCAT, 0); }
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public TerminalNode SUBSTRING() { return getToken(JpqlParser.SUBSTRING, 0); }
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public TerminalNode TRIM() { return getToken(JpqlParser.TRIM, 0); }
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Trim_specificationContext trim_specification() {
			return getRuleContext(Trim_specificationContext.class,0);
		}
		public Trim_characterContext trim_character() {
			return getRuleContext(Trim_characterContext.class,0);
		}
		public TerminalNode LOWER() { return getToken(JpqlParser.LOWER, 0); }
		public TerminalNode UPPER() { return getToken(JpqlParser.UPPER, 0); }
		public TerminalNode REPLACE() { return getToken(JpqlParser.REPLACE, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode RIGHT() { return getToken(JpqlParser.RIGHT, 0); }
		public Functions_returning_stringsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions_returning_strings; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunctions_returning_strings(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunctions_returning_strings(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunctions_returning_strings(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Functions_returning_stringsContext functions_returning_strings() throws RecognitionException {
		Functions_returning_stringsContext _localctx = new Functions_returning_stringsContext(_ctx, getState());
		enterRule(_localctx, 180, RULE_functions_returning_strings);
		int _la;
		try {
			setState(1339);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONCAT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1267);
				match(CONCAT);
				setState(1268);
				match(T__1);
				setState(1269);
				string_expression(0);
				setState(1270);
				match(T__0);
				setState(1271);
				string_expression(0);
				setState(1276);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1272);
					match(T__0);
					setState(1273);
					string_expression(0);
					}
					}
					setState(1278);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1279);
				match(T__2);
				}
				break;
			case SUBSTRING:
				enterOuterAlt(_localctx, 2);
				{
				setState(1281);
				match(SUBSTRING);
				setState(1282);
				match(T__1);
				setState(1283);
				string_expression(0);
				setState(1284);
				match(T__0);
				setState(1285);
				arithmetic_expression(0);
				setState(1288);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1286);
					match(T__0);
					setState(1287);
					arithmetic_expression(0);
					}
				}

				setState(1290);
				match(T__2);
				}
				break;
			case TRIM:
				enterOuterAlt(_localctx, 3);
				{
				setState(1292);
				match(TRIM);
				setState(1293);
				match(T__1);
				setState(1301);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,141,_ctx) ) {
				case 1:
					{
					setState(1295);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==BOTH || _la==LEADING || _la==TRAILING) {
						{
						setState(1294);
						trim_specification();
						}
					}

					setState(1298);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==T__13 || _la==T__14 || _la==CHARACTER) {
						{
						setState(1297);
						trim_character();
						}
					}

					setState(1300);
					match(FROM);
					}
					break;
				}
				setState(1303);
				string_expression(0);
				setState(1304);
				match(T__2);
				}
				break;
			case LOWER:
				enterOuterAlt(_localctx, 4);
				{
				setState(1306);
				match(LOWER);
				setState(1307);
				match(T__1);
				setState(1308);
				string_expression(0);
				setState(1309);
				match(T__2);
				}
				break;
			case UPPER:
				enterOuterAlt(_localctx, 5);
				{
				setState(1311);
				match(UPPER);
				setState(1312);
				match(T__1);
				setState(1313);
				string_expression(0);
				setState(1314);
				match(T__2);
				}
				break;
			case REPLACE:
				enterOuterAlt(_localctx, 6);
				{
				setState(1316);
				match(REPLACE);
				setState(1317);
				match(T__1);
				setState(1318);
				string_expression(0);
				setState(1319);
				match(T__0);
				setState(1320);
				string_expression(0);
				setState(1321);
				match(T__0);
				setState(1322);
				string_expression(0);
				setState(1323);
				match(T__2);
				}
				break;
			case LEFT:
				enterOuterAlt(_localctx, 7);
				{
				setState(1325);
				match(LEFT);
				setState(1326);
				match(T__1);
				setState(1327);
				string_expression(0);
				setState(1328);
				match(T__0);
				setState(1329);
				arithmetic_expression(0);
				setState(1330);
				match(T__2);
				}
				break;
			case RIGHT:
				enterOuterAlt(_localctx, 8);
				{
				setState(1332);
				match(RIGHT);
				setState(1333);
				match(T__1);
				setState(1334);
				string_expression(0);
				setState(1335);
				match(T__0);
				setState(1336);
				arithmetic_expression(0);
				setState(1337);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Trim_specificationContext extends ParserRuleContext {
		public TerminalNode LEADING() { return getToken(JpqlParser.LEADING, 0); }
		public TerminalNode TRAILING() { return getToken(JpqlParser.TRAILING, 0); }
		public TerminalNode BOTH() { return getToken(JpqlParser.BOTH, 0); }
		public Trim_specificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trim_specification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTrim_specification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTrim_specification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTrim_specification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Trim_specificationContext trim_specification() throws RecognitionException {
		Trim_specificationContext _localctx = new Trim_specificationContext(_ctx, getState());
		enterRule(_localctx, 182, RULE_trim_specification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1341);
			_la = _input.LA(1);
			if ( !(_la==BOTH || _la==LEADING || _la==TRAILING) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_cast_functionContext extends ParserRuleContext {
		public Token f;
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public TerminalNode INTEGER() { return getToken(JpqlParser.INTEGER, 0); }
		public TerminalNode LONG() { return getToken(JpqlParser.LONG, 0); }
		public TerminalNode FLOAT() { return getToken(JpqlParser.FLOAT, 0); }
		public TerminalNode DOUBLE() { return getToken(JpqlParser.DOUBLE, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Arithmetic_cast_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_cast_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_cast_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_cast_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_cast_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_cast_functionContext arithmetic_cast_function() throws RecognitionException {
		Arithmetic_cast_functionContext _localctx = new Arithmetic_cast_functionContext(_ctx, getState());
		enterRule(_localctx, 184, RULE_arithmetic_cast_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1343);
			match(CAST);
			setState(1344);
			match(T__1);
			setState(1345);
			string_expression(0);
			setState(1347);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1346);
				match(AS);
				}
			}

			setState(1349);
			((Arithmetic_cast_functionContext)_localctx).f = _input.LT(1);
			_la = _input.LA(1);
			if ( !(((((_la - 43)) & ~0x3f) == 0 && ((1L << (_la - 43)) & 68727873537L) != 0)) ) {
				((Arithmetic_cast_functionContext)_localctx).f = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1350);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Type_cast_functionContext extends ParserRuleContext {
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public List<Numeric_literalContext> numeric_literal() {
			return getRuleContexts(Numeric_literalContext.class);
		}
		public Numeric_literalContext numeric_literal(int i) {
			return getRuleContext(Numeric_literalContext.class,i);
		}
		public Type_cast_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_cast_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterType_cast_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitType_cast_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitType_cast_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Type_cast_functionContext type_cast_function() throws RecognitionException {
		Type_cast_functionContext _localctx = new Type_cast_functionContext(_ctx, getState());
		enterRule(_localctx, 186, RULE_type_cast_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1352);
			match(CAST);
			setState(1353);
			match(T__1);
			setState(1354);
			scalar_expression();
			setState(1356);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,144,_ctx) ) {
			case 1:
				{
				setState(1355);
				match(AS);
				}
				break;
			}
			setState(1358);
			identification_variable();
			setState(1370);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(1359);
				match(T__1);
				setState(1360);
				numeric_literal();
				setState(1365);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1361);
					match(T__0);
					setState(1362);
					numeric_literal();
					}
					}
					setState(1367);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1368);
				match(T__2);
				}
			}

			setState(1372);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class String_cast_functionContext extends ParserRuleContext {
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public TerminalNode STRING() { return getToken(JpqlParser.STRING, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public String_cast_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string_cast_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterString_cast_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitString_cast_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitString_cast_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final String_cast_functionContext string_cast_function() throws RecognitionException {
		String_cast_functionContext _localctx = new String_cast_functionContext(_ctx, getState());
		enterRule(_localctx, 188, RULE_string_cast_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1374);
			match(CAST);
			setState(1375);
			match(T__1);
			setState(1376);
			scalar_expression();
			setState(1378);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1377);
				match(AS);
				}
			}

			setState(1380);
			match(STRING);
			setState(1381);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_id_or_version_functionContext extends ParserRuleContext {
		public Id_functionContext id_function() {
			return getRuleContext(Id_functionContext.class,0);
		}
		public Version_functionContext version_function() {
			return getRuleContext(Version_functionContext.class,0);
		}
		public Entity_id_or_version_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_id_or_version_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_id_or_version_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_id_or_version_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_id_or_version_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_id_or_version_functionContext entity_id_or_version_function() throws RecognitionException {
		Entity_id_or_version_functionContext _localctx = new Entity_id_or_version_functionContext(_ctx, getState());
		enterRule(_localctx, 190, RULE_entity_id_or_version_function);
		try {
			setState(1385);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(1383);
				id_function();
				}
				break;
			case VERSION:
				enterOuterAlt(_localctx, 2);
				{
				setState(1384);
				version_function();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Id_functionContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(JpqlParser.ID, 0); }
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Id_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_id_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterId_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitId_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitId_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Id_functionContext id_function() throws RecognitionException {
		Id_functionContext _localctx = new Id_functionContext(_ctx, getState());
		enterRule(_localctx, 192, RULE_id_function);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1387);
			match(ID);
			setState(1388);
			match(T__1);
			setState(1391);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,149,_ctx) ) {
			case 1:
				{
				setState(1389);
				general_identification_variable();
				}
				break;
			case 2:
				{
				setState(1390);
				single_valued_object_path_expression();
				}
				break;
			}
			setState(1393);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Version_functionContext extends ParserRuleContext {
		public TerminalNode VERSION() { return getToken(JpqlParser.VERSION, 0); }
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Version_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_version_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterVersion_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitVersion_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitVersion_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Version_functionContext version_function() throws RecognitionException {
		Version_functionContext _localctx = new Version_functionContext(_ctx, getState());
		enterRule(_localctx, 194, RULE_version_function);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1395);
			match(VERSION);
			setState(1396);
			match(T__1);
			setState(1399);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,150,_ctx) ) {
			case 1:
				{
				setState(1397);
				general_identification_variable();
				}
				break;
			case 2:
				{
				setState(1398);
				single_valued_object_path_expression();
				}
				break;
			}
			setState(1401);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_invocationContext extends ParserRuleContext {
		public TerminalNode FUNCTION() { return getToken(JpqlParser.FUNCTION, 0); }
		public Function_nameContext function_name() {
			return getRuleContext(Function_nameContext.class,0);
		}
		public List<Function_argContext> function_arg() {
			return getRuleContexts(Function_argContext.class);
		}
		public Function_argContext function_arg(int i) {
			return getRuleContext(Function_argContext.class,i);
		}
		public Function_invocationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_invocation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunction_invocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunction_invocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunction_invocation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_invocationContext function_invocation() throws RecognitionException {
		Function_invocationContext _localctx = new Function_invocationContext(_ctx, getState());
		enterRule(_localctx, 196, RULE_function_invocation);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1403);
			match(FUNCTION);
			setState(1404);
			match(T__1);
			setState(1405);
			function_name();
			setState(1410);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1406);
				match(T__0);
				setState(1407);
				function_arg();
				}
				}
				setState(1412);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1413);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Extract_datetime_fieldContext extends ParserRuleContext {
		public TerminalNode EXTRACT() { return getToken(JpqlParser.EXTRACT, 0); }
		public Datetime_fieldContext datetime_field() {
			return getRuleContext(Datetime_fieldContext.class,0);
		}
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Datetime_expressionContext datetime_expression() {
			return getRuleContext(Datetime_expressionContext.class,0);
		}
		public Extract_datetime_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extract_datetime_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterExtract_datetime_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitExtract_datetime_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitExtract_datetime_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Extract_datetime_fieldContext extract_datetime_field() throws RecognitionException {
		Extract_datetime_fieldContext _localctx = new Extract_datetime_fieldContext(_ctx, getState());
		enterRule(_localctx, 198, RULE_extract_datetime_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1415);
			match(EXTRACT);
			setState(1416);
			match(T__1);
			setState(1417);
			datetime_field();
			setState(1418);
			match(FROM);
			setState(1419);
			datetime_expression();
			setState(1420);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Datetime_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Datetime_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetime_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetime_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetime_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetime_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Datetime_fieldContext datetime_field() throws RecognitionException {
		Datetime_fieldContext _localctx = new Datetime_fieldContext(_ctx, getState());
		enterRule(_localctx, 200, RULE_datetime_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1422);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Extract_datetime_partContext extends ParserRuleContext {
		public TerminalNode EXTRACT() { return getToken(JpqlParser.EXTRACT, 0); }
		public Datetime_partContext datetime_part() {
			return getRuleContext(Datetime_partContext.class,0);
		}
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Datetime_expressionContext datetime_expression() {
			return getRuleContext(Datetime_expressionContext.class,0);
		}
		public Extract_datetime_partContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extract_datetime_part; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterExtract_datetime_part(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitExtract_datetime_part(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitExtract_datetime_part(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Extract_datetime_partContext extract_datetime_part() throws RecognitionException {
		Extract_datetime_partContext _localctx = new Extract_datetime_partContext(_ctx, getState());
		enterRule(_localctx, 202, RULE_extract_datetime_part);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1424);
			match(EXTRACT);
			setState(1425);
			match(T__1);
			setState(1426);
			datetime_part();
			setState(1427);
			match(FROM);
			setState(1428);
			datetime_expression();
			setState(1429);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Datetime_partContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Datetime_partContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetime_part; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetime_part(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetime_part(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetime_part(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Datetime_partContext datetime_part() throws RecognitionException {
		Datetime_partContext _localctx = new Datetime_partContext(_ctx, getState());
		enterRule(_localctx, 204, RULE_datetime_part);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1431);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_argContext extends ParserRuleContext {
		public Simple_select_expressionContext simple_select_expression() {
			return getRuleContext(Simple_select_expressionContext.class,0);
		}
		public Function_argContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_arg; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunction_arg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunction_arg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunction_arg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_argContext function_arg() throws RecognitionException {
		Function_argContext _localctx = new Function_argContext(_ctx, getState());
		enterRule(_localctx, 206, RULE_function_arg);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1433);
			simple_select_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Case_expressionContext extends ParserRuleContext {
		public General_case_expressionContext general_case_expression() {
			return getRuleContext(General_case_expressionContext.class,0);
		}
		public Simple_case_expressionContext simple_case_expression() {
			return getRuleContext(Simple_case_expressionContext.class,0);
		}
		public Coalesce_expressionContext coalesce_expression() {
			return getRuleContext(Coalesce_expressionContext.class,0);
		}
		public Nullif_expressionContext nullif_expression() {
			return getRuleContext(Nullif_expressionContext.class,0);
		}
		public Case_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_case_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCase_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCase_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCase_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Case_expressionContext case_expression() throws RecognitionException {
		Case_expressionContext _localctx = new Case_expressionContext(_ctx, getState());
		enterRule(_localctx, 208, RULE_case_expression);
		try {
			setState(1439);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,152,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1435);
				general_case_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1436);
				simple_case_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1437);
				coalesce_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1438);
				nullif_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_case_expressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(JpqlParser.CASE, 0); }
		public List<When_clauseContext> when_clause() {
			return getRuleContexts(When_clauseContext.class);
		}
		public When_clauseContext when_clause(int i) {
			return getRuleContext(When_clauseContext.class,i);
		}
		public TerminalNode END() { return getToken(JpqlParser.END, 0); }
		public TerminalNode ELSE() { return getToken(JpqlParser.ELSE, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public General_case_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_case_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_case_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_case_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_case_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_case_expressionContext general_case_expression() throws RecognitionException {
		General_case_expressionContext _localctx = new General_case_expressionContext(_ctx, getState());
		enterRule(_localctx, 210, RULE_general_case_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1441);
			match(CASE);
			setState(1442);
			when_clause();
			setState(1446);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WHEN) {
				{
				{
				setState(1443);
				when_clause();
				}
				}
				setState(1448);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1451);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(1449);
				match(ELSE);
				setState(1450);
				scalar_expression();
				}
			}

			setState(1453);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class When_clauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(JpqlParser.WHEN, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public TerminalNode THEN() { return getToken(JpqlParser.THEN, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public When_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_when_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterWhen_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitWhen_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitWhen_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final When_clauseContext when_clause() throws RecognitionException {
		When_clauseContext _localctx = new When_clauseContext(_ctx, getState());
		enterRule(_localctx, 212, RULE_when_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1455);
			match(WHEN);
			setState(1456);
			conditional_expression(0);
			setState(1457);
			match(THEN);
			setState(1458);
			scalar_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_case_expressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(JpqlParser.CASE, 0); }
		public Case_operandContext case_operand() {
			return getRuleContext(Case_operandContext.class,0);
		}
		public List<Simple_when_clauseContext> simple_when_clause() {
			return getRuleContexts(Simple_when_clauseContext.class);
		}
		public Simple_when_clauseContext simple_when_clause(int i) {
			return getRuleContext(Simple_when_clauseContext.class,i);
		}
		public TerminalNode END() { return getToken(JpqlParser.END, 0); }
		public TerminalNode ELSE() { return getToken(JpqlParser.ELSE, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Simple_case_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_case_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_case_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_case_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_case_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_case_expressionContext simple_case_expression() throws RecognitionException {
		Simple_case_expressionContext _localctx = new Simple_case_expressionContext(_ctx, getState());
		enterRule(_localctx, 214, RULE_simple_case_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1460);
			match(CASE);
			setState(1461);
			case_operand();
			setState(1462);
			simple_when_clause();
			setState(1466);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WHEN) {
				{
				{
				setState(1463);
				simple_when_clause();
				}
				}
				setState(1468);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1471);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ELSE) {
				{
				setState(1469);
				match(ELSE);
				setState(1470);
				scalar_expression();
				}
			}

			setState(1473);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Case_operandContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Type_discriminatorContext type_discriminator() {
			return getRuleContext(Type_discriminatorContext.class,0);
		}
		public Case_operandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_case_operand; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCase_operand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCase_operand(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCase_operand(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Case_operandContext case_operand() throws RecognitionException {
		Case_operandContext _localctx = new Case_operandContext(_ctx, getState());
		enterRule(_localctx, 216, RULE_case_operand);
		try {
			setState(1477);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,157,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1475);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1476);
				type_discriminator();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_when_clauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(JpqlParser.WHEN, 0); }
		public List<Scalar_expressionContext> scalar_expression() {
			return getRuleContexts(Scalar_expressionContext.class);
		}
		public Scalar_expressionContext scalar_expression(int i) {
			return getRuleContext(Scalar_expressionContext.class,i);
		}
		public TerminalNode THEN() { return getToken(JpqlParser.THEN, 0); }
		public Simple_when_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_when_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_when_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_when_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_when_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_when_clauseContext simple_when_clause() throws RecognitionException {
		Simple_when_clauseContext _localctx = new Simple_when_clauseContext(_ctx, getState());
		enterRule(_localctx, 218, RULE_simple_when_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1479);
			match(WHEN);
			setState(1480);
			scalar_expression();
			setState(1481);
			match(THEN);
			setState(1482);
			scalar_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Coalesce_expressionContext extends ParserRuleContext {
		public TerminalNode COALESCE() { return getToken(JpqlParser.COALESCE, 0); }
		public List<Scalar_expressionContext> scalar_expression() {
			return getRuleContexts(Scalar_expressionContext.class);
		}
		public Scalar_expressionContext scalar_expression(int i) {
			return getRuleContext(Scalar_expressionContext.class,i);
		}
		public Coalesce_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_coalesce_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCoalesce_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCoalesce_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCoalesce_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Coalesce_expressionContext coalesce_expression() throws RecognitionException {
		Coalesce_expressionContext _localctx = new Coalesce_expressionContext(_ctx, getState());
		enterRule(_localctx, 220, RULE_coalesce_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1484);
			match(COALESCE);
			setState(1485);
			match(T__1);
			setState(1486);
			scalar_expression();
			setState(1489); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1487);
				match(T__0);
				setState(1488);
				scalar_expression();
				}
				}
				setState(1491); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 );
			setState(1493);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Nullif_expressionContext extends ParserRuleContext {
		public TerminalNode NULLIF() { return getToken(JpqlParser.NULLIF, 0); }
		public List<Scalar_expressionContext> scalar_expression() {
			return getRuleContexts(Scalar_expressionContext.class);
		}
		public Scalar_expressionContext scalar_expression(int i) {
			return getRuleContext(Scalar_expressionContext.class,i);
		}
		public Nullif_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullif_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNullif_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNullif_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNullif_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Nullif_expressionContext nullif_expression() throws RecognitionException {
		Nullif_expressionContext _localctx = new Nullif_expressionContext(_ctx, getState());
		enterRule(_localctx, 222, RULE_nullif_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1495);
			match(NULLIF);
			setState(1496);
			match(T__1);
			setState(1497);
			scalar_expression();
			setState(1498);
			match(T__0);
			setState(1499);
			scalar_expression();
			setState(1500);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Trim_characterContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public Character_valued_input_parameterContext character_valued_input_parameter() {
			return getRuleContext(Character_valued_input_parameterContext.class,0);
		}
		public Trim_characterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trim_character; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTrim_character(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTrim_character(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTrim_character(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Trim_characterContext trim_character() throws RecognitionException {
		Trim_characterContext _localctx = new Trim_characterContext(_ctx, getState());
		enterRule(_localctx, 224, RULE_trim_character);
		try {
			setState(1504);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,159,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1502);
				match(CHARACTER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1503);
				character_valued_input_parameter();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Identification_variableContext extends ParserRuleContext {
		public Token f;
		public TerminalNode IDENTIFICATION_VARIABLE() { return getToken(JpqlParser.IDENTIFICATION_VARIABLE, 0); }
		public TerminalNode COUNT() { return getToken(JpqlParser.COUNT, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public TerminalNode DATE() { return getToken(JpqlParser.DATE, 0); }
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public TerminalNode INNER() { return getToken(JpqlParser.INNER, 0); }
		public TerminalNode KEY() { return getToken(JpqlParser.KEY, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode NEW() { return getToken(JpqlParser.NEW, 0); }
		public TerminalNode ORDER() { return getToken(JpqlParser.ORDER, 0); }
		public TerminalNode OUTER() { return getToken(JpqlParser.OUTER, 0); }
		public TerminalNode POWER() { return getToken(JpqlParser.POWER, 0); }
		public TerminalNode RIGHT() { return getToken(JpqlParser.RIGHT, 0); }
		public TerminalNode FLOOR() { return getToken(JpqlParser.FLOOR, 0); }
		public TerminalNode SIGN() { return getToken(JpqlParser.SIGN, 0); }
		public TerminalNode TIME() { return getToken(JpqlParser.TIME, 0); }
		public TerminalNode TYPE() { return getToken(JpqlParser.TYPE, 0); }
		public TerminalNode VALUE() { return getToken(JpqlParser.VALUE, 0); }
		public TerminalNode ID() { return getToken(JpqlParser.ID, 0); }
		public TerminalNode VERSION() { return getToken(JpqlParser.VERSION, 0); }
		public Type_literalContext type_literal() {
			return getRuleContext(Type_literalContext.class,0);
		}
		public Identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIdentification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIdentification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIdentification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Identification_variableContext identification_variable() throws RecognitionException {
		Identification_variableContext _localctx = new Identification_variableContext(_ctx, getState());
		enterRule(_localctx, 226, RULE_identification_variable);
		int _la;
		try {
			setState(1509);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1506);
				match(IDENTIFICATION_VARIABLE);
				}
				break;
			case AS:
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case TIME:
			case TYPE:
			case VALUE:
			case VERSION:
				enterOuterAlt(_localctx, 2);
				{
				setState(1507);
				((Identification_variableContext)_localctx).f = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 5044031874721120256L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 110408855431676193L) != 0)) ) {
					((Identification_variableContext)_localctx).f = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			case DOUBLE:
			case FLOAT:
			case INTEGER:
			case LONG:
			case STRING:
				enterOuterAlt(_localctx, 3);
				{
				setState(1508);
				type_literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Constructor_nameContext extends ParserRuleContext {
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public Constructor_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constructor_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConstructor_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConstructor_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConstructor_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constructor_nameContext constructor_name() throws RecognitionException {
		Constructor_nameContext _localctx = new Constructor_nameContext(_ctx, getState());
		enterRule(_localctx, 228, RULE_constructor_name);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1511);
			entity_name();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LiteralContext extends ParserRuleContext {
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public TerminalNode JAVASTRINGLITERAL() { return getToken(JpqlParser.JAVASTRINGLITERAL, 0); }
		public TerminalNode INTLITERAL() { return getToken(JpqlParser.INTLITERAL, 0); }
		public TerminalNode FLOATLITERAL() { return getToken(JpqlParser.FLOATLITERAL, 0); }
		public TerminalNode LONGLITERAL() { return getToken(JpqlParser.LONGLITERAL, 0); }
		public Boolean_literalContext boolean_literal() {
			return getRuleContext(Boolean_literalContext.class,0);
		}
		public Entity_type_literalContext entity_type_literal() {
			return getRuleContext(Entity_type_literalContext.class,0);
		}
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 230, RULE_literal);
		try {
			setState(1521);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRINGLITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1513);
				match(STRINGLITERAL);
				}
				break;
			case CHARACTER:
				enterOuterAlt(_localctx, 2);
				{
				setState(1514);
				match(CHARACTER);
				}
				break;
			case JAVASTRINGLITERAL:
				enterOuterAlt(_localctx, 3);
				{
				setState(1515);
				match(JAVASTRINGLITERAL);
				}
				break;
			case INTLITERAL:
				enterOuterAlt(_localctx, 4);
				{
				setState(1516);
				match(INTLITERAL);
				}
				break;
			case FLOATLITERAL:
				enterOuterAlt(_localctx, 5);
				{
				setState(1517);
				match(FLOATLITERAL);
				}
				break;
			case LONGLITERAL:
				enterOuterAlt(_localctx, 6);
				{
				setState(1518);
				match(LONGLITERAL);
				}
				break;
			case FALSE:
			case TRUE:
				enterOuterAlt(_localctx, 7);
				{
				setState(1519);
				boolean_literal();
				}
				break;
			case AS:
			case COUNT:
			case DATE:
			case DOUBLE:
			case FLOAT:
			case FLOOR:
			case FROM:
			case ID:
			case INNER:
			case INTEGER:
			case KEY:
			case LEFT:
			case LONG:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case RIGHT:
			case SIGN:
			case STRING:
			case TIME:
			case TYPE:
			case VALUE:
			case VERSION:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 8);
				{
				setState(1520);
				entity_type_literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Input_parameterContext extends ParserRuleContext {
		public TerminalNode INTLITERAL() { return getToken(JpqlParser.INTLITERAL, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterInput_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitInput_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitInput_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Input_parameterContext input_parameter() throws RecognitionException {
		Input_parameterContext _localctx = new Input_parameterContext(_ctx, getState());
		enterRule(_localctx, 232, RULE_input_parameter);
		try {
			setState(1527);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__13:
				enterOuterAlt(_localctx, 1);
				{
				setState(1523);
				match(T__13);
				setState(1524);
				match(INTLITERAL);
				}
				break;
			case T__14:
				enterOuterAlt(_localctx, 2);
				{
				setState(1525);
				match(T__14);
				setState(1526);
				identification_variable();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Pattern_valueContext extends ParserRuleContext {
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Pattern_valueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pattern_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterPattern_value(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitPattern_value(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitPattern_value(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Pattern_valueContext pattern_value() throws RecognitionException {
		Pattern_valueContext _localctx = new Pattern_valueContext(_ctx, getState());
		enterRule(_localctx, 234, RULE_pattern_value);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1529);
			string_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Date_time_timestamp_literalContext extends ParserRuleContext {
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public Jdbc_date_literalContext jdbc_date_literal() {
			return getRuleContext(Jdbc_date_literalContext.class,0);
		}
		public Jdbc_time_literalContext jdbc_time_literal() {
			return getRuleContext(Jdbc_time_literalContext.class,0);
		}
		public Jdbc_timestamp_literalContext jdbc_timestamp_literal() {
			return getRuleContext(Jdbc_timestamp_literalContext.class,0);
		}
		public Date_time_timestamp_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_date_time_timestamp_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDate_time_timestamp_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDate_time_timestamp_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDate_time_timestamp_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Date_time_timestamp_literalContext date_time_timestamp_literal() throws RecognitionException {
		Date_time_timestamp_literalContext _localctx = new Date_time_timestamp_literalContext(_ctx, getState());
		enterRule(_localctx, 236, RULE_date_time_timestamp_literal);
		try {
			setState(1535);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRINGLITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1531);
				match(STRINGLITERAL);
				}
				break;
			case DATE_ESCAPE_START:
				enterOuterAlt(_localctx, 2);
				{
				setState(1532);
				jdbc_date_literal();
				}
				break;
			case TIME_ESCAPE_START:
				enterOuterAlt(_localctx, 3);
				{
				setState(1533);
				jdbc_time_literal();
				}
				break;
			case TIMESTAMP_ESCAPE_START:
				enterOuterAlt(_localctx, 4);
				{
				setState(1534);
				jdbc_timestamp_literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Jdbc_date_literalContext extends ParserRuleContext {
		public TerminalNode DATE_ESCAPE_START() { return getToken(JpqlParser.DATE_ESCAPE_START, 0); }
		public Jdbc_temporal_literal_textContext jdbc_temporal_literal_text() {
			return getRuleContext(Jdbc_temporal_literal_textContext.class,0);
		}
		public Jdbc_date_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbc_date_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJdbc_date_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJdbc_date_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJdbc_date_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Jdbc_date_literalContext jdbc_date_literal() throws RecognitionException {
		Jdbc_date_literalContext _localctx = new Jdbc_date_literalContext(_ctx, getState());
		enterRule(_localctx, 238, RULE_jdbc_date_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1537);
			match(DATE_ESCAPE_START);
			setState(1538);
			jdbc_temporal_literal_text();
			setState(1539);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Jdbc_time_literalContext extends ParserRuleContext {
		public TerminalNode TIME_ESCAPE_START() { return getToken(JpqlParser.TIME_ESCAPE_START, 0); }
		public Jdbc_temporal_literal_textContext jdbc_temporal_literal_text() {
			return getRuleContext(Jdbc_temporal_literal_textContext.class,0);
		}
		public Jdbc_time_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbc_time_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJdbc_time_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJdbc_time_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJdbc_time_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Jdbc_time_literalContext jdbc_time_literal() throws RecognitionException {
		Jdbc_time_literalContext _localctx = new Jdbc_time_literalContext(_ctx, getState());
		enterRule(_localctx, 240, RULE_jdbc_time_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1541);
			match(TIME_ESCAPE_START);
			setState(1542);
			jdbc_temporal_literal_text();
			setState(1543);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Jdbc_timestamp_literalContext extends ParserRuleContext {
		public TerminalNode TIMESTAMP_ESCAPE_START() { return getToken(JpqlParser.TIMESTAMP_ESCAPE_START, 0); }
		public Jdbc_temporal_literal_textContext jdbc_temporal_literal_text() {
			return getRuleContext(Jdbc_temporal_literal_textContext.class,0);
		}
		public Jdbc_timestamp_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbc_timestamp_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJdbc_timestamp_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJdbc_timestamp_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJdbc_timestamp_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Jdbc_timestamp_literalContext jdbc_timestamp_literal() throws RecognitionException {
		Jdbc_timestamp_literalContext _localctx = new Jdbc_timestamp_literalContext(_ctx, getState());
		enterRule(_localctx, 242, RULE_jdbc_timestamp_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1545);
			match(TIMESTAMP_ESCAPE_START);
			setState(1546);
			jdbc_temporal_literal_text();
			setState(1547);
			match(T__15);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Jdbc_temporal_literal_textContext extends ParserRuleContext {
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public Jdbc_temporal_literal_textContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_jdbc_temporal_literal_text; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJdbc_temporal_literal_text(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJdbc_temporal_literal_text(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJdbc_temporal_literal_text(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Jdbc_temporal_literal_textContext jdbc_temporal_literal_text() throws RecognitionException {
		Jdbc_temporal_literal_textContext _localctx = new Jdbc_temporal_literal_textContext(_ctx, getState());
		enterRule(_localctx, 244, RULE_jdbc_temporal_literal_text);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1549);
			match(STRINGLITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_type_literalContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Entity_type_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_type_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_type_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_type_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_type_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_type_literalContext entity_type_literal() throws RecognitionException {
		Entity_type_literalContext _localctx = new Entity_type_literalContext(_ctx, getState());
		enterRule(_localctx, 246, RULE_entity_type_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1551);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Escape_characterContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public Character_valued_input_parameterContext character_valued_input_parameter() {
			return getRuleContext(Character_valued_input_parameterContext.class,0);
		}
		public Escape_characterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_escape_character; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEscape_character(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEscape_character(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEscape_character(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Escape_characterContext escape_character() throws RecognitionException {
		Escape_characterContext _localctx = new Escape_characterContext(_ctx, getState());
		enterRule(_localctx, 248, RULE_escape_character);
		try {
			setState(1556);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,164,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1553);
				match(CHARACTER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1554);
				string_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1555);
				character_valued_input_parameter();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Numeric_literalContext extends ParserRuleContext {
		public TerminalNode INTLITERAL() { return getToken(JpqlParser.INTLITERAL, 0); }
		public TerminalNode FLOATLITERAL() { return getToken(JpqlParser.FLOATLITERAL, 0); }
		public TerminalNode LONGLITERAL() { return getToken(JpqlParser.LONGLITERAL, 0); }
		public Numeric_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numeric_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNumeric_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNumeric_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNumeric_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Numeric_literalContext numeric_literal() throws RecognitionException {
		Numeric_literalContext _localctx = new Numeric_literalContext(_ctx, getState());
		enterRule(_localctx, 250, RULE_numeric_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1558);
			_la = _input.LA(1);
			if ( !(((((_la - 130)) & ~0x3f) == 0 && ((1L << (_la - 130)) & 7L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Type_literalContext extends ParserRuleContext {
		public TerminalNode STRING() { return getToken(JpqlParser.STRING, 0); }
		public TerminalNode INTEGER() { return getToken(JpqlParser.INTEGER, 0); }
		public TerminalNode LONG() { return getToken(JpqlParser.LONG, 0); }
		public TerminalNode FLOAT() { return getToken(JpqlParser.FLOAT, 0); }
		public TerminalNode DOUBLE() { return getToken(JpqlParser.DOUBLE, 0); }
		public Type_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterType_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitType_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitType_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Type_literalContext type_literal() throws RecognitionException {
		Type_literalContext _localctx = new Type_literalContext(_ctx, getState());
		enterRule(_localctx, 252, RULE_type_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1560);
			_la = _input.LA(1);
			if ( !(_la==DOUBLE || _la==FLOAT || ((((_la - 66)) & ~0x3f) == 0 && ((1L << (_la - 66)) & 2199023263745L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Boolean_literalContext extends ParserRuleContext {
		public TerminalNode TRUE() { return getToken(JpqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(JpqlParser.FALSE, 0); }
		public Boolean_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolean_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBoolean_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBoolean_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBoolean_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Boolean_literalContext boolean_literal() throws RecognitionException {
		Boolean_literalContext _localctx = new Boolean_literalContext(_ctx, getState());
		enterRule(_localctx, 254, RULE_boolean_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1562);
			_la = _input.LA(1);
			if ( !(_la==FALSE || _la==TRUE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Enum_literalContext extends ParserRuleContext {
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public Enum_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_enum_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEnum_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEnum_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEnum_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Enum_literalContext enum_literal() throws RecognitionException {
		Enum_literalContext _localctx = new Enum_literalContext(_ctx, getState());
		enterRule(_localctx, 256, RULE_enum_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1564);
			state_field_path_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class String_literalContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public String_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterString_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitString_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitString_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final String_literalContext string_literal() throws RecognitionException {
		String_literalContext _localctx = new String_literalContext(_ctx, getState());
		enterRule(_localctx, 258, RULE_string_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1566);
			_la = _input.LA(1);
			if ( !(_la==CHARACTER || _la==STRINGLITERAL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_embeddable_object_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Single_valued_embeddable_object_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_embeddable_object_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_embeddable_object_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_embeddable_object_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_embeddable_object_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field() throws RecognitionException {
		Single_valued_embeddable_object_fieldContext _localctx = new Single_valued_embeddable_object_fieldContext(_ctx, getState());
		enterRule(_localctx, 260, RULE_single_valued_embeddable_object_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1568);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubtypeContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public SubtypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subtype; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubtype(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubtype(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubtype(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubtypeContext subtype() throws RecognitionException {
		SubtypeContext _localctx = new SubtypeContext(_ctx, getState());
		enterRule(_localctx, 262, RULE_subtype);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1570);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_valued_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public Collection_valued_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_valued_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_valued_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_valued_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_valued_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_valued_fieldContext collection_valued_field() throws RecognitionException {
		Collection_valued_fieldContext _localctx = new Collection_valued_fieldContext(_ctx, getState());
		enterRule(_localctx, 264, RULE_collection_valued_field);
		try {
			setState(1574);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,165,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1572);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1573);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_object_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public Single_valued_object_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_object_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_object_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_object_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_object_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_object_fieldContext single_valued_object_field() throws RecognitionException {
		Single_valued_object_fieldContext _localctx = new Single_valued_object_fieldContext(_ctx, getState());
		enterRule(_localctx, 266, RULE_single_valued_object_field);
		try {
			setState(1578);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,166,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1576);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1577);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public State_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterState_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitState_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitState_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_fieldContext state_field() throws RecognitionException {
		State_fieldContext _localctx = new State_fieldContext(_ctx, getState());
		enterRule(_localctx, 268, RULE_state_field);
		try {
			setState(1582);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,167,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1580);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1581);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_value_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public Collection_value_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_value_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_value_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_value_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_value_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_value_fieldContext collection_value_field() throws RecognitionException {
		Collection_value_fieldContext _localctx = new Collection_value_fieldContext(_ctx, getState());
		enterRule(_localctx, 270, RULE_collection_value_field);
		try {
			setState(1586);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,168,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1584);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1585);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_nameContext extends ParserRuleContext {
		public List<Reserved_wordContext> reserved_word() {
			return getRuleContexts(Reserved_wordContext.class);
		}
		public Reserved_wordContext reserved_word(int i) {
			return getRuleContext(Reserved_wordContext.class,i);
		}
		public Entity_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_nameContext entity_name() throws RecognitionException {
		Entity_nameContext _localctx = new Entity_nameContext(_ctx, getState());
		enterRule(_localctx, 272, RULE_entity_name);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1588);
			reserved_word();
			setState(1593);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__3) {
				{
				{
				setState(1589);
				match(T__3);
				setState(1590);
				reserved_word();
				}
				}
				setState(1595);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Result_variableContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Result_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_result_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterResult_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitResult_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitResult_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Result_variableContext result_variable() throws RecognitionException {
		Result_variableContext _localctx = new Result_variableContext(_ctx, getState());
		enterRule(_localctx, 274, RULE_result_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1596);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Superquery_identification_variableContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Superquery_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_superquery_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSuperquery_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSuperquery_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSuperquery_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Superquery_identification_variableContext superquery_identification_variable() throws RecognitionException {
		Superquery_identification_variableContext _localctx = new Superquery_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 276, RULE_superquery_identification_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1598);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_valued_input_parameterContext extends ParserRuleContext {
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Collection_valued_input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_valued_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_valued_input_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_valued_input_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_valued_input_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_valued_input_parameterContext collection_valued_input_parameter() throws RecognitionException {
		Collection_valued_input_parameterContext _localctx = new Collection_valued_input_parameterContext(_ctx, getState());
		enterRule(_localctx, 278, RULE_collection_valued_input_parameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1600);
			input_parameter();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_input_parameterContext extends ParserRuleContext {
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Single_valued_input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_input_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_input_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_input_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_input_parameterContext single_valued_input_parameter() throws RecognitionException {
		Single_valued_input_parameterContext _localctx = new Single_valued_input_parameterContext(_ctx, getState());
		enterRule(_localctx, 280, RULE_single_valued_input_parameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1602);
			input_parameter();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_nameContext extends ParserRuleContext {
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public Function_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunction_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunction_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunction_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_nameContext function_name() throws RecognitionException {
		Function_nameContext _localctx = new Function_nameContext(_ctx, getState());
		enterRule(_localctx, 282, RULE_function_name);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1604);
			string_literal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Character_valued_input_parameterContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Character_valued_input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_character_valued_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCharacter_valued_input_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCharacter_valued_input_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCharacter_valued_input_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Character_valued_input_parameterContext character_valued_input_parameter() throws RecognitionException {
		Character_valued_input_parameterContext _localctx = new Character_valued_input_parameterContext(_ctx, getState());
		enterRule(_localctx, 284, RULE_character_valued_input_parameter);
		try {
			setState(1608);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CHARACTER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1606);
				match(CHARACTER);
				}
				break;
			case T__13:
			case T__14:
				enterOuterAlt(_localctx, 2);
				{
				setState(1607);
				input_parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Reserved_wordContext extends ParserRuleContext {
		public Token f;
		public TerminalNode IDENTIFICATION_VARIABLE() { return getToken(JpqlParser.IDENTIFICATION_VARIABLE, 0); }
		public TerminalNode ABS() { return getToken(JpqlParser.ABS, 0); }
		public TerminalNode ALL() { return getToken(JpqlParser.ALL, 0); }
		public TerminalNode AND() { return getToken(JpqlParser.AND, 0); }
		public TerminalNode ANY() { return getToken(JpqlParser.ANY, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public TerminalNode ASC() { return getToken(JpqlParser.ASC, 0); }
		public TerminalNode AVG() { return getToken(JpqlParser.AVG, 0); }
		public TerminalNode BETWEEN() { return getToken(JpqlParser.BETWEEN, 0); }
		public TerminalNode BOTH() { return getToken(JpqlParser.BOTH, 0); }
		public TerminalNode BY() { return getToken(JpqlParser.BY, 0); }
		public TerminalNode CASE() { return getToken(JpqlParser.CASE, 0); }
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public TerminalNode CEILING() { return getToken(JpqlParser.CEILING, 0); }
		public TerminalNode COALESCE() { return getToken(JpqlParser.COALESCE, 0); }
		public TerminalNode CONCAT() { return getToken(JpqlParser.CONCAT, 0); }
		public TerminalNode COUNT() { return getToken(JpqlParser.COUNT, 0); }
		public TerminalNode CURRENT_DATE() { return getToken(JpqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT_TIME() { return getToken(JpqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(JpqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode DATE() { return getToken(JpqlParser.DATE, 0); }
		public TerminalNode DATETIME() { return getToken(JpqlParser.DATETIME, 0); }
		public TerminalNode DELETE() { return getToken(JpqlParser.DELETE, 0); }
		public TerminalNode DESC() { return getToken(JpqlParser.DESC, 0); }
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public TerminalNode END() { return getToken(JpqlParser.END, 0); }
		public TerminalNode ELSE() { return getToken(JpqlParser.ELSE, 0); }
		public TerminalNode EMPTY() { return getToken(JpqlParser.EMPTY, 0); }
		public TerminalNode ENTRY() { return getToken(JpqlParser.ENTRY, 0); }
		public TerminalNode ESCAPE() { return getToken(JpqlParser.ESCAPE, 0); }
		public TerminalNode EXISTS() { return getToken(JpqlParser.EXISTS, 0); }
		public TerminalNode EXP() { return getToken(JpqlParser.EXP, 0); }
		public TerminalNode EXTRACT() { return getToken(JpqlParser.EXTRACT, 0); }
		public TerminalNode FALSE() { return getToken(JpqlParser.FALSE, 0); }
		public TerminalNode FETCH() { return getToken(JpqlParser.FETCH, 0); }
		public TerminalNode FLOOR() { return getToken(JpqlParser.FLOOR, 0); }
		public TerminalNode FUNCTION() { return getToken(JpqlParser.FUNCTION, 0); }
		public TerminalNode ID() { return getToken(JpqlParser.ID, 0); }
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public TerminalNode INDEX() { return getToken(JpqlParser.INDEX, 0); }
		public TerminalNode INNER() { return getToken(JpqlParser.INNER, 0); }
		public TerminalNode IS() { return getToken(JpqlParser.IS, 0); }
		public TerminalNode KEY() { return getToken(JpqlParser.KEY, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode LENGTH() { return getToken(JpqlParser.LENGTH, 0); }
		public TerminalNode LIKE() { return getToken(JpqlParser.LIKE, 0); }
		public TerminalNode LN() { return getToken(JpqlParser.LN, 0); }
		public TerminalNode LOCAL() { return getToken(JpqlParser.LOCAL, 0); }
		public TerminalNode LOCATE() { return getToken(JpqlParser.LOCATE, 0); }
		public TerminalNode LOWER() { return getToken(JpqlParser.LOWER, 0); }
		public TerminalNode MAX() { return getToken(JpqlParser.MAX, 0); }
		public TerminalNode MEMBER() { return getToken(JpqlParser.MEMBER, 0); }
		public TerminalNode MIN() { return getToken(JpqlParser.MIN, 0); }
		public TerminalNode MOD() { return getToken(JpqlParser.MOD, 0); }
		public TerminalNode NEW() { return getToken(JpqlParser.NEW, 0); }
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public TerminalNode NULL() { return getToken(JpqlParser.NULL, 0); }
		public TerminalNode NULLIF() { return getToken(JpqlParser.NULLIF, 0); }
		public TerminalNode OBJECT() { return getToken(JpqlParser.OBJECT, 0); }
		public TerminalNode OF() { return getToken(JpqlParser.OF, 0); }
		public TerminalNode ON() { return getToken(JpqlParser.ON, 0); }
		public TerminalNode OR() { return getToken(JpqlParser.OR, 0); }
		public TerminalNode ORDER() { return getToken(JpqlParser.ORDER, 0); }
		public TerminalNode OUTER() { return getToken(JpqlParser.OUTER, 0); }
		public TerminalNode POWER() { return getToken(JpqlParser.POWER, 0); }
		public TerminalNode REPLACE() { return getToken(JpqlParser.REPLACE, 0); }
		public TerminalNode RIGHT() { return getToken(JpqlParser.RIGHT, 0); }
		public TerminalNode ROUND() { return getToken(JpqlParser.ROUND, 0); }
		public TerminalNode SELECT() { return getToken(JpqlParser.SELECT, 0); }
		public TerminalNode SET() { return getToken(JpqlParser.SET, 0); }
		public TerminalNode SIGN() { return getToken(JpqlParser.SIGN, 0); }
		public TerminalNode SIZE() { return getToken(JpqlParser.SIZE, 0); }
		public TerminalNode SOME() { return getToken(JpqlParser.SOME, 0); }
		public TerminalNode SQRT() { return getToken(JpqlParser.SQRT, 0); }
		public TerminalNode SUBSTRING() { return getToken(JpqlParser.SUBSTRING, 0); }
		public TerminalNode SUM() { return getToken(JpqlParser.SUM, 0); }
		public TerminalNode THEN() { return getToken(JpqlParser.THEN, 0); }
		public TerminalNode TIME() { return getToken(JpqlParser.TIME, 0); }
		public TerminalNode TRAILING() { return getToken(JpqlParser.TRAILING, 0); }
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public TerminalNode TRIM() { return getToken(JpqlParser.TRIM, 0); }
		public TerminalNode TRUE() { return getToken(JpqlParser.TRUE, 0); }
		public TerminalNode TYPE() { return getToken(JpqlParser.TYPE, 0); }
		public TerminalNode UPDATE() { return getToken(JpqlParser.UPDATE, 0); }
		public TerminalNode UPPER() { return getToken(JpqlParser.UPPER, 0); }
		public TerminalNode VALUE() { return getToken(JpqlParser.VALUE, 0); }
		public TerminalNode VERSION() { return getToken(JpqlParser.VERSION, 0); }
		public Reserved_wordContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_reserved_word; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterReserved_word(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitReserved_word(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitReserved_word(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Reserved_wordContext reserved_word() throws RecognitionException {
		Reserved_wordContext _localctx = new Reserved_wordContext(_ctx, getState());
		enterRule(_localctx, 286, RULE_reserved_word);
		int _la;
		try {
			setState(1612);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1610);
				match(IDENTIFICATION_VARIABLE);
				}
				break;
			case ABS:
			case ALL:
			case AND:
			case ANY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BY:
			case CASE:
			case CAST:
			case CEILING:
			case COALESCE:
			case CONCAT:
			case COUNT:
			case CURRENT_DATE:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case DATE:
			case DATETIME:
			case DELETE:
			case DESC:
			case DISTINCT:
			case END:
			case ELSE:
			case EMPTY:
			case ENTRY:
			case ESCAPE:
			case EXISTS:
			case EXP:
			case EXTRACT:
			case FALSE:
			case FETCH:
			case FLOOR:
			case FUNCTION:
			case ID:
			case IN:
			case INDEX:
			case INNER:
			case IS:
			case KEY:
			case LEFT:
			case LENGTH:
			case LIKE:
			case LN:
			case LOCAL:
			case LOCATE:
			case LOWER:
			case MAX:
			case MEMBER:
			case MIN:
			case MOD:
			case NEW:
			case NOT:
			case NULL:
			case NULLIF:
			case OBJECT:
			case OF:
			case ON:
			case OR:
			case ORDER:
			case OUTER:
			case POWER:
			case REPLACE:
			case RIGHT:
			case ROUND:
			case SELECT:
			case SET:
			case SIGN:
			case SIZE:
			case SOME:
			case SQRT:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIME:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUE:
			case TYPE:
			case UPDATE:
			case UPPER:
			case VALUE:
			case VERSION:
				enterOuterAlt(_localctx, 2);
				{
				setState(1611);
				((Reserved_wordContext)_localctx).f = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & -3855653027076112384L) != 0) || ((((_la - 64)) & ~0x3f) == 0 && ((1L << (_la - 64)) & 279214372180426323L) != 0)) ) {
					((Reserved_wordContext)_localctx).f = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 58:
			return conditional_expression_sempred((Conditional_expressionContext)_localctx, predIndex);
		case 59:
			return conditional_term_sempred((Conditional_termContext)_localctx, predIndex);
		case 76:
			return arithmetic_expression_sempred((Arithmetic_expressionContext)_localctx, predIndex);
		case 77:
			return arithmetic_term_sempred((Arithmetic_termContext)_localctx, predIndex);
		case 80:
			return string_expression_sempred((String_expressionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean conditional_expression_sempred(Conditional_expressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean conditional_term_sempred(Conditional_termContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean arithmetic_expression_sempred(Arithmetic_expressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean arithmetic_term_sempred(Arithmetic_termContext _localctx, int predIndex) {
		switch (predIndex) {
		case 3:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean string_expression_sempred(String_expressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 4:
			return precpred(_ctx, 1);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001\u0087\u064f\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001"+
		"\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004"+
		"\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007"+
		"\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b"+
		"\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007"+
		"\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007"+
		"\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007"+
		"\u0015\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007"+
		"\u0018\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007"+
		"\u001b\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007"+
		"\u001e\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007"+
		"\"\u0002#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007"+
		"\'\u0002(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007"+
		",\u0002-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u0007"+
		"1\u00022\u00072\u00023\u00073\u00024\u00074\u00025\u00075\u00026\u0007"+
		"6\u00027\u00077\u00028\u00078\u00029\u00079\u0002:\u0007:\u0002;\u0007"+
		";\u0002<\u0007<\u0002=\u0007=\u0002>\u0007>\u0002?\u0007?\u0002@\u0007"+
		"@\u0002A\u0007A\u0002B\u0007B\u0002C\u0007C\u0002D\u0007D\u0002E\u0007"+
		"E\u0002F\u0007F\u0002G\u0007G\u0002H\u0007H\u0002I\u0007I\u0002J\u0007"+
		"J\u0002K\u0007K\u0002L\u0007L\u0002M\u0007M\u0002N\u0007N\u0002O\u0007"+
		"O\u0002P\u0007P\u0002Q\u0007Q\u0002R\u0007R\u0002S\u0007S\u0002T\u0007"+
		"T\u0002U\u0007U\u0002V\u0007V\u0002W\u0007W\u0002X\u0007X\u0002Y\u0007"+
		"Y\u0002Z\u0007Z\u0002[\u0007[\u0002\\\u0007\\\u0002]\u0007]\u0002^\u0007"+
		"^\u0002_\u0007_\u0002`\u0007`\u0002a\u0007a\u0002b\u0007b\u0002c\u0007"+
		"c\u0002d\u0007d\u0002e\u0007e\u0002f\u0007f\u0002g\u0007g\u0002h\u0007"+
		"h\u0002i\u0007i\u0002j\u0007j\u0002k\u0007k\u0002l\u0007l\u0002m\u0007"+
		"m\u0002n\u0007n\u0002o\u0007o\u0002p\u0007p\u0002q\u0007q\u0002r\u0007"+
		"r\u0002s\u0007s\u0002t\u0007t\u0002u\u0007u\u0002v\u0007v\u0002w\u0007"+
		"w\u0002x\u0007x\u0002y\u0007y\u0002z\u0007z\u0002{\u0007{\u0002|\u0007"+
		"|\u0002}\u0007}\u0002~\u0007~\u0002\u007f\u0007\u007f\u0002\u0080\u0007"+
		"\u0080\u0002\u0081\u0007\u0081\u0002\u0082\u0007\u0082\u0002\u0083\u0007"+
		"\u0083\u0002\u0084\u0007\u0084\u0002\u0085\u0007\u0085\u0002\u0086\u0007"+
		"\u0086\u0002\u0087\u0007\u0087\u0002\u0088\u0007\u0088\u0002\u0089\u0007"+
		"\u0089\u0002\u008a\u0007\u008a\u0002\u008b\u0007\u008b\u0002\u008c\u0007"+
		"\u008c\u0002\u008d\u0007\u008d\u0002\u008e\u0007\u008e\u0002\u008f\u0007"+
		"\u008f\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0003\u0001\u0127\b\u0001\u0001\u0002\u0001\u0002\u0001\u0002\u0003"+
		"\u0002\u012c\b\u0002\u0001\u0002\u0003\u0002\u012f\b\u0002\u0001\u0002"+
		"\u0003\u0002\u0132\b\u0002\u0001\u0002\u0003\u0002\u0135\b\u0002\u0001"+
		"\u0002\u0003\u0002\u0138\b\u0002\u0001\u0002\u0001\u0002\u0003\u0002\u013c"+
		"\b\u0002\u0001\u0002\u0003\u0002\u013f\b\u0002\u0001\u0002\u0003\u0002"+
		"\u0142\b\u0002\u0001\u0002\u0003\u0002\u0145\b\u0002\u0001\u0002\u0003"+
		"\u0002\u0148\b\u0002\u0003\u0002\u014a\b\u0002\u0001\u0003\u0001\u0003"+
		"\u0003\u0003\u014e\b\u0003\u0001\u0003\u0001\u0003\u0003\u0003\u0152\b"+
		"\u0003\u0001\u0003\u0001\u0003\u0003\u0003\u0156\b\u0003\u0003\u0003\u0158"+
		"\b\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0003"+
		"\u0005\u015f\b\u0005\u0001\u0006\u0001\u0006\u0003\u0006\u0163\b\u0006"+
		"\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007\u0005\u0007\u0169\b\u0007"+
		"\n\u0007\f\u0007\u016c\t\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001\b"+
		"\u0001\b\u0003\b\u0174\b\b\u0001\b\u0003\b\u0177\b\b\u0003\b\u0179\b\b"+
		"\u0001\t\u0001\t\u0001\t\u0005\t\u017e\b\t\n\t\f\t\u0181\t\t\u0001\n\u0001"+
		"\n\u0003\n\u0185\b\n\u0001\n\u0003\n\u0188\b\n\u0001\u000b\u0001\u000b"+
		"\u0001\u000b\u0003\u000b\u018d\b\u000b\u0001\u000b\u0003\u000b\u0190\b"+
		"\u000b\u0001\u000b\u0003\u000b\u0193\b\u000b\u0001\f\u0001\f\u0001\f\u0001"+
		"\f\u0003\f\u0199\b\f\u0001\f\u0003\f\u019c\b\f\u0001\f\u0003\f\u019f\b"+
		"\f\u0001\r\u0001\r\u0003\r\u01a3\b\r\u0001\r\u0003\r\u01a6\b\r\u0001\r"+
		"\u0001\r\u0001\u000e\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0001\u000f\u0003"+
		"\u000f\u01b5\b\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0003\u0010\u01ba"+
		"\b\u0010\u0001\u0010\u0001\u0010\u0001\u0010\u0005\u0010\u01bf\b\u0010"+
		"\n\u0010\f\u0010\u01c2\t\u0010\u0001\u0010\u0001\u0010\u0001\u0011\u0001"+
		"\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0003\u0011\u01cb\b\u0011\u0001"+
		"\u0011\u0003\u0011\u01ce\b\u0011\u0001\u0012\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0003\u0012\u01d6\b\u0012\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001"+
		"\u0013\u0001\u0013\u0001\u0013\u0003\u0013\u01e2\b\u0013\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001\u0014\u0001"+
		"\u0014\u0001\u0014\u0001\u0014\u0003\u0014\u01ee\b\u0014\u0001\u0015\u0001"+
		"\u0015\u0003\u0015\u01f2\b\u0015\u0001\u0016\u0001\u0016\u0001\u0016\u0001"+
		"\u0016\u0005\u0016\u01f8\b\u0016\n\u0016\f\u0016\u01fb\t\u0016\u0003\u0016"+
		"\u01fd\b\u0016\u0001\u0017\u0001\u0017\u0001\u0017\u0005\u0017\u0202\b"+
		"\u0017\n\u0017\f\u0017\u0205\t\u0017\u0001\u0018\u0001\u0018\u0001\u0018"+
		"\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0018\u0001\u0019\u0001\u0019"+
		"\u0001\u0019\u0001\u0019\u0001\u001a\u0001\u001a\u0003\u001a\u0214\b\u001a"+
		"\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001b\u0001\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0003\u001d"+
		"\u0221\b\u001d\u0001\u001d\u0003\u001d\u0224\b\u001d\u0001\u001d\u0001"+
		"\u001d\u0001\u001d\u0001\u001d\u0005\u001d\u022a\b\u001d\n\u001d\f\u001d"+
		"\u022d\t\u001d\u0001\u001e\u0001\u001e\u0001\u001e\u0003\u001e\u0232\b"+
		"\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0005\u001e\u0237\b\u001e\n"+
		"\u001e\f\u001e\u023a\t\u001e\u0001\u001e\u0001\u001e\u0003\u001e\u023e"+
		"\b\u001e\u0001\u001e\u0001\u001e\u0001\u001e\u0001\u001f\u0001\u001f\u0001"+
		"\u001f\u0003\u001f\u0246\b\u001f\u0001 \u0001 \u0001 \u0001 \u0003 \u024c"+
		"\b \u0001 \u0003 \u024f\b \u0001!\u0001!\u0003!\u0253\b!\u0001!\u0001"+
		"!\u0001!\u0005!\u0258\b!\n!\f!\u025b\t!\u0001\"\u0001\"\u0003\"\u025f"+
		"\b\"\u0001\"\u0003\"\u0262\b\"\u0001#\u0001#\u0001#\u0001#\u0001#\u0001"+
		"#\u0001#\u0001#\u0001#\u0001#\u0003#\u026e\b#\u0001$\u0001$\u0001$\u0001"+
		"$\u0001$\u0001$\u0005$\u0276\b$\n$\f$\u0279\t$\u0001$\u0001$\u0001%\u0001"+
		"%\u0001%\u0001%\u0001%\u0003%\u0282\b%\u0001&\u0001&\u0001&\u0003&\u0287"+
		"\b&\u0001&\u0001&\u0001&\u0001&\u0001&\u0001&\u0003&\u028f\b&\u0001&\u0001"+
		"&\u0001&\u0001&\u0003&\u0295\b&\u0001\'\u0001\'\u0001\'\u0001(\u0001("+
		"\u0001(\u0001(\u0001(\u0005(\u029f\b(\n(\f(\u02a2\t(\u0001)\u0001)\u0003"+
		")\u02a6\b)\u0001*\u0001*\u0001*\u0001+\u0001+\u0001+\u0001+\u0001+\u0005"+
		"+\u02b0\b+\n+\f+\u02b3\t+\u0001,\u0001,\u0003,\u02b7\b,\u0001,\u0003,"+
		"\u02ba\b,\u0001-\u0001-\u0001-\u0001-\u0003-\u02c0\b-\u0001.\u0001.\u0001"+
		".\u0001/\u0001/\u0001/\u0003/\u02c8\b/\u0001/\u0003/\u02cb\b/\u0001/\u0003"+
		"/\u02ce\b/\u00010\u00010\u00010\u00010\u00010\u00030\u02d5\b0\u00050\u02d7"+
		"\b0\n0\f0\u02da\t0\u00011\u00011\u00011\u00031\u02df\b1\u00011\u00031"+
		"\u02e2\b1\u00011\u00051\u02e5\b1\n1\f1\u02e8\t1\u00011\u00031\u02eb\b"+
		"1\u00012\u00012\u00012\u00012\u00012\u00012\u00012\u00012\u00032\u02f5"+
		"\b2\u00013\u00013\u00013\u00013\u00053\u02fb\b3\n3\f3\u02fe\t3\u00033"+
		"\u0300\b3\u00014\u00014\u00014\u00054\u0305\b4\n4\f4\u0308\t4\u00015\u0001"+
		"5\u00015\u00015\u00015\u00015\u00015\u00016\u00016\u00016\u00016\u0001"+
		"6\u00016\u00056\u0317\b6\n6\f6\u031a\t6\u00016\u00016\u00017\u00017\u0003"+
		"7\u0320\b7\u00017\u00017\u00018\u00018\u00018\u00018\u00038\u0328\b8\u0001"+
		"9\u00019\u00019\u00019\u00019\u00019\u00019\u00019\u00039\u0332\b9\u0001"+
		":\u0001:\u0001:\u0001:\u0001:\u0001:\u0005:\u033a\b:\n:\f:\u033d\t:\u0001"+
		";\u0001;\u0001;\u0001;\u0001;\u0001;\u0005;\u0345\b;\n;\f;\u0348\t;\u0001"+
		"<\u0003<\u034b\b<\u0001<\u0001<\u0001=\u0001=\u0001=\u0001=\u0001=\u0003"+
		"=\u0354\b=\u0001>\u0001>\u0001>\u0001>\u0001>\u0001>\u0001>\u0001>\u0003"+
		">\u035e\b>\u0001?\u0001?\u0003?\u0362\b?\u0001?\u0001?\u0001?\u0001?\u0001"+
		"?\u0001?\u0001?\u0003?\u036b\b?\u0001?\u0001?\u0001?\u0001?\u0001?\u0001"+
		"?\u0001?\u0003?\u0374\b?\u0001?\u0001?\u0001?\u0001?\u0001?\u0003?\u037b"+
		"\b?\u0001@\u0001@\u0003@\u037f\b@\u0001@\u0003@\u0382\b@\u0001@\u0001"+
		"@\u0001@\u0001@\u0001@\u0005@\u0389\b@\n@\f@\u038c\t@\u0001@\u0001@\u0001"+
		"@\u0001@\u0001@\u0001@\u0001@\u0003@\u0395\b@\u0001A\u0001A\u0001A\u0001"+
		"A\u0001A\u0001A\u0001A\u0003A\u039e\bA\u0001B\u0001B\u0003B\u03a2\bB\u0001"+
		"B\u0001B\u0001B\u0001B\u0003B\u03a8\bB\u0001C\u0001C\u0003C\u03ac\bC\u0001"+
		"C\u0001C\u0003C\u03b0\bC\u0001C\u0001C\u0001D\u0001D\u0001D\u0003D\u03b7"+
		"\bD\u0001D\u0001D\u0001E\u0001E\u0003E\u03bd\bE\u0001E\u0001E\u0003E\u03c1"+
		"\bE\u0001E\u0001E\u0001F\u0001F\u0001F\u0001F\u0003F\u03c9\bF\u0001G\u0001"+
		"G\u0001G\u0003G\u03ce\bG\u0001H\u0003H\u03d1\bH\u0001H\u0001H\u0001H\u0001"+
		"H\u0001H\u0001I\u0001I\u0001I\u0001I\u0001I\u0001J\u0001J\u0001J\u0001"+
		"J\u0003J\u03e1\bJ\u0001J\u0001J\u0001J\u0001J\u0003J\u03e7\bJ\u0001J\u0001"+
		"J\u0001J\u0001J\u0001J\u0003J\u03ee\bJ\u0001J\u0001J\u0001J\u0001J\u0003"+
		"J\u03f4\bJ\u0001J\u0001J\u0001J\u0001J\u0003J\u03fa\bJ\u0001J\u0001J\u0001"+
		"J\u0001J\u0003J\u0400\bJ\u0001J\u0001J\u0001J\u0001J\u0001J\u0001J\u0001"+
		"J\u0001J\u0001J\u0001J\u0001J\u0001J\u0003J\u040e\bJ\u0001K\u0001K\u0001"+
		"K\u0001K\u0001K\u0001K\u0003K\u0416\bK\u0001L\u0001L\u0001L\u0001L\u0001"+
		"L\u0001L\u0005L\u041e\bL\nL\fL\u0421\tL\u0001M\u0001M\u0001M\u0001M\u0001"+
		"M\u0001M\u0005M\u0429\bM\nM\fM\u042c\tM\u0001N\u0003N\u042f\bN\u0001N"+
		"\u0001N\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001"+
		"O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0003O\u0443\bO\u0001"+
		"P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001"+
		"P\u0001P\u0001P\u0003P\u0452\bP\u0001P\u0001P\u0001P\u0005P\u0457\bP\n"+
		"P\fP\u045a\tP\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q"+
		"\u0001Q\u0001Q\u0003Q\u0466\bQ\u0001R\u0001R\u0001R\u0001R\u0001R\u0001"+
		"R\u0001R\u0001R\u0001R\u0003R\u0471\bR\u0001S\u0001S\u0001S\u0001S\u0001"+
		"S\u0001S\u0001S\u0001S\u0003S\u047b\bS\u0001T\u0001T\u0003T\u047f\bT\u0001"+
		"U\u0001U\u0003U\u0483\bU\u0001V\u0001V\u0001V\u0003V\u0488\bV\u0001W\u0001"+
		"W\u0001W\u0001W\u0001W\u0003W\u048f\bW\u0001W\u0001W\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0003"+
		"X\u049f\bX\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0003X\u04e6\bX\u0001Y\u0001Y\u0001Y\u0001Y\u0001Y\u0001Y\u0001Y\u0001"+
		"Y\u0001Y\u0001Y\u0003Y\u04f2\bY\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0005Z\u04fb\bZ\nZ\fZ\u04fe\tZ\u0001Z\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0001Z\u0001Z\u0001Z\u0003Z\u0509\bZ\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0003Z\u0510\bZ\u0001Z\u0003Z\u0513\bZ\u0001Z\u0003Z\u0516\b"+
		"Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001"+
		"Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0001Z\u0003Z\u053c\bZ\u0001[\u0001"+
		"[\u0001\\\u0001\\\u0001\\\u0001\\\u0003\\\u0544\b\\\u0001\\\u0001\\\u0001"+
		"\\\u0001]\u0001]\u0001]\u0001]\u0003]\u054d\b]\u0001]\u0001]\u0001]\u0001"+
		"]\u0001]\u0005]\u0554\b]\n]\f]\u0557\t]\u0001]\u0001]\u0003]\u055b\b]"+
		"\u0001]\u0001]\u0001^\u0001^\u0001^\u0001^\u0003^\u0563\b^\u0001^\u0001"+
		"^\u0001^\u0001_\u0001_\u0003_\u056a\b_\u0001`\u0001`\u0001`\u0001`\u0003"+
		"`\u0570\b`\u0001`\u0001`\u0001a\u0001a\u0001a\u0001a\u0003a\u0578\ba\u0001"+
		"a\u0001a\u0001b\u0001b\u0001b\u0001b\u0001b\u0005b\u0581\bb\nb\fb\u0584"+
		"\tb\u0001b\u0001b\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001c\u0001"+
		"d\u0001d\u0001e\u0001e\u0001e\u0001e\u0001e\u0001e\u0001e\u0001f\u0001"+
		"f\u0001g\u0001g\u0001h\u0001h\u0001h\u0001h\u0003h\u05a0\bh\u0001i\u0001"+
		"i\u0001i\u0005i\u05a5\bi\ni\fi\u05a8\ti\u0001i\u0001i\u0003i\u05ac\bi"+
		"\u0001i\u0001i\u0001j\u0001j\u0001j\u0001j\u0001j\u0001k\u0001k\u0001"+
		"k\u0001k\u0005k\u05b9\bk\nk\fk\u05bc\tk\u0001k\u0001k\u0003k\u05c0\bk"+
		"\u0001k\u0001k\u0001l\u0001l\u0003l\u05c6\bl\u0001m\u0001m\u0001m\u0001"+
		"m\u0001m\u0001n\u0001n\u0001n\u0001n\u0001n\u0004n\u05d2\bn\u000bn\fn"+
		"\u05d3\u0001n\u0001n\u0001o\u0001o\u0001o\u0001o\u0001o\u0001o\u0001o"+
		"\u0001p\u0001p\u0003p\u05e1\bp\u0001q\u0001q\u0001q\u0003q\u05e6\bq\u0001"+
		"r\u0001r\u0001s\u0001s\u0001s\u0001s\u0001s\u0001s\u0001s\u0001s\u0003"+
		"s\u05f2\bs\u0001t\u0001t\u0001t\u0001t\u0003t\u05f8\bt\u0001u\u0001u\u0001"+
		"v\u0001v\u0001v\u0001v\u0003v\u0600\bv\u0001w\u0001w\u0001w\u0001w\u0001"+
		"x\u0001x\u0001x\u0001x\u0001y\u0001y\u0001y\u0001y\u0001z\u0001z\u0001"+
		"{\u0001{\u0001|\u0001|\u0001|\u0003|\u0615\b|\u0001}\u0001}\u0001~\u0001"+
		"~\u0001\u007f\u0001\u007f\u0001\u0080\u0001\u0080\u0001\u0081\u0001\u0081"+
		"\u0001\u0082\u0001\u0082\u0001\u0083\u0001\u0083\u0001\u0084\u0001\u0084"+
		"\u0003\u0084\u0627\b\u0084\u0001\u0085\u0001\u0085\u0003\u0085\u062b\b"+
		"\u0085\u0001\u0086\u0001\u0086\u0003\u0086\u062f\b\u0086\u0001\u0087\u0001"+
		"\u0087\u0003\u0087\u0633\b\u0087\u0001\u0088\u0001\u0088\u0001\u0088\u0005"+
		"\u0088\u0638\b\u0088\n\u0088\f\u0088\u063b\t\u0088\u0001\u0089\u0001\u0089"+
		"\u0001\u008a\u0001\u008a\u0001\u008b\u0001\u008b\u0001\u008c\u0001\u008c"+
		"\u0001\u008d\u0001\u008d\u0001\u008e\u0001\u008e\u0003\u008e\u0649\b\u008e"+
		"\u0001\u008f\u0001\u008f\u0003\u008f\u064d\b\u008f\u0001\u008f\u0000\u0005"+
		"tv\u0098\u009a\u00a0\u0090\u0000\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012"+
		"\u0014\u0016\u0018\u001a\u001c\u001e \"$&(*,.02468:<>@BDFHJLNPRTVXZ\\"+
		"^`bdfhjlnprtvxz|~\u0080\u0082\u0084\u0086\u0088\u008a\u008c\u008e\u0090"+
		"\u0092\u0094\u0096\u0098\u009a\u009c\u009e\u00a0\u00a2\u00a4\u00a6\u00a8"+
		"\u00aa\u00ac\u00ae\u00b0\u00b2\u00b4\u00b6\u00b8\u00ba\u00bc\u00be\u00c0"+
		"\u00c2\u00c4\u00c6\u00c8\u00ca\u00cc\u00ce\u00d0\u00d2\u00d4\u00d6\u00d8"+
		"\u00da\u00dc\u00de\u00e0\u00e2\u00e4\u00e6\u00e8\u00ea\u00ec\u00ee\u00f0"+
		"\u00f2\u00f4\u00f6\u00f8\u00fa\u00fc\u00fe\u0100\u0102\u0104\u0106\u0108"+
		"\u010a\u010c\u010e\u0110\u0112\u0114\u0116\u0118\u011a\u011c\u011e\u0000"+
		"\u000f\u0004\u0000\u0019\u0019QQSSmm\u0002\u0000\u0018\u0018))\u0002\u0000"+
		"77GG\u0003\u0000\u0014\u0014\u0016\u0016ii\u0001\u0000|}\u0001\u0000\t"+
		"\n\u0001\u0000\u000b\f\u0003\u0000\u001b\u001bHHpp\u0004\u0000++88BBO"+
		"O\u000f\u0000\u0017\u0017\"\"&&9:>>AAFFIIUU^`ccggoottxy\u0001\u0000\u0082"+
		"\u0084\u0005\u0000++88BBOOkk\u0002\u000055ss\u0002\u0000~~\u0080\u0080"+
		"\u000e\u0000\u0013*,02699;;>ADDFFINPXZ`bjltvy\u06e1\u0000\u0120\u0001"+
		"\u0000\u0000\u0000\u0002\u0126\u0001\u0000\u0000\u0000\u0004\u0149\u0001"+
		"\u0000\u0000\u0000\u0006\u0157\u0001\u0000\u0000\u0000\b\u0159\u0001\u0000"+
		"\u0000\u0000\n\u015c\u0001\u0000\u0000\u0000\f\u0160\u0001\u0000\u0000"+
		"\u0000\u000e\u0164\u0001\u0000\u0000\u0000\u0010\u0178\u0001\u0000\u0000"+
		"\u0000\u0012\u017a\u0001\u0000\u0000\u0000\u0014\u0182\u0001\u0000\u0000"+
		"\u0000\u0016\u0189\u0001\u0000\u0000\u0000\u0018\u0194\u0001\u0000\u0000"+
		"\u0000\u001a\u01a5\u0001\u0000\u0000\u0000\u001c\u01a9\u0001\u0000\u0000"+
		"\u0000\u001e\u01b4\u0001\u0000\u0000\u0000 \u01b9\u0001\u0000\u0000\u0000"+
		"\"\u01c5\u0001\u0000\u0000\u0000$\u01d5\u0001\u0000\u0000\u0000&\u01e1"+
		"\u0001\u0000\u0000\u0000(\u01ed\u0001\u0000\u0000\u0000*\u01f1\u0001\u0000"+
		"\u0000\u0000,\u01fc\u0001\u0000\u0000\u0000.\u01fe\u0001\u0000\u0000\u0000"+
		"0\u0206\u0001\u0000\u0000\u00002\u020d\u0001\u0000\u0000\u00004\u0213"+
		"\u0001\u0000\u0000\u00006\u0215\u0001\u0000\u0000\u00008\u0219\u0001\u0000"+
		"\u0000\u0000:\u021d\u0001\u0000\u0000\u0000<\u0231\u0001\u0000\u0000\u0000"+
		">\u0245\u0001\u0000\u0000\u0000@\u0247\u0001\u0000\u0000\u0000B\u0250"+
		"\u0001\u0000\u0000\u0000D\u025c\u0001\u0000\u0000\u0000F\u026d\u0001\u0000"+
		"\u0000\u0000H\u026f\u0001\u0000\u0000\u0000J\u0281\u0001\u0000\u0000\u0000"+
		"L\u0294\u0001\u0000\u0000\u0000N\u0296\u0001\u0000\u0000\u0000P\u0299"+
		"\u0001\u0000\u0000\u0000R\u02a5\u0001\u0000\u0000\u0000T\u02a7\u0001\u0000"+
		"\u0000\u0000V\u02aa\u0001\u0000\u0000\u0000X\u02b4\u0001\u0000\u0000\u0000"+
		"Z\u02bf\u0001\u0000\u0000\u0000\\\u02c1\u0001\u0000\u0000\u0000^\u02c4"+
		"\u0001\u0000\u0000\u0000`\u02cf\u0001\u0000\u0000\u0000b\u02ea\u0001\u0000"+
		"\u0000\u0000d\u02f4\u0001\u0000\u0000\u0000f\u02ff\u0001\u0000\u0000\u0000"+
		"h\u0301\u0001\u0000\u0000\u0000j\u0309\u0001\u0000\u0000\u0000l\u0310"+
		"\u0001\u0000\u0000\u0000n\u031d\u0001\u0000\u0000\u0000p\u0327\u0001\u0000"+
		"\u0000\u0000r\u0331\u0001\u0000\u0000\u0000t\u0333\u0001\u0000\u0000\u0000"+
		"v\u033e\u0001\u0000\u0000\u0000x\u034a\u0001\u0000\u0000\u0000z\u0353"+
		"\u0001\u0000\u0000\u0000|\u035d\u0001\u0000\u0000\u0000~\u037a\u0001\u0000"+
		"\u0000\u0000\u0080\u037e\u0001\u0000\u0000\u0000\u0082\u039d\u0001\u0000"+
		"\u0000\u0000\u0084\u039f\u0001\u0000\u0000\u0000\u0086\u03ab\u0001\u0000"+
		"\u0000\u0000\u0088\u03b3\u0001\u0000\u0000\u0000\u008a\u03ba\u0001\u0000"+
		"\u0000\u0000\u008c\u03c8\u0001\u0000\u0000\u0000\u008e\u03cd\u0001\u0000"+
		"\u0000\u0000\u0090\u03d0\u0001\u0000\u0000\u0000\u0092\u03d7\u0001\u0000"+
		"\u0000\u0000\u0094\u040d\u0001\u0000\u0000\u0000\u0096\u0415\u0001\u0000"+
		"\u0000\u0000\u0098\u0417\u0001\u0000\u0000\u0000\u009a\u0422\u0001\u0000"+
		"\u0000\u0000\u009c\u042e\u0001\u0000\u0000\u0000\u009e\u0442\u0001\u0000"+
		"\u0000\u0000\u00a0\u0451\u0001\u0000\u0000\u0000\u00a2\u0465\u0001\u0000"+
		"\u0000\u0000\u00a4\u0470\u0001\u0000\u0000\u0000\u00a6\u047a\u0001\u0000"+
		"\u0000\u0000\u00a8\u047e\u0001\u0000\u0000\u0000\u00aa\u0482\u0001\u0000"+
		"\u0000\u0000\u00ac\u0487\u0001\u0000\u0000\u0000\u00ae\u0489\u0001\u0000"+
		"\u0000\u0000\u00b0\u04e5\u0001\u0000\u0000\u0000\u00b2\u04f1\u0001\u0000"+
		"\u0000\u0000\u00b4\u053b\u0001\u0000\u0000\u0000\u00b6\u053d\u0001\u0000"+
		"\u0000\u0000\u00b8\u053f\u0001\u0000\u0000\u0000\u00ba\u0548\u0001\u0000"+
		"\u0000\u0000\u00bc\u055e\u0001\u0000\u0000\u0000\u00be\u0569\u0001\u0000"+
		"\u0000\u0000\u00c0\u056b\u0001\u0000\u0000\u0000\u00c2\u0573\u0001\u0000"+
		"\u0000\u0000\u00c4\u057b\u0001\u0000\u0000\u0000\u00c6\u0587\u0001\u0000"+
		"\u0000\u0000\u00c8\u058e\u0001\u0000\u0000\u0000\u00ca\u0590\u0001\u0000"+
		"\u0000\u0000\u00cc\u0597\u0001\u0000\u0000\u0000\u00ce\u0599\u0001\u0000"+
		"\u0000\u0000\u00d0\u059f\u0001\u0000\u0000\u0000\u00d2\u05a1\u0001\u0000"+
		"\u0000\u0000\u00d4\u05af\u0001\u0000\u0000\u0000\u00d6\u05b4\u0001\u0000"+
		"\u0000\u0000\u00d8\u05c5\u0001\u0000\u0000\u0000\u00da\u05c7\u0001\u0000"+
		"\u0000\u0000\u00dc\u05cc\u0001\u0000\u0000\u0000\u00de\u05d7\u0001\u0000"+
		"\u0000\u0000\u00e0\u05e0\u0001\u0000\u0000\u0000\u00e2\u05e5\u0001\u0000"+
		"\u0000\u0000\u00e4\u05e7\u0001\u0000\u0000\u0000\u00e6\u05f1\u0001\u0000"+
		"\u0000\u0000\u00e8\u05f7\u0001\u0000\u0000\u0000\u00ea\u05f9\u0001\u0000"+
		"\u0000\u0000\u00ec\u05ff\u0001\u0000\u0000\u0000\u00ee\u0601\u0001\u0000"+
		"\u0000\u0000\u00f0\u0605\u0001\u0000\u0000\u0000\u00f2\u0609\u0001\u0000"+
		"\u0000\u0000\u00f4\u060d\u0001\u0000\u0000\u0000\u00f6\u060f\u0001\u0000"+
		"\u0000\u0000\u00f8\u0614\u0001\u0000\u0000\u0000\u00fa\u0616\u0001\u0000"+
		"\u0000\u0000\u00fc\u0618\u0001\u0000\u0000\u0000\u00fe\u061a\u0001\u0000"+
		"\u0000\u0000\u0100\u061c\u0001\u0000\u0000\u0000\u0102\u061e\u0001\u0000"+
		"\u0000\u0000\u0104\u0620\u0001\u0000\u0000\u0000\u0106\u0622\u0001\u0000"+
		"\u0000\u0000\u0108\u0626\u0001\u0000\u0000\u0000\u010a\u062a\u0001\u0000"+
		"\u0000\u0000\u010c\u062e\u0001\u0000\u0000\u0000\u010e\u0632\u0001\u0000"+
		"\u0000\u0000\u0110\u0634\u0001\u0000\u0000\u0000\u0112\u063c\u0001\u0000"+
		"\u0000\u0000\u0114\u063e\u0001\u0000\u0000\u0000\u0116\u0640\u0001\u0000"+
		"\u0000\u0000\u0118\u0642\u0001\u0000\u0000\u0000\u011a\u0644\u0001\u0000"+
		"\u0000\u0000\u011c\u0648\u0001\u0000\u0000\u0000\u011e\u064c\u0001\u0000"+
		"\u0000\u0000\u0120\u0121\u0003\u0002\u0001\u0000\u0121\u0122\u0005\u0000"+
		"\u0000\u0001\u0122\u0001\u0001\u0000\u0000\u0000\u0123\u0127\u0003\u0004"+
		"\u0002\u0000\u0124\u0127\u0003\n\u0005\u0000\u0125\u0127\u0003\f\u0006"+
		"\u0000\u0126\u0123\u0001\u0000\u0000\u0000\u0126\u0124\u0001\u0000\u0000"+
		"\u0000\u0126\u0125\u0001\u0000\u0000\u0000\u0127\u0003\u0001\u0000\u0000"+
		"\u0000\u0128\u0129\u0003B!\u0000\u0129\u012b\u0003\u000e\u0007\u0000\u012a"+
		"\u012c\u0003N\'\u0000\u012b\u012a\u0001\u0000\u0000\u0000\u012b\u012c"+
		"\u0001\u0000\u0000\u0000\u012c\u012e\u0001\u0000\u0000\u0000\u012d\u012f"+
		"\u0003P(\u0000\u012e\u012d\u0001\u0000\u0000\u0000\u012e\u012f\u0001\u0000"+
		"\u0000\u0000\u012f\u0131\u0001\u0000\u0000\u0000\u0130\u0132\u0003T*\u0000"+
		"\u0131\u0130\u0001\u0000\u0000\u0000\u0131\u0132\u0001\u0000\u0000\u0000"+
		"\u0132\u0134\u0001\u0000\u0000\u0000\u0133\u0135\u0003V+\u0000\u0134\u0133"+
		"\u0001\u0000\u0000\u0000\u0134\u0135\u0001\u0000\u0000\u0000\u0135\u0137"+
		"\u0001\u0000\u0000\u0000\u0136\u0138\u0003\b\u0004\u0000\u0137\u0136\u0001"+
		"\u0000\u0000\u0000\u0137\u0138\u0001\u0000\u0000\u0000\u0138\u014a\u0001"+
		"\u0000\u0000\u0000\u0139\u013b\u0003\u000e\u0007\u0000\u013a\u013c\u0003"+
		"N\'\u0000\u013b\u013a\u0001\u0000\u0000\u0000\u013b\u013c\u0001\u0000"+
		"\u0000\u0000\u013c\u013e\u0001\u0000\u0000\u0000\u013d\u013f\u0003P(\u0000"+
		"\u013e\u013d\u0001\u0000\u0000\u0000\u013e\u013f\u0001\u0000\u0000\u0000"+
		"\u013f\u0141\u0001\u0000\u0000\u0000\u0140\u0142\u0003T*\u0000\u0141\u0140"+
		"\u0001\u0000\u0000\u0000\u0141\u0142\u0001\u0000\u0000\u0000\u0142\u0144"+
		"\u0001\u0000\u0000\u0000\u0143\u0145\u0003V+\u0000\u0144\u0143\u0001\u0000"+
		"\u0000\u0000\u0144\u0145\u0001\u0000\u0000\u0000\u0145\u0147\u0001\u0000"+
		"\u0000\u0000\u0146\u0148\u0003\b\u0004\u0000\u0147\u0146\u0001\u0000\u0000"+
		"\u0000\u0147\u0148\u0001\u0000\u0000\u0000\u0148\u014a\u0001\u0000\u0000"+
		"\u0000\u0149\u0128\u0001\u0000\u0000\u0000\u0149\u0139\u0001\u0000\u0000"+
		"\u0000\u014a\u0005\u0001\u0000\u0000\u0000\u014b\u014d\u0005u\u0000\u0000"+
		"\u014c\u014e\u0005\u0014\u0000\u0000\u014d\u014c\u0001\u0000\u0000\u0000"+
		"\u014d\u014e\u0001\u0000\u0000\u0000\u014e\u0158\u0001\u0000\u0000\u0000"+
		"\u014f\u0151\u0005C\u0000\u0000\u0150\u0152\u0005\u0014\u0000\u0000\u0151"+
		"\u0150\u0001\u0000\u0000\u0000\u0151\u0152\u0001\u0000\u0000\u0000\u0152"+
		"\u0158\u0001\u0000\u0000\u0000\u0153\u0155\u00051\u0000\u0000\u0154\u0156"+
		"\u0005\u0014\u0000\u0000\u0155\u0154\u0001\u0000\u0000\u0000\u0155\u0156"+
		"\u0001\u0000\u0000\u0000\u0156\u0158\u0001\u0000\u0000\u0000\u0157\u014b"+
		"\u0001\u0000\u0000\u0000\u0157\u014f\u0001\u0000\u0000\u0000\u0157\u0153"+
		"\u0001\u0000\u0000\u0000\u0158\u0007\u0001\u0000\u0000\u0000\u0159\u015a"+
		"\u0003\u0006\u0003\u0000\u015a\u015b\u0003\u0004\u0002\u0000\u015b\t\u0001"+
		"\u0000\u0000\u0000\u015c\u015e\u0003:\u001d\u0000\u015d\u015f\u0003N\'"+
		"\u0000\u015e\u015d\u0001\u0000\u0000\u0000\u015e\u015f\u0001\u0000\u0000"+
		"\u0000\u015f\u000b\u0001\u0000\u0000\u0000\u0160\u0162\u0003@ \u0000\u0161"+
		"\u0163\u0003N\'\u0000\u0162\u0161\u0001\u0000\u0000\u0000\u0162\u0163"+
		"\u0001\u0000\u0000\u0000\u0163\r\u0001\u0000\u0000\u0000\u0164\u0165\u0005"+
		":\u0000\u0000\u0165\u016a\u0003\u0012\t\u0000\u0166\u0167\u0005\u0001"+
		"\u0000\u0000\u0167\u0169\u0003\u0010\b\u0000\u0168\u0166\u0001\u0000\u0000"+
		"\u0000\u0169\u016c\u0001\u0000\u0000\u0000\u016a\u0168\u0001\u0000\u0000"+
		"\u0000\u016a\u016b\u0001\u0000\u0000\u0000\u016b\u000f\u0001\u0000\u0000"+
		"\u0000\u016c\u016a\u0001\u0000\u0000\u0000\u016d\u0179\u0003\u0012\t\u0000"+
		"\u016e\u0179\u0003\"\u0011\u0000\u016f\u0170\u0005\u0002\u0000\u0000\u0170"+
		"\u0171\u0003^/\u0000\u0171\u0176\u0005\u0003\u0000\u0000\u0172\u0174\u0005"+
		"\u0017\u0000\u0000\u0173\u0172\u0001\u0000\u0000\u0000\u0173\u0174\u0001"+
		"\u0000\u0000\u0000\u0174\u0175\u0001\u0000\u0000\u0000\u0175\u0177\u0003"+
		"\u00e2q\u0000\u0176\u0173\u0001\u0000\u0000\u0000\u0176\u0177\u0001\u0000"+
		"\u0000\u0000\u0177\u0179\u0001\u0000\u0000\u0000\u0178\u016d\u0001\u0000"+
		"\u0000\u0000\u0178\u016e\u0001\u0000\u0000\u0000\u0178\u016f\u0001\u0000"+
		"\u0000\u0000\u0179\u0011\u0001\u0000\u0000\u0000\u017a\u017f\u0003\u0014"+
		"\n\u0000\u017b\u017e\u0003\u0016\u000b\u0000\u017c\u017e\u0003\u0018\f"+
		"\u0000\u017d\u017b\u0001\u0000\u0000\u0000\u017d\u017c\u0001\u0000\u0000"+
		"\u0000\u017e\u0181\u0001\u0000\u0000\u0000\u017f\u017d\u0001\u0000\u0000"+
		"\u0000\u017f\u0180\u0001\u0000\u0000\u0000\u0180\u0013\u0001\u0000\u0000"+
		"\u0000\u0181\u017f\u0001\u0000\u0000\u0000\u0182\u0187\u0003\u0110\u0088"+
		"\u0000\u0183\u0185\u0005\u0017\u0000\u0000\u0184\u0183\u0001\u0000\u0000"+
		"\u0000\u0184\u0185\u0001\u0000\u0000\u0000\u0185\u0186\u0001\u0000\u0000"+
		"\u0000\u0186\u0188\u0003\u00e2q\u0000\u0187\u0184\u0001\u0000\u0000\u0000"+
		"\u0187\u0188\u0001\u0000\u0000\u0000\u0188\u0015\u0001\u0000\u0000\u0000"+
		"\u0189\u018a\u0003\u001a\r\u0000\u018a\u018f\u0003\u001e\u000f\u0000\u018b"+
		"\u018d\u0005\u0017\u0000\u0000\u018c\u018b\u0001\u0000\u0000\u0000\u018c"+
		"\u018d\u0001\u0000\u0000\u0000\u018d\u018e\u0001\u0000\u0000\u0000\u018e"+
		"\u0190\u0003\u00e2q\u0000\u018f\u018c\u0001\u0000\u0000\u0000\u018f\u0190"+
		"\u0001\u0000\u0000\u0000\u0190\u0192\u0001\u0000\u0000\u0000\u0191\u0193"+
		"\u0003\u001c\u000e\u0000\u0192\u0191\u0001\u0000\u0000\u0000\u0192\u0193"+
		"\u0001\u0000\u0000\u0000\u0193\u0017\u0001\u0000\u0000\u0000\u0194\u0195"+
		"\u0003\u001a\r\u0000\u0195\u0196\u00056\u0000\u0000\u0196\u019b\u0003"+
		"\u001e\u000f\u0000\u0197\u0199\u0005\u0017\u0000\u0000\u0198\u0197\u0001"+
		"\u0000\u0000\u0000\u0198\u0199\u0001\u0000\u0000\u0000\u0199\u019a\u0001"+
		"\u0000\u0000\u0000\u019a\u019c\u0003\u00e2q\u0000\u019b\u0198\u0001\u0000"+
		"\u0000\u0000\u019b\u019c\u0001\u0000\u0000\u0000\u019c\u019e\u0001\u0000"+
		"\u0000\u0000\u019d\u019f\u0003\u001c\u000e\u0000\u019e\u019d\u0001\u0000"+
		"\u0000\u0000\u019e\u019f\u0001\u0000\u0000\u0000\u019f\u0019\u0001\u0000"+
		"\u0000\u0000\u01a0\u01a2\u0005I\u0000\u0000\u01a1\u01a3\u0005_\u0000\u0000"+
		"\u01a2\u01a1\u0001\u0000\u0000\u0000\u01a2\u01a3\u0001\u0000\u0000\u0000"+
		"\u01a3\u01a6\u0001\u0000\u0000\u0000\u01a4\u01a6\u0005A\u0000\u0000\u01a5"+
		"\u01a0\u0001\u0000\u0000\u0000\u01a5\u01a4\u0001\u0000\u0000\u0000\u01a5"+
		"\u01a6\u0001\u0000\u0000\u0000\u01a6\u01a7\u0001\u0000\u0000\u0000\u01a7"+
		"\u01a8\u0005E\u0000\u0000\u01a8\u001b\u0001\u0000\u0000\u0000\u01a9\u01aa"+
		"\u0005\\\u0000\u0000\u01aa\u01ab\u0003t:\u0000\u01ab\u001d\u0001\u0000"+
		"\u0000\u0000\u01ac\u01b5\u0003 \u0010\u0000\u01ad\u01ae\u0005q\u0000\u0000"+
		"\u01ae\u01af\u0005\u0002\u0000\u0000\u01af\u01b0\u0003 \u0010\u0000\u01b0"+
		"\u01b1\u0005\u0017\u0000\u0000\u01b1\u01b2\u0003\u0106\u0083\u0000\u01b2"+
		"\u01b3\u0005\u0003\u0000\u0000\u01b3\u01b5\u0001\u0000\u0000\u0000\u01b4"+
		"\u01ac\u0001\u0000\u0000\u0000\u01b4\u01ad\u0001\u0000\u0000\u0000\u01b5"+
		"\u001f\u0001\u0000\u0000\u0000\u01b6\u01b7\u0003\u00e2q\u0000\u01b7\u01b8"+
		"\u0005\u0004\u0000\u0000\u01b8\u01ba\u0001\u0000\u0000\u0000\u01b9\u01b6"+
		"\u0001\u0000\u0000\u0000\u01b9\u01ba\u0001\u0000\u0000\u0000\u01ba\u01c0"+
		"\u0001\u0000\u0000\u0000\u01bb\u01bc\u0003\u0104\u0082\u0000\u01bc\u01bd"+
		"\u0005\u0004\u0000\u0000\u01bd\u01bf\u0001\u0000\u0000\u0000\u01be\u01bb"+
		"\u0001\u0000\u0000\u0000\u01bf\u01c2\u0001\u0000\u0000\u0000\u01c0\u01be"+
		"\u0001\u0000\u0000\u0000\u01c0\u01c1\u0001\u0000\u0000\u0000\u01c1\u01c3"+
		"\u0001\u0000\u0000\u0000\u01c2\u01c0\u0001\u0000\u0000\u0000\u01c3\u01c4"+
		"\u0003\u010a\u0085\u0000\u01c4!\u0001\u0000\u0000\u0000\u01c5\u01c6\u0005"+
		"?\u0000\u0000\u01c6\u01c7\u0005\u0002\u0000\u0000\u01c7\u01c8\u00038\u001c"+
		"\u0000\u01c8\u01cd\u0005\u0003\u0000\u0000\u01c9\u01cb\u0005\u0017\u0000"+
		"\u0000\u01ca\u01c9\u0001\u0000\u0000\u0000\u01ca\u01cb\u0001\u0000\u0000"+
		"\u0000\u01cb\u01cc\u0001\u0000\u0000\u0000\u01cc\u01ce\u0003\u00e2q\u0000"+
		"\u01cd\u01ca\u0001\u0000\u0000\u0000\u01cd\u01ce\u0001\u0000\u0000\u0000"+
		"\u01ce#\u0001\u0000\u0000\u0000\u01cf\u01d6\u0003&\u0013\u0000\u01d0\u01d1"+
		"\u0005/\u0000\u0000\u01d1\u01d2\u0005\u0002\u0000\u0000\u01d2\u01d3\u0003"+
		"\u00e2q\u0000\u01d3\u01d4\u0005\u0003\u0000\u0000\u01d4\u01d6\u0001\u0000"+
		"\u0000\u0000\u01d5\u01cf\u0001\u0000\u0000\u0000\u01d5\u01d0\u0001\u0000"+
		"\u0000\u0000\u01d6%\u0001\u0000\u0000\u0000\u01d7\u01d8\u0005F\u0000\u0000"+
		"\u01d8\u01d9\u0005\u0002\u0000\u0000\u01d9\u01da\u0003\u00e2q\u0000\u01da"+
		"\u01db\u0005\u0003\u0000\u0000\u01db\u01e2\u0001\u0000\u0000\u0000\u01dc"+
		"\u01dd\u0005x\u0000\u0000\u01dd\u01de\u0005\u0002\u0000\u0000\u01de\u01df"+
		"\u0003\u00e2q\u0000\u01df\u01e0\u0005\u0003\u0000\u0000\u01e0\u01e2\u0001"+
		"\u0000\u0000\u0000\u01e1\u01d7\u0001\u0000\u0000\u0000\u01e1\u01dc\u0001"+
		"\u0000\u0000\u0000\u01e2\'\u0001\u0000\u0000\u0000\u01e3\u01ee\u0003$"+
		"\u0012\u0000\u01e4\u01e5\u0005q\u0000\u0000\u01e5\u01e6\u0005\u0002\u0000"+
		"\u0000\u01e6\u01e7\u0003$\u0012\u0000\u01e7\u01e8\u0005\u0017\u0000\u0000"+
		"\u01e8\u01e9\u0003\u0106\u0083\u0000\u01e9\u01ea\u0005\u0003\u0000\u0000"+
		"\u01ea\u01ee\u0001\u0000\u0000\u0000\u01eb\u01ee\u00032\u0019\u0000\u01ec"+
		"\u01ee\u00036\u001b\u0000\u01ed\u01e3\u0001\u0000\u0000\u0000\u01ed\u01e4"+
		"\u0001\u0000\u0000\u0000\u01ed\u01eb\u0001\u0000\u0000\u0000\u01ed\u01ec"+
		"\u0001\u0000\u0000\u0000\u01ee)\u0001\u0000\u0000\u0000\u01ef\u01f2\u0003"+
		"\u00e2q\u0000\u01f0\u01f2\u0003&\u0013\u0000\u01f1\u01ef\u0001\u0000\u0000"+
		"\u0000\u01f1\u01f0\u0001\u0000\u0000\u0000\u01f2+\u0001\u0000\u0000\u0000"+
		"\u01f3\u01fd\u0003.\u0017\u0000\u01f4\u01f9\u00030\u0018\u0000\u01f5\u01f6"+
		"\u0005\u0004\u0000\u0000\u01f6\u01f8\u0003\u010a\u0085\u0000\u01f7\u01f5"+
		"\u0001\u0000\u0000\u0000\u01f8\u01fb\u0001\u0000\u0000\u0000\u01f9\u01f7"+
		"\u0001\u0000\u0000\u0000\u01f9\u01fa\u0001\u0000\u0000\u0000\u01fa\u01fd"+
		"\u0001\u0000\u0000\u0000\u01fb\u01f9\u0001\u0000\u0000\u0000\u01fc\u01f3"+
		"\u0001\u0000\u0000\u0000\u01fc\u01f4\u0001\u0000\u0000\u0000\u01fd-\u0001"+
		"\u0000\u0000\u0000\u01fe\u0203\u0003*\u0015\u0000\u01ff\u0200\u0005\u0004"+
		"\u0000\u0000\u0200\u0202\u0003\u010a\u0085\u0000\u0201\u01ff\u0001\u0000"+
		"\u0000\u0000\u0202\u0205\u0001\u0000\u0000\u0000\u0203\u0201\u0001\u0000"+
		"\u0000\u0000\u0203\u0204\u0001\u0000\u0000\u0000\u0204/\u0001\u0000\u0000"+
		"\u0000\u0205\u0203\u0001\u0000\u0000\u0000\u0206\u0207\u0005q\u0000\u0000"+
		"\u0207\u0208\u0005\u0002\u0000\u0000\u0208\u0209\u0003,\u0016\u0000\u0209"+
		"\u020a\u0005\u0017\u0000\u0000\u020a\u020b\u0003\u0106\u0083\u0000\u020b"+
		"\u020c\u0005\u0003\u0000\u0000\u020c1\u0001\u0000\u0000\u0000\u020d\u020e"+
		"\u0003,\u0016\u0000\u020e\u020f\u0005\u0004\u0000\u0000\u020f\u0210\u0003"+
		"\u010c\u0086\u0000\u02103\u0001\u0000\u0000\u0000\u0211\u0214\u00032\u0019"+
		"\u0000\u0212\u0214\u0003*\u0015\u0000\u0213\u0211\u0001\u0000\u0000\u0000"+
		"\u0213\u0212\u0001\u0000\u0000\u0000\u02145\u0001\u0000\u0000\u0000\u0215"+
		"\u0216\u0003,\u0016\u0000\u0216\u0217\u0005\u0004\u0000\u0000\u0217\u0218"+
		"\u0003\u010a\u0085\u0000\u02187\u0001\u0000\u0000\u0000\u0219\u021a\u0003"+
		",\u0016\u0000\u021a\u021b\u0005\u0004\u0000\u0000\u021b\u021c\u0003\u010e"+
		"\u0087\u0000\u021c9\u0001\u0000\u0000\u0000\u021d\u021e\u0005v\u0000\u0000"+
		"\u021e\u0223\u0003\u0110\u0088\u0000\u021f\u0221\u0005\u0017\u0000\u0000"+
		"\u0220\u021f\u0001\u0000\u0000\u0000\u0220\u0221\u0001\u0000\u0000\u0000"+
		"\u0221\u0222\u0001\u0000\u0000\u0000\u0222\u0224\u0003\u00e2q\u0000\u0223"+
		"\u0220\u0001\u0000\u0000\u0000\u0223\u0224\u0001\u0000\u0000\u0000\u0224"+
		"\u0225\u0001\u0000\u0000\u0000\u0225\u0226\u0005f\u0000\u0000\u0226\u022b"+
		"\u0003<\u001e\u0000\u0227\u0228\u0005\u0001\u0000\u0000\u0228\u022a\u0003"+
		"<\u001e\u0000\u0229\u0227\u0001\u0000\u0000\u0000\u022a\u022d\u0001\u0000"+
		"\u0000\u0000\u022b\u0229\u0001\u0000\u0000\u0000\u022b\u022c\u0001\u0000"+
		"\u0000\u0000\u022c;\u0001\u0000\u0000\u0000\u022d\u022b\u0001\u0000\u0000"+
		"\u0000\u022e\u022f\u0003\u00e2q\u0000\u022f\u0230\u0005\u0004\u0000\u0000"+
		"\u0230\u0232\u0001\u0000\u0000\u0000\u0231\u022e\u0001\u0000\u0000\u0000"+
		"\u0231\u0232\u0001\u0000\u0000\u0000\u0232\u0238\u0001\u0000\u0000\u0000"+
		"\u0233\u0234\u0003\u0104\u0082\u0000\u0234\u0235\u0005\u0004\u0000\u0000"+
		"\u0235\u0237\u0001\u0000\u0000\u0000\u0236\u0233\u0001\u0000\u0000\u0000"+
		"\u0237\u023a\u0001\u0000\u0000\u0000\u0238\u0236\u0001\u0000\u0000\u0000"+
		"\u0238\u0239\u0001\u0000\u0000\u0000\u0239\u023d\u0001\u0000\u0000\u0000"+
		"\u023a\u0238\u0001\u0000\u0000\u0000\u023b\u023e\u0003\u010c\u0086\u0000"+
		"\u023c\u023e\u0003\u010a\u0085\u0000\u023d\u023b\u0001\u0000\u0000\u0000"+
		"\u023d\u023c\u0001\u0000\u0000\u0000\u023e\u023f\u0001\u0000\u0000\u0000"+
		"\u023f\u0240\u0005|\u0000\u0000\u0240\u0241\u0003>\u001f\u0000\u0241="+
		"\u0001\u0000\u0000\u0000\u0242\u0246\u0003r9\u0000\u0243\u0246\u0003\u00aa"+
		"U\u0000\u0244\u0246\u0005W\u0000\u0000\u0245\u0242\u0001\u0000\u0000\u0000"+
		"\u0245\u0243\u0001\u0000\u0000\u0000\u0245\u0244\u0001\u0000\u0000\u0000"+
		"\u0246?\u0001\u0000\u0000\u0000\u0247\u0248\u0005(\u0000\u0000\u0248\u0249"+
		"\u0005:\u0000\u0000\u0249\u024e\u0003\u0110\u0088\u0000\u024a\u024c\u0005"+
		"\u0017\u0000\u0000\u024b\u024a\u0001\u0000\u0000\u0000\u024b\u024c\u0001"+
		"\u0000\u0000\u0000\u024c\u024d\u0001\u0000\u0000\u0000\u024d\u024f\u0003"+
		"\u00e2q\u0000\u024e\u024b\u0001\u0000\u0000\u0000\u024e\u024f\u0001\u0000"+
		"\u0000\u0000\u024fA\u0001\u0000\u0000\u0000\u0250\u0252\u0005e\u0000\u0000"+
		"\u0251\u0253\u0005*\u0000\u0000\u0252\u0251\u0001\u0000\u0000\u0000\u0252"+
		"\u0253\u0001\u0000\u0000\u0000\u0253\u0254\u0001\u0000\u0000\u0000\u0254"+
		"\u0259\u0003D\"\u0000\u0255\u0256\u0005\u0001\u0000\u0000\u0256\u0258"+
		"\u0003D\"\u0000\u0257\u0255\u0001\u0000\u0000\u0000\u0258\u025b\u0001"+
		"\u0000\u0000\u0000\u0259\u0257\u0001\u0000\u0000\u0000\u0259\u025a\u0001"+
		"\u0000\u0000\u0000\u025aC\u0001\u0000\u0000\u0000\u025b\u0259\u0001\u0000"+
		"\u0000\u0000\u025c\u0261\u0003F#\u0000\u025d\u025f\u0005\u0017\u0000\u0000"+
		"\u025e\u025d\u0001\u0000\u0000\u0000\u025e\u025f\u0001\u0000\u0000\u0000"+
		"\u025f\u0260\u0001\u0000\u0000\u0000\u0260\u0262\u0003\u0112\u0089\u0000"+
		"\u0261\u025e\u0001\u0000\u0000\u0000\u0261\u0262\u0001\u0000\u0000\u0000"+
		"\u0262E\u0001\u0000\u0000\u0000\u0263\u026e\u0003(\u0014\u0000\u0264\u026e"+
		"\u0003r9\u0000\u0265\u026e\u0003L&\u0000\u0266\u026e\u0003\u00e2q\u0000"+
		"\u0267\u0268\u0005Z\u0000\u0000\u0268\u0269\u0005\u0002\u0000\u0000\u0269"+
		"\u026a\u0003\u00e2q\u0000\u026a\u026b\u0005\u0003\u0000\u0000\u026b\u026e"+
		"\u0001\u0000\u0000\u0000\u026c\u026e\u0003H$\u0000\u026d\u0263\u0001\u0000"+
		"\u0000\u0000\u026d\u0264\u0001\u0000\u0000\u0000\u026d\u0265\u0001\u0000"+
		"\u0000\u0000\u026d\u0266\u0001\u0000\u0000\u0000\u026d\u0267\u0001\u0000"+
		"\u0000\u0000\u026d\u026c\u0001\u0000\u0000\u0000\u026eG\u0001\u0000\u0000"+
		"\u0000\u026f\u0270\u0005U\u0000\u0000\u0270\u0271\u0003\u00e4r\u0000\u0271"+
		"\u0272\u0005\u0002\u0000\u0000\u0272\u0277\u0003J%\u0000\u0273\u0274\u0005"+
		"\u0001\u0000\u0000\u0274\u0276\u0003J%\u0000\u0275\u0273\u0001\u0000\u0000"+
		"\u0000\u0276\u0279\u0001\u0000\u0000\u0000\u0277\u0275\u0001\u0000\u0000"+
		"\u0000\u0277\u0278\u0001\u0000\u0000\u0000\u0278\u027a\u0001\u0000\u0000"+
		"\u0000\u0279\u0277\u0001\u0000\u0000\u0000\u027a\u027b\u0005\u0003\u0000"+
		"\u0000\u027bI\u0001\u0000\u0000\u0000\u027c\u0282\u0003(\u0014\u0000\u027d"+
		"\u0282\u0003r9\u0000\u027e\u0282\u0003L&\u0000\u027f\u0282\u0003\u00e2"+
		"q\u0000\u0280\u0282\u0003\u00e6s\u0000\u0281\u027c\u0001\u0000\u0000\u0000"+
		"\u0281\u027d\u0001\u0000\u0000\u0000\u0281\u027e\u0001\u0000\u0000\u0000"+
		"\u0281\u027f\u0001\u0000\u0000\u0000\u0281\u0280\u0001\u0000\u0000\u0000"+
		"\u0282K\u0001\u0000\u0000\u0000\u0283\u0284\u0007\u0000\u0000\u0000\u0284"+
		"\u0286\u0005\u0002\u0000\u0000\u0285\u0287\u0005*\u0000\u0000\u0286\u0285"+
		"\u0001\u0000\u0000\u0000\u0286\u0287\u0001\u0000\u0000\u0000\u0287\u0288"+
		"\u0001\u0000\u0000\u0000\u0288\u0289\u0003p8\u0000\u0289\u028a\u0005\u0003"+
		"\u0000\u0000\u028a\u0295\u0001\u0000\u0000\u0000\u028b\u028c\u0005\"\u0000"+
		"\u0000\u028c\u028e\u0005\u0002\u0000\u0000\u028d\u028f\u0005*\u0000\u0000"+
		"\u028e\u028d\u0001\u0000\u0000\u0000\u028e\u028f\u0001\u0000\u0000\u0000"+
		"\u028f\u0290\u0001\u0000\u0000\u0000\u0290\u0291\u0003p8\u0000\u0291\u0292"+
		"\u0005\u0003\u0000\u0000\u0292\u0295\u0001\u0000\u0000\u0000\u0293\u0295"+
		"\u0003\u00c4b\u0000\u0294\u0283\u0001\u0000\u0000\u0000\u0294\u028b\u0001"+
		"\u0000\u0000\u0000\u0294\u0293\u0001\u0000\u0000\u0000\u0295M\u0001\u0000"+
		"\u0000\u0000\u0296\u0297\u0005{\u0000\u0000\u0297\u0298\u0003t:\u0000"+
		"\u0298O\u0001\u0000\u0000\u0000\u0299\u029a\u0005<\u0000\u0000\u029a\u029b"+
		"\u0005\u001c\u0000\u0000\u029b\u02a0\u0003R)\u0000\u029c\u029d\u0005\u0001"+
		"\u0000\u0000\u029d\u029f\u0003R)\u0000\u029e\u029c\u0001\u0000\u0000\u0000"+
		"\u029f\u02a2\u0001\u0000\u0000\u0000\u02a0\u029e\u0001\u0000\u0000\u0000"+
		"\u02a0\u02a1\u0001\u0000\u0000\u0000\u02a1Q\u0001\u0000\u0000\u0000\u02a2"+
		"\u02a0\u0001\u0000\u0000\u0000\u02a3\u02a6\u0003(\u0014\u0000\u02a4\u02a6"+
		"\u0003\u00e2q\u0000\u02a5\u02a3\u0001\u0000\u0000\u0000\u02a5\u02a4\u0001"+
		"\u0000\u0000\u0000\u02a6S\u0001\u0000\u0000\u0000\u02a7\u02a8\u0005=\u0000"+
		"\u0000\u02a8\u02a9\u0003t:\u0000\u02a9U\u0001\u0000\u0000\u0000\u02aa"+
		"\u02ab\u0005^\u0000\u0000\u02ab\u02ac\u0005\u001c\u0000\u0000\u02ac\u02b1"+
		"\u0003X,\u0000\u02ad\u02ae\u0005\u0001\u0000\u0000\u02ae\u02b0\u0003X"+
		",\u0000\u02af\u02ad\u0001\u0000\u0000\u0000\u02b0\u02b3\u0001\u0000\u0000"+
		"\u0000\u02b1\u02af\u0001\u0000\u0000\u0000\u02b1\u02b2\u0001\u0000\u0000"+
		"\u0000\u02b2W\u0001\u0000\u0000\u0000\u02b3\u02b1\u0001\u0000\u0000\u0000"+
		"\u02b4\u02b6\u0003Z-\u0000\u02b5\u02b7\u0007\u0001\u0000\u0000\u02b6\u02b5"+
		"\u0001\u0000\u0000\u0000\u02b6\u02b7\u0001\u0000\u0000\u0000\u02b7\u02b9"+
		"\u0001\u0000\u0000\u0000\u02b8\u02ba\u0003\\.\u0000\u02b9\u02b8\u0001"+
		"\u0000\u0000\u0000\u02b9\u02ba\u0001\u0000\u0000\u0000\u02baY\u0001\u0000"+
		"\u0000\u0000\u02bb\u02c0\u00032\u0019\u0000\u02bc\u02c0\u0003*\u0015\u0000"+
		"\u02bd\u02c0\u0003\u00a0P\u0000\u02be\u02c0\u0003r9\u0000\u02bf\u02bb"+
		"\u0001\u0000\u0000\u0000\u02bf\u02bc\u0001\u0000\u0000\u0000\u02bf\u02bd"+
		"\u0001\u0000\u0000\u0000\u02bf\u02be\u0001\u0000\u0000\u0000\u02c0[\u0001"+
		"\u0000\u0000\u0000\u02c1\u02c2\u0005Y\u0000\u0000\u02c2\u02c3\u0007\u0002"+
		"\u0000\u0000\u02c3]\u0001\u0000\u0000\u0000\u02c4\u02c5\u0003n7\u0000"+
		"\u02c5\u02c7\u0003`0\u0000\u02c6\u02c8\u0003N\'\u0000\u02c7\u02c6\u0001"+
		"\u0000\u0000\u0000\u02c7\u02c8\u0001\u0000\u0000\u0000\u02c8\u02ca\u0001"+
		"\u0000\u0000\u0000\u02c9\u02cb\u0003P(\u0000\u02ca\u02c9\u0001\u0000\u0000"+
		"\u0000\u02ca\u02cb\u0001\u0000\u0000\u0000\u02cb\u02cd\u0001\u0000\u0000"+
		"\u0000\u02cc\u02ce\u0003T*\u0000\u02cd\u02cc\u0001\u0000\u0000\u0000\u02cd"+
		"\u02ce\u0001\u0000\u0000\u0000\u02ce_\u0001\u0000\u0000\u0000\u02cf\u02d0"+
		"\u0005:\u0000\u0000\u02d0\u02d8\u0003b1\u0000\u02d1\u02d4\u0005\u0001"+
		"\u0000\u0000\u02d2\u02d5\u0003b1\u0000\u02d3\u02d5\u0003\"\u0011\u0000"+
		"\u02d4\u02d2\u0001\u0000\u0000\u0000\u02d4\u02d3\u0001\u0000\u0000\u0000"+
		"\u02d5\u02d7\u0001\u0000\u0000\u0000\u02d6\u02d1\u0001\u0000\u0000\u0000"+
		"\u02d7\u02da\u0001\u0000\u0000\u0000\u02d8\u02d6\u0001\u0000\u0000\u0000"+
		"\u02d8\u02d9\u0001\u0000\u0000\u0000\u02d9a\u0001\u0000\u0000\u0000\u02da"+
		"\u02d8\u0001\u0000\u0000\u0000\u02db\u02eb\u0003\u0012\t\u0000\u02dc\u02e1"+
		"\u0003d2\u0000\u02dd\u02df\u0005\u0017\u0000\u0000\u02de\u02dd\u0001\u0000"+
		"\u0000\u0000\u02de\u02df\u0001\u0000\u0000\u0000\u02df\u02e0\u0001\u0000"+
		"\u0000\u0000\u02e0\u02e2\u0003\u00e2q\u0000\u02e1\u02de\u0001\u0000\u0000"+
		"\u0000\u02e1\u02e2\u0001\u0000\u0000\u0000\u02e2\u02e6\u0001\u0000\u0000"+
		"\u0000\u02e3\u02e5\u0003\u0016\u000b\u0000\u02e4\u02e3\u0001\u0000\u0000"+
		"\u0000\u02e5\u02e8\u0001\u0000\u0000\u0000\u02e6\u02e4\u0001\u0000\u0000"+
		"\u0000\u02e6\u02e7\u0001\u0000\u0000\u0000\u02e7\u02eb\u0001\u0000\u0000"+
		"\u0000\u02e8\u02e6\u0001\u0000\u0000\u0000\u02e9\u02eb\u0003l6\u0000\u02ea"+
		"\u02db\u0001\u0000\u0000\u0000\u02ea\u02dc\u0001\u0000\u0000\u0000\u02ea"+
		"\u02e9\u0001\u0000\u0000\u0000\u02ebc\u0001\u0000\u0000\u0000\u02ec\u02ed"+
		"\u0003f3\u0000\u02ed\u02ee\u0005\u0004\u0000\u0000\u02ee\u02ef\u0003\u010a"+
		"\u0085\u0000\u02ef\u02f5\u0001\u0000\u0000\u0000\u02f0\u02f1\u0003f3\u0000"+
		"\u02f1\u02f2\u0005\u0004\u0000\u0000\u02f2\u02f3\u0003\u0108\u0084\u0000"+
		"\u02f3\u02f5\u0001\u0000\u0000\u0000\u02f4\u02ec\u0001\u0000\u0000\u0000"+
		"\u02f4\u02f0\u0001\u0000\u0000\u0000\u02f5e\u0001\u0000\u0000\u0000\u02f6"+
		"\u0300\u0003h4\u0000\u02f7\u02fc\u0003j5\u0000\u02f8\u02f9\u0005\u0004"+
		"\u0000\u0000\u02f9\u02fb\u0003\u010a\u0085\u0000\u02fa\u02f8\u0001\u0000"+
		"\u0000\u0000\u02fb\u02fe\u0001\u0000\u0000\u0000\u02fc\u02fa\u0001\u0000"+
		"\u0000\u0000\u02fc\u02fd\u0001\u0000\u0000\u0000\u02fd\u0300\u0001\u0000"+
		"\u0000\u0000\u02fe\u02fc\u0001\u0000\u0000\u0000\u02ff\u02f6\u0001\u0000"+
		"\u0000\u0000\u02ff\u02f7\u0001\u0000\u0000\u0000\u0300g\u0001\u0000\u0000"+
		"\u0000\u0301\u0306\u0003\u0114\u008a\u0000\u0302\u0303\u0005\u0004\u0000"+
		"\u0000\u0303\u0305\u0003\u010a\u0085\u0000\u0304\u0302\u0001\u0000\u0000"+
		"\u0000\u0305\u0308\u0001\u0000\u0000\u0000\u0306\u0304\u0001\u0000\u0000"+
		"\u0000\u0306\u0307\u0001\u0000\u0000\u0000\u0307i\u0001\u0000\u0000\u0000"+
		"\u0308\u0306\u0001\u0000\u0000\u0000\u0309\u030a\u0005q\u0000\u0000\u030a"+
		"\u030b\u0005\u0002\u0000\u0000\u030b\u030c\u0003f3\u0000\u030c\u030d\u0005"+
		"\u0017\u0000\u0000\u030d\u030e\u0003\u0106\u0083\u0000\u030e\u030f\u0005"+
		"\u0003\u0000\u0000\u030fk\u0001\u0000\u0000\u0000\u0310\u0311\u0005?\u0000"+
		"\u0000\u0311\u0312\u0003\u0114\u008a\u0000\u0312\u0318\u0005\u0004\u0000"+
		"\u0000\u0313\u0314\u0003\u010a\u0085\u0000\u0314\u0315\u0005\u0004\u0000"+
		"\u0000\u0315\u0317\u0001\u0000\u0000\u0000\u0316\u0313\u0001\u0000\u0000"+
		"\u0000\u0317\u031a\u0001\u0000\u0000\u0000\u0318\u0316\u0001\u0000\u0000"+
		"\u0000\u0318\u0319\u0001\u0000\u0000\u0000\u0319\u031b\u0001\u0000\u0000"+
		"\u0000\u031a\u0318\u0001\u0000\u0000\u0000\u031b\u031c\u0003\u0108\u0084"+
		"\u0000\u031cm\u0001\u0000\u0000\u0000\u031d\u031f\u0005e\u0000\u0000\u031e"+
		"\u0320\u0005*\u0000\u0000\u031f\u031e\u0001\u0000\u0000\u0000\u031f\u0320"+
		"\u0001\u0000\u0000\u0000\u0320\u0321\u0001\u0000\u0000\u0000\u0321\u0322"+
		"\u0003p8\u0000\u0322o\u0001\u0000\u0000\u0000\u0323\u0328\u0003(\u0014"+
		"\u0000\u0324\u0328\u0003r9\u0000\u0325\u0328\u0003L&\u0000\u0326\u0328"+
		"\u0003\u00e2q\u0000\u0327\u0323\u0001\u0000\u0000\u0000\u0327\u0324\u0001"+
		"\u0000\u0000\u0000\u0327\u0325\u0001\u0000\u0000\u0000\u0327\u0326\u0001"+
		"\u0000\u0000\u0000\u0328q\u0001\u0000\u0000\u0000\u0329\u0332\u0003\u0098"+
		"L\u0000\u032a\u0332\u0003\u00a0P\u0000\u032b\u0332\u0003\u00a6S\u0000"+
		"\u032c\u0332\u0003\u00a2Q\u0000\u032d\u0332\u0003\u00a4R\u0000\u032e\u0332"+
		"\u0003\u00d0h\u0000\u032f\u0332\u0003\u00acV\u0000\u0330\u0332\u0003\u00be"+
		"_\u0000\u0331\u0329\u0001\u0000\u0000\u0000\u0331\u032a\u0001\u0000\u0000"+
		"\u0000\u0331\u032b\u0001\u0000\u0000\u0000\u0331\u032c\u0001\u0000\u0000"+
		"\u0000\u0331\u032d\u0001\u0000\u0000\u0000\u0331\u032e\u0001\u0000\u0000"+
		"\u0000\u0331\u032f\u0001\u0000\u0000\u0000\u0331\u0330\u0001\u0000\u0000"+
		"\u0000\u0332s\u0001\u0000\u0000\u0000\u0333\u0334\u0006:\uffff\uffff\u0000"+
		"\u0334\u0335\u0003v;\u0000\u0335\u033b\u0001\u0000\u0000\u0000\u0336\u0337"+
		"\n\u0001\u0000\u0000\u0337\u0338\u0005]\u0000\u0000\u0338\u033a\u0003"+
		"v;\u0000\u0339\u0336\u0001\u0000\u0000\u0000\u033a\u033d\u0001\u0000\u0000"+
		"\u0000\u033b\u0339\u0001\u0000\u0000\u0000\u033b\u033c\u0001\u0000\u0000"+
		"\u0000\u033cu\u0001\u0000\u0000\u0000\u033d\u033b\u0001\u0000\u0000\u0000"+
		"\u033e\u033f\u0006;\uffff\uffff\u0000\u033f\u0340\u0003x<\u0000\u0340"+
		"\u0346\u0001\u0000\u0000\u0000\u0341\u0342\n\u0001\u0000\u0000\u0342\u0343"+
		"\u0005\u0015\u0000\u0000\u0343\u0345\u0003x<\u0000\u0344\u0341\u0001\u0000"+
		"\u0000\u0000\u0345\u0348\u0001\u0000\u0000\u0000\u0346\u0344\u0001\u0000"+
		"\u0000\u0000\u0346\u0347\u0001\u0000\u0000\u0000\u0347w\u0001\u0000\u0000"+
		"\u0000\u0348\u0346\u0001\u0000\u0000\u0000\u0349\u034b\u0005V\u0000\u0000"+
		"\u034a\u0349\u0001\u0000\u0000\u0000\u034a\u034b\u0001\u0000\u0000\u0000"+
		"\u034b\u034c\u0001\u0000\u0000\u0000\u034c\u034d\u0003z=\u0000\u034dy"+
		"\u0001\u0000\u0000\u0000\u034e\u0354\u0003|>\u0000\u034f\u0350\u0005\u0002"+
		"\u0000\u0000\u0350\u0351\u0003t:\u0000\u0351\u0352\u0005\u0003\u0000\u0000"+
		"\u0352\u0354\u0001\u0000\u0000\u0000\u0353\u034e\u0001\u0000\u0000\u0000"+
		"\u0353\u034f\u0001\u0000\u0000\u0000\u0354{\u0001\u0000\u0000\u0000\u0355"+
		"\u035e\u0003\u0094J\u0000\u0356\u035e\u0003~?\u0000\u0357\u035e\u0003"+
		"\u0080@\u0000\u0358\u035e\u0003\u0084B\u0000\u0359\u035e\u0003\u0086C"+
		"\u0000\u035a\u035e\u0003\u0088D\u0000\u035b\u035e\u0003\u008aE\u0000\u035c"+
		"\u035e\u0003\u0090H\u0000\u035d\u0355\u0001\u0000\u0000\u0000\u035d\u0356"+
		"\u0001\u0000\u0000\u0000\u035d\u0357\u0001\u0000\u0000\u0000\u035d\u0358"+
		"\u0001\u0000\u0000\u0000\u035d\u0359\u0001\u0000\u0000\u0000\u035d\u035a"+
		"\u0001\u0000\u0000\u0000\u035d\u035b\u0001\u0000\u0000\u0000\u035d\u035c"+
		"\u0001\u0000\u0000\u0000\u035e}\u0001\u0000\u0000\u0000\u035f\u0361\u0003"+
		"\u0098L\u0000\u0360\u0362\u0005V\u0000\u0000\u0361\u0360\u0001\u0000\u0000"+
		"\u0000\u0361\u0362\u0001\u0000\u0000\u0000\u0362\u0363\u0001\u0000\u0000"+
		"\u0000\u0363\u0364\u0005\u001a\u0000\u0000\u0364\u0365\u0003\u0098L\u0000"+
		"\u0365\u0366\u0005\u0015\u0000\u0000\u0366\u0367\u0003\u0098L\u0000\u0367"+
		"\u037b\u0001\u0000\u0000\u0000\u0368\u036a\u0003\u00a0P\u0000\u0369\u036b"+
		"\u0005V\u0000\u0000\u036a\u0369\u0001\u0000\u0000\u0000\u036a\u036b\u0001"+
		"\u0000\u0000\u0000\u036b\u036c\u0001\u0000\u0000\u0000\u036c\u036d\u0005"+
		"\u001a\u0000\u0000\u036d\u036e\u0003\u00a0P\u0000\u036e\u036f\u0005\u0015"+
		"\u0000\u0000\u036f\u0370\u0003\u00a0P\u0000\u0370\u037b\u0001\u0000\u0000"+
		"\u0000\u0371\u0373\u0003\u00a2Q\u0000\u0372\u0374\u0005V\u0000\u0000\u0373"+
		"\u0372\u0001\u0000\u0000\u0000\u0373\u0374\u0001\u0000\u0000\u0000\u0374"+
		"\u0375\u0001\u0000\u0000\u0000\u0375\u0376\u0005\u001a\u0000\u0000\u0376"+
		"\u0377\u0003\u00a2Q\u0000\u0377\u0378\u0005\u0015\u0000\u0000\u0378\u0379"+
		"\u0003\u00a2Q\u0000\u0379\u037b\u0001\u0000\u0000\u0000\u037a\u035f\u0001"+
		"\u0000\u0000\u0000\u037a\u0368\u0001\u0000\u0000\u0000\u037a\u0371\u0001"+
		"\u0000\u0000\u0000\u037b\u007f\u0001\u0000\u0000\u0000\u037c\u037f\u0003"+
		"\u00a0P\u0000\u037d\u037f\u0003\u00aeW\u0000\u037e\u037c\u0001\u0000\u0000"+
		"\u0000\u037e\u037d\u0001\u0000\u0000\u0000\u037f\u0381\u0001\u0000\u0000"+
		"\u0000\u0380\u0382\u0005V\u0000\u0000\u0381\u0380\u0001\u0000\u0000\u0000"+
		"\u0381\u0382\u0001\u0000\u0000\u0000\u0382\u0383\u0001\u0000\u0000\u0000"+
		"\u0383\u0394\u0005?\u0000\u0000\u0384\u0385\u0005\u0002\u0000\u0000\u0385"+
		"\u038a\u0003\u0082A\u0000\u0386\u0387\u0005\u0001\u0000\u0000\u0387\u0389"+
		"\u0003\u0082A\u0000\u0388\u0386\u0001\u0000\u0000\u0000\u0389\u038c\u0001"+
		"\u0000\u0000\u0000\u038a\u0388\u0001\u0000\u0000\u0000\u038a\u038b\u0001"+
		"\u0000\u0000\u0000\u038b\u038d\u0001\u0000\u0000\u0000\u038c\u038a\u0001"+
		"\u0000\u0000\u0000\u038d\u038e\u0005\u0003\u0000\u0000\u038e\u0395\u0001"+
		"\u0000\u0000\u0000\u038f\u0390\u0005\u0002\u0000\u0000\u0390\u0391\u0003"+
		"^/\u0000\u0391\u0392\u0005\u0003\u0000\u0000\u0392\u0395\u0001\u0000\u0000"+
		"\u0000\u0393\u0395\u0003\u0116\u008b\u0000\u0394\u0384\u0001\u0000\u0000"+
		"\u0000\u0394\u038f\u0001\u0000\u0000\u0000\u0394\u0393\u0001\u0000\u0000"+
		"\u0000\u0395\u0081\u0001\u0000\u0000\u0000\u0396\u039e\u0003\u00e6s\u0000"+
		"\u0397\u039e\u0003\u00a0P\u0000\u0398\u039e\u0003\u00fe\u007f\u0000\u0399"+
		"\u039e\u0003\u00fa}\u0000\u039a\u039e\u0003\u00ecv\u0000\u039b\u039e\u0003"+
		"\u0118\u008c\u0000\u039c\u039e\u0003t:\u0000\u039d\u0396\u0001\u0000\u0000"+
		"\u0000\u039d\u0397\u0001\u0000\u0000\u0000\u039d\u0398\u0001\u0000\u0000"+
		"\u0000\u039d\u0399\u0001\u0000\u0000\u0000\u039d\u039a\u0001\u0000\u0000"+
		"\u0000\u039d\u039b\u0001\u0000\u0000\u0000\u039d\u039c\u0001\u0000\u0000"+
		"\u0000\u039e\u0083\u0001\u0000\u0000\u0000\u039f\u03a1\u0003\u00a0P\u0000"+
		"\u03a0\u03a2\u0005V\u0000\u0000\u03a1\u03a0\u0001\u0000\u0000\u0000\u03a1"+
		"\u03a2\u0001\u0000\u0000\u0000\u03a2\u03a3\u0001\u0000\u0000\u0000\u03a3"+
		"\u03a4\u0005K\u0000\u0000\u03a4\u03a7\u0003\u00eau\u0000\u03a5\u03a6\u0005"+
		"0\u0000\u0000\u03a6\u03a8\u0003\u00f8|\u0000\u03a7\u03a5\u0001\u0000\u0000"+
		"\u0000\u03a7\u03a8\u0001\u0000\u0000\u0000\u03a8\u0085\u0001\u0000\u0000"+
		"\u0000\u03a9\u03ac\u0003(\u0014\u0000\u03aa\u03ac\u0003\u00e8t\u0000\u03ab"+
		"\u03a9\u0001\u0000\u0000\u0000\u03ab\u03aa\u0001\u0000\u0000\u0000\u03ac"+
		"\u03ad\u0001\u0000\u0000\u0000\u03ad\u03af\u0005D\u0000\u0000\u03ae\u03b0"+
		"\u0005V\u0000\u0000\u03af\u03ae\u0001\u0000\u0000\u0000\u03af\u03b0\u0001"+
		"\u0000\u0000\u0000\u03b0\u03b1\u0001\u0000\u0000\u0000\u03b1\u03b2\u0005"+
		"W\u0000\u0000\u03b2\u0087\u0001\u0000\u0000\u0000\u03b3\u03b4\u00038\u001c"+
		"\u0000\u03b4\u03b6\u0005D\u0000\u0000\u03b5\u03b7\u0005V\u0000\u0000\u03b6"+
		"\u03b5\u0001\u0000\u0000\u0000\u03b6\u03b7\u0001\u0000\u0000\u0000\u03b7"+
		"\u03b8\u0001\u0000\u0000\u0000\u03b8\u03b9\u0005.\u0000\u0000\u03b9\u0089"+
		"\u0001\u0000\u0000\u0000\u03ba\u03bc\u0003\u008cF\u0000\u03bb\u03bd\u0005"+
		"V\u0000\u0000\u03bc\u03bb\u0001\u0000\u0000\u0000\u03bc\u03bd\u0001\u0000"+
		"\u0000\u0000\u03bd\u03be\u0001\u0000\u0000\u0000\u03be\u03c0\u0005R\u0000"+
		"\u0000\u03bf\u03c1\u0005[\u0000\u0000\u03c0\u03bf\u0001\u0000\u0000\u0000"+
		"\u03c0\u03c1\u0001\u0000\u0000\u0000\u03c1\u03c2\u0001\u0000\u0000\u0000"+
		"\u03c2\u03c3\u00038\u001c\u0000\u03c3\u008b\u0001\u0000\u0000\u0000\u03c4"+
		"\u03c9\u00036\u001b\u0000\u03c5\u03c9\u00032\u0019\u0000\u03c6\u03c9\u0003"+
		"&\u0013\u0000\u03c7\u03c9\u0003\u008eG\u0000\u03c8\u03c4\u0001\u0000\u0000"+
		"\u0000\u03c8\u03c5\u0001\u0000\u0000\u0000\u03c8\u03c6\u0001\u0000\u0000"+
		"\u0000\u03c8\u03c7\u0001\u0000\u0000\u0000\u03c9\u008d\u0001\u0000\u0000"+
		"\u0000\u03ca\u03ce\u0003\u00e2q\u0000\u03cb\u03ce\u0003\u00e8t\u0000\u03cc"+
		"\u03ce\u0003\u00e6s\u0000\u03cd\u03ca\u0001\u0000\u0000\u0000\u03cd\u03cb"+
		"\u0001\u0000\u0000\u0000\u03cd\u03cc\u0001\u0000\u0000\u0000\u03ce\u008f"+
		"\u0001\u0000\u0000\u0000\u03cf\u03d1\u0005V\u0000\u0000\u03d0\u03cf\u0001"+
		"\u0000\u0000\u0000\u03d0\u03d1\u0001\u0000\u0000\u0000\u03d1\u03d2\u0001"+
		"\u0000\u0000\u0000\u03d2\u03d3\u00052\u0000\u0000\u03d3\u03d4\u0005\u0002"+
		"\u0000\u0000\u03d4\u03d5\u0003^/\u0000\u03d5\u03d6\u0005\u0003\u0000\u0000"+
		"\u03d6\u0091\u0001\u0000\u0000\u0000\u03d7\u03d8\u0007\u0003\u0000\u0000"+
		"\u03d8\u03d9\u0005\u0002\u0000\u0000\u03d9\u03da\u0003^/\u0000\u03da\u03db"+
		"\u0005\u0003\u0000\u0000\u03db\u0093\u0001\u0000\u0000\u0000\u03dc\u03dd"+
		"\u0003\u00a0P\u0000\u03dd\u03e0\u0003\u0096K\u0000\u03de\u03e1\u0003\u00a0"+
		"P\u0000\u03df\u03e1\u0003\u0092I\u0000\u03e0\u03de\u0001\u0000\u0000\u0000"+
		"\u03e0\u03df\u0001\u0000\u0000\u0000\u03e1\u040e\u0001\u0000\u0000\u0000"+
		"\u03e2\u03e3\u0003\u00a4R\u0000\u03e3\u03e6\u0007\u0004\u0000\u0000\u03e4"+
		"\u03e7\u0003\u00a4R\u0000\u03e5\u03e7\u0003\u0092I\u0000\u03e6\u03e4\u0001"+
		"\u0000\u0000\u0000\u03e6\u03e5\u0001\u0000\u0000\u0000\u03e7\u040e\u0001"+
		"\u0000\u0000\u0000\u03e8\u040e\u0003\u00a4R\u0000\u03e9\u03ea\u0003\u00a6"+
		"S\u0000\u03ea\u03ed\u0007\u0004\u0000\u0000\u03eb\u03ee\u0003\u00a6S\u0000"+
		"\u03ec\u03ee\u0003\u0092I\u0000\u03ed\u03eb\u0001\u0000\u0000\u0000\u03ed"+
		"\u03ec\u0001\u0000\u0000\u0000\u03ee\u040e\u0001\u0000\u0000\u0000\u03ef"+
		"\u03f0\u0003\u00a2Q\u0000\u03f0\u03f3\u0003\u0096K\u0000\u03f1\u03f4\u0003"+
		"\u00a2Q\u0000\u03f2\u03f4\u0003\u0092I\u0000\u03f3\u03f1\u0001\u0000\u0000"+
		"\u0000\u03f3\u03f2\u0001\u0000\u0000\u0000\u03f4\u040e\u0001\u0000\u0000"+
		"\u0000\u03f5\u03f6\u0003\u00a8T\u0000\u03f6\u03f9\u0007\u0004\u0000\u0000"+
		"\u03f7\u03fa\u0003\u00a8T\u0000\u03f8\u03fa\u0003\u0092I\u0000\u03f9\u03f7"+
		"\u0001\u0000\u0000\u0000\u03f9\u03f8\u0001\u0000\u0000\u0000\u03fa\u040e"+
		"\u0001\u0000\u0000\u0000\u03fb\u03fc\u0003\u0098L\u0000\u03fc\u03ff\u0003"+
		"\u0096K\u0000\u03fd\u0400\u0003\u0098L\u0000\u03fe\u0400\u0003\u0092I"+
		"\u0000\u03ff\u03fd\u0001\u0000\u0000\u0000\u03ff\u03fe\u0001\u0000\u0000"+
		"\u0000\u0400\u040e\u0001\u0000\u0000\u0000\u0401\u0402\u0003\u00be_\u0000"+
		"\u0402\u0403\u0007\u0004\u0000\u0000\u0403\u0404\u0003\u00e8t\u0000\u0404"+
		"\u040e\u0001\u0000\u0000\u0000\u0405\u0406\u0003\u00acV\u0000\u0406\u0407"+
		"\u0007\u0004\u0000\u0000\u0407\u0408\u0003\u00acV\u0000\u0408\u040e\u0001"+
		"\u0000\u0000\u0000\u0409\u040a\u0003\u00a0P\u0000\u040a\u040b\u0005a\u0000"+
		"\u0000\u040b\u040c\u0003\u0102\u0081\u0000\u040c\u040e\u0001\u0000\u0000"+
		"\u0000\u040d\u03dc\u0001\u0000\u0000\u0000\u040d\u03e2\u0001\u0000\u0000"+
		"\u0000\u040d\u03e8\u0001\u0000\u0000\u0000\u040d\u03e9\u0001\u0000\u0000"+
		"\u0000\u040d\u03ef\u0001\u0000\u0000\u0000\u040d\u03f5\u0001\u0000\u0000"+
		"\u0000\u040d\u03fb\u0001\u0000\u0000\u0000\u040d\u0401\u0001\u0000\u0000"+
		"\u0000\u040d\u0405\u0001\u0000\u0000\u0000\u040d\u0409\u0001\u0000\u0000"+
		"\u0000\u040e\u0095\u0001\u0000\u0000\u0000\u040f\u0416\u0005|\u0000\u0000"+
		"\u0410\u0416\u0005\u0005\u0000\u0000\u0411\u0416\u0005\u0006\u0000\u0000"+
		"\u0412\u0416\u0005\u0007\u0000\u0000\u0413\u0416\u0005\b\u0000\u0000\u0414"+
		"\u0416\u0005}\u0000\u0000\u0415\u040f\u0001\u0000\u0000\u0000\u0415\u0410"+
		"\u0001\u0000\u0000\u0000\u0415\u0411\u0001\u0000\u0000\u0000\u0415\u0412"+
		"\u0001\u0000\u0000\u0000\u0415\u0413\u0001\u0000\u0000\u0000\u0415\u0414"+
		"\u0001\u0000\u0000\u0000\u0416\u0097\u0001\u0000\u0000\u0000\u0417\u0418"+
		"\u0006L\uffff\uffff\u0000\u0418\u0419\u0003\u009aM\u0000\u0419\u041f\u0001"+
		"\u0000\u0000\u0000\u041a\u041b\n\u0001\u0000\u0000\u041b\u041c\u0007\u0005"+
		"\u0000\u0000\u041c\u041e\u0003\u009aM\u0000\u041d\u041a\u0001\u0000\u0000"+
		"\u0000\u041e\u0421\u0001\u0000\u0000\u0000\u041f\u041d\u0001\u0000\u0000"+
		"\u0000\u041f\u0420\u0001\u0000\u0000\u0000\u0420\u0099\u0001\u0000\u0000"+
		"\u0000\u0421\u041f\u0001\u0000\u0000\u0000\u0422\u0423\u0006M\uffff\uffff"+
		"\u0000\u0423\u0424\u0003\u009cN\u0000\u0424\u042a\u0001\u0000\u0000\u0000"+
		"\u0425\u0426\n\u0001\u0000\u0000\u0426\u0427\u0007\u0006\u0000\u0000\u0427"+
		"\u0429\u0003\u009cN\u0000\u0428\u0425\u0001\u0000\u0000\u0000\u0429\u042c"+
		"\u0001\u0000\u0000\u0000\u042a\u0428\u0001\u0000\u0000\u0000\u042a\u042b"+
		"\u0001\u0000\u0000\u0000\u042b\u009b\u0001\u0000\u0000\u0000\u042c\u042a"+
		"\u0001\u0000\u0000\u0000\u042d\u042f\u0007\u0005\u0000\u0000\u042e\u042d"+
		"\u0001\u0000\u0000\u0000\u042e\u042f\u0001\u0000\u0000\u0000\u042f\u0430"+
		"\u0001\u0000\u0000\u0000\u0430\u0431\u0003\u009eO\u0000\u0431\u009d\u0001"+
		"\u0000\u0000\u0000\u0432\u0443\u00034\u001a\u0000\u0433\u0443\u0003\u00fa"+
		"}\u0000\u0434\u0435\u0005\u0002\u0000\u0000\u0435\u0436\u0003\u0098L\u0000"+
		"\u0436\u0437\u0005\u0003\u0000\u0000\u0437\u0443\u0001\u0000\u0000\u0000"+
		"\u0438\u0443\u0003\u00e8t\u0000\u0439\u0443\u0003\u00b0X\u0000\u043a\u0443"+
		"\u0003L&\u0000\u043b\u0443\u0003\u00d0h\u0000\u043c\u0443\u0003\u00b8"+
		"\\\u0000\u043d\u0443\u0003\u00ba]\u0000\u043e\u043f\u0005\u0002\u0000"+
		"\u0000\u043f\u0440\u0003^/\u0000\u0440\u0441\u0005\u0003\u0000\u0000\u0441"+
		"\u0443\u0001\u0000\u0000\u0000\u0442\u0432\u0001\u0000\u0000\u0000\u0442"+
		"\u0433\u0001\u0000\u0000\u0000\u0442\u0434\u0001\u0000\u0000\u0000\u0442"+
		"\u0438\u0001\u0000\u0000\u0000\u0442\u0439\u0001\u0000\u0000\u0000\u0442"+
		"\u043a\u0001\u0000\u0000\u0000\u0442\u043b\u0001\u0000\u0000\u0000\u0442"+
		"\u043c\u0001\u0000\u0000\u0000\u0442\u043d\u0001\u0000\u0000\u0000\u0442"+
		"\u043e\u0001\u0000\u0000\u0000\u0443\u009f\u0001\u0000\u0000\u0000\u0444"+
		"\u0445\u0006P\uffff\uffff\u0000\u0445\u0452\u00034\u001a\u0000\u0446\u0452"+
		"\u0003\u0102\u0081\u0000\u0447\u0452\u0003\u00e8t\u0000\u0448\u0452\u0003"+
		"\u00b4Z\u0000\u0449\u0452\u0003L&\u0000\u044a\u0452\u0003\u00d0h\u0000"+
		"\u044b\u0452\u0003\u00bc^\u0000\u044c\u0452\u0003\u00ba]\u0000\u044d\u044e"+
		"\u0005\u0002\u0000\u0000\u044e\u044f\u0003^/\u0000\u044f\u0450\u0005\u0003"+
		"\u0000\u0000\u0450\u0452\u0001\u0000\u0000\u0000\u0451\u0444\u0001\u0000"+
		"\u0000\u0000\u0451\u0446\u0001\u0000\u0000\u0000\u0451\u0447\u0001\u0000"+
		"\u0000\u0000\u0451\u0448\u0001\u0000\u0000\u0000\u0451\u0449\u0001\u0000"+
		"\u0000\u0000\u0451\u044a\u0001\u0000\u0000\u0000\u0451\u044b\u0001\u0000"+
		"\u0000\u0000\u0451\u044c\u0001\u0000\u0000\u0000\u0451\u044d\u0001\u0000"+
		"\u0000\u0000\u0452\u0458\u0001\u0000\u0000\u0000\u0453\u0454\n\u0001\u0000"+
		"\u0000\u0454\u0455\u0005\r\u0000\u0000\u0455\u0457\u0003\u00a0P\u0002"+
		"\u0456\u0453\u0001\u0000\u0000\u0000\u0457\u045a\u0001\u0000\u0000\u0000"+
		"\u0458\u0456\u0001\u0000\u0000\u0000\u0458\u0459\u0001\u0000\u0000\u0000"+
		"\u0459\u00a1\u0001\u0000\u0000\u0000\u045a\u0458\u0001\u0000\u0000\u0000"+
		"\u045b\u0466\u00034\u001a\u0000\u045c\u0466\u0003\u00e8t\u0000\u045d\u0466"+
		"\u0003\u00b2Y\u0000\u045e\u0466\u0003L&\u0000\u045f\u0466\u0003\u00d0"+
		"h\u0000\u0460\u0466\u0003\u00ecv\u0000\u0461\u0462\u0005\u0002\u0000\u0000"+
		"\u0462\u0463\u0003^/\u0000\u0463\u0464\u0005\u0003\u0000\u0000\u0464\u0466"+
		"\u0001\u0000\u0000\u0000\u0465\u045b\u0001\u0000\u0000\u0000\u0465\u045c"+
		"\u0001\u0000\u0000\u0000\u0465\u045d\u0001\u0000\u0000\u0000\u0465\u045e"+
		"\u0001\u0000\u0000\u0000\u0465\u045f\u0001\u0000\u0000\u0000\u0465\u0460"+
		"\u0001\u0000\u0000\u0000\u0465\u0461\u0001\u0000\u0000\u0000\u0466\u00a3"+
		"\u0001\u0000\u0000\u0000\u0467\u0471\u00034\u001a\u0000\u0468\u0471\u0003"+
		"\u00fe\u007f\u0000\u0469\u0471\u0003\u00e8t\u0000\u046a\u0471\u0003\u00d0"+
		"h\u0000\u046b\u0471\u0003\u00c4b\u0000\u046c\u046d\u0005\u0002\u0000\u0000"+
		"\u046d\u046e\u0003^/\u0000\u046e\u046f\u0005\u0003\u0000\u0000\u046f\u0471"+
		"\u0001\u0000\u0000\u0000\u0470\u0467\u0001\u0000\u0000\u0000\u0470\u0468"+
		"\u0001\u0000\u0000\u0000\u0470\u0469\u0001\u0000\u0000\u0000\u0470\u046a"+
		"\u0001\u0000\u0000\u0000\u0470\u046b\u0001\u0000\u0000\u0000\u0470\u046c"+
		"\u0001\u0000\u0000\u0000\u0471\u00a5\u0001\u0000\u0000\u0000\u0472\u047b"+
		"\u00034\u001a\u0000\u0473\u047b\u0003\u0100\u0080\u0000\u0474\u047b\u0003"+
		"\u00e8t\u0000\u0475\u047b\u0003\u00d0h\u0000\u0476\u0477\u0005\u0002\u0000"+
		"\u0000\u0477\u0478\u0003^/\u0000\u0478\u0479\u0005\u0003\u0000\u0000\u0479"+
		"\u047b\u0001\u0000\u0000\u0000\u047a\u0472\u0001\u0000\u0000\u0000\u047a"+
		"\u0473\u0001\u0000\u0000\u0000\u047a\u0474\u0001\u0000\u0000\u0000\u047a"+
		"\u0475\u0001\u0000\u0000\u0000\u047a\u0476\u0001\u0000\u0000\u0000\u047b"+
		"\u00a7\u0001\u0000\u0000\u0000\u047c\u047f\u00036\u001b\u0000\u047d\u047f"+
		"\u0003\u00aaU\u0000\u047e\u047c\u0001\u0000\u0000\u0000\u047e\u047d\u0001"+
		"\u0000\u0000\u0000\u047f\u00a9\u0001\u0000\u0000\u0000\u0480\u0483\u0003"+
		"\u00e2q\u0000\u0481\u0483\u0003\u00e8t\u0000\u0482\u0480\u0001\u0000\u0000"+
		"\u0000\u0482\u0481\u0001\u0000\u0000\u0000\u0483\u00ab\u0001\u0000\u0000"+
		"\u0000\u0484\u0488\u0003\u00aeW\u0000\u0485\u0488\u0003\u00f6{\u0000\u0486"+
		"\u0488\u0003\u00e8t\u0000\u0487\u0484\u0001\u0000\u0000\u0000\u0487\u0485"+
		"\u0001\u0000\u0000\u0000\u0487\u0486\u0001\u0000\u0000\u0000\u0488\u00ad"+
		"\u0001\u0000\u0000\u0000\u0489\u048a\u0005t\u0000\u0000\u048a\u048e\u0005"+
		"\u0002\u0000\u0000\u048b\u048f\u0003*\u0015\u0000\u048c\u048f\u00036\u001b"+
		"\u0000\u048d\u048f\u0003\u00e8t\u0000\u048e\u048b\u0001\u0000\u0000\u0000"+
		"\u048e\u048c\u0001\u0000\u0000\u0000\u048e\u048d\u0001\u0000\u0000\u0000"+
		"\u048f\u0490\u0001\u0000\u0000\u0000\u0490\u0491\u0005\u0003\u0000\u0000"+
		"\u0491\u00af\u0001\u0000\u0000\u0000\u0492\u0493\u0005J\u0000\u0000\u0493"+
		"\u0494\u0005\u0002\u0000\u0000\u0494\u0495\u0003\u00a0P\u0000\u0495\u0496"+
		"\u0005\u0003\u0000\u0000\u0496\u04e6\u0001\u0000\u0000\u0000\u0497\u0498"+
		"\u0005N\u0000\u0000\u0498\u0499\u0005\u0002\u0000\u0000\u0499\u049a\u0003"+
		"\u00a0P\u0000\u049a\u049b\u0005\u0001\u0000\u0000\u049b\u049e\u0003\u00a0"+
		"P\u0000\u049c\u049d\u0005\u0001\u0000\u0000\u049d\u049f\u0003\u0098L\u0000"+
		"\u049e\u049c\u0001\u0000\u0000\u0000\u049e\u049f\u0001\u0000\u0000\u0000"+
		"\u049f\u04a0\u0001\u0000\u0000\u0000\u04a0\u04a1\u0005\u0003\u0000\u0000"+
		"\u04a1\u04e6\u0001\u0000\u0000\u0000\u04a2\u04a3\u0005\u0013\u0000\u0000"+
		"\u04a3\u04a4\u0005\u0002\u0000\u0000\u04a4\u04a5\u0003\u0098L\u0000\u04a5"+
		"\u04a6\u0005\u0003\u0000\u0000\u04a6\u04e6\u0001\u0000\u0000\u0000\u04a7"+
		"\u04a8\u0005\u001f\u0000\u0000\u04a8\u04a9\u0005\u0002\u0000\u0000\u04a9"+
		"\u04aa\u0003\u0098L\u0000\u04aa\u04ab\u0005\u0003\u0000\u0000\u04ab\u04e6"+
		"\u0001\u0000\u0000\u0000\u04ac\u04ad\u00053\u0000\u0000\u04ad\u04ae\u0005"+
		"\u0002\u0000\u0000\u04ae\u04af\u0003\u0098L\u0000\u04af\u04b0\u0005\u0003"+
		"\u0000\u0000\u04b0\u04e6\u0001\u0000\u0000\u0000\u04b1\u04b2\u00059\u0000"+
		"\u0000\u04b2\u04b3\u0005\u0002\u0000\u0000\u04b3\u04b4\u0003\u0098L\u0000"+
		"\u04b4\u04b5\u0005\u0003\u0000\u0000\u04b5\u04e6\u0001\u0000\u0000\u0000"+
		"\u04b6\u04b7\u0005L\u0000\u0000\u04b7\u04b8\u0005\u0002\u0000\u0000\u04b8"+
		"\u04b9\u0003\u0098L\u0000\u04b9\u04ba\u0005\u0003\u0000\u0000\u04ba\u04e6"+
		"\u0001\u0000\u0000\u0000\u04bb\u04bc\u0005g\u0000\u0000\u04bc\u04bd\u0005"+
		"\u0002\u0000\u0000\u04bd\u04be\u0003\u0098L\u0000\u04be\u04bf\u0005\u0003"+
		"\u0000\u0000\u04bf\u04e6\u0001\u0000\u0000\u0000\u04c0\u04c1\u0005j\u0000"+
		"\u0000\u04c1\u04c2\u0005\u0002\u0000\u0000\u04c2\u04c3\u0003\u0098L\u0000"+
		"\u04c3\u04c4\u0005\u0003\u0000\u0000\u04c4\u04e6\u0001\u0000\u0000\u0000"+
		"\u04c5\u04c6\u0005T\u0000\u0000\u04c6\u04c7\u0005\u0002\u0000\u0000\u04c7"+
		"\u04c8\u0003\u0098L\u0000\u04c8\u04c9\u0005\u0001\u0000\u0000\u04c9\u04ca"+
		"\u0003\u0098L\u0000\u04ca\u04cb\u0005\u0003\u0000\u0000\u04cb\u04e6\u0001"+
		"\u0000\u0000\u0000\u04cc\u04cd\u0005`\u0000\u0000\u04cd\u04ce\u0005\u0002"+
		"\u0000\u0000\u04ce\u04cf\u0003\u0098L\u0000\u04cf\u04d0\u0005\u0001\u0000"+
		"\u0000\u04d0\u04d1\u0003\u0098L\u0000\u04d1\u04d2\u0005\u0003\u0000\u0000"+
		"\u04d2\u04e6\u0001\u0000\u0000\u0000\u04d3\u04d4\u0005d\u0000\u0000\u04d4"+
		"\u04d5\u0005\u0002\u0000\u0000\u04d5\u04d6\u0003\u0098L\u0000\u04d6\u04d7"+
		"\u0005\u0001\u0000\u0000\u04d7\u04d8\u0003\u0098L\u0000\u04d8\u04d9\u0005"+
		"\u0003\u0000\u0000\u04d9\u04e6\u0001\u0000\u0000\u0000\u04da\u04db\u0005"+
		"h\u0000\u0000\u04db\u04dc\u0005\u0002\u0000\u0000\u04dc\u04dd\u00038\u001c"+
		"\u0000\u04dd\u04de\u0005\u0003\u0000\u0000\u04de\u04e6\u0001\u0000\u0000"+
		"\u0000\u04df\u04e0\u0005@\u0000\u0000\u04e0\u04e1\u0005\u0002\u0000\u0000"+
		"\u04e1\u04e2\u0003\u00e2q\u0000\u04e2\u04e3\u0005\u0003\u0000\u0000\u04e3"+
		"\u04e6\u0001\u0000\u0000\u0000\u04e4\u04e6\u0003\u00c6c\u0000\u04e5\u0492"+
		"\u0001\u0000\u0000\u0000\u04e5\u0497\u0001\u0000\u0000\u0000\u04e5\u04a2"+
		"\u0001\u0000\u0000\u0000\u04e5\u04a7\u0001\u0000\u0000\u0000\u04e5\u04ac"+
		"\u0001\u0000\u0000\u0000\u04e5\u04b1\u0001\u0000\u0000\u0000\u04e5\u04b6"+
		"\u0001\u0000\u0000\u0000\u04e5\u04bb\u0001\u0000\u0000\u0000\u04e5\u04c0"+
		"\u0001\u0000\u0000\u0000\u04e5\u04c5\u0001\u0000\u0000\u0000\u04e5\u04cc"+
		"\u0001\u0000\u0000\u0000\u04e5\u04d3\u0001\u0000\u0000\u0000\u04e5\u04da"+
		"\u0001\u0000\u0000\u0000\u04e5\u04df\u0001\u0000\u0000\u0000\u04e5\u04e4"+
		"\u0001\u0000\u0000\u0000\u04e6\u00b1\u0001\u0000\u0000\u0000\u04e7\u04f2"+
		"\u0005#\u0000\u0000\u04e8\u04f2\u0005$\u0000\u0000\u04e9\u04f2\u0005%"+
		"\u0000\u0000\u04ea\u04eb\u0005M\u0000\u0000\u04eb\u04f2\u0005&\u0000\u0000"+
		"\u04ec\u04ed\u0005M\u0000\u0000\u04ed\u04f2\u0005o\u0000\u0000\u04ee\u04ef"+
		"\u0005M\u0000\u0000\u04ef\u04f2\u0005\'\u0000\u0000\u04f0\u04f2\u0003"+
		"\u00cae\u0000\u04f1\u04e7\u0001\u0000\u0000\u0000\u04f1\u04e8\u0001\u0000"+
		"\u0000\u0000\u04f1\u04e9\u0001\u0000\u0000\u0000\u04f1\u04ea\u0001\u0000"+
		"\u0000\u0000\u04f1\u04ec\u0001\u0000\u0000\u0000\u04f1\u04ee\u0001\u0000"+
		"\u0000\u0000\u04f1\u04f0\u0001\u0000\u0000\u0000\u04f2\u00b3\u0001\u0000"+
		"\u0000\u0000\u04f3\u04f4\u0005!\u0000\u0000\u04f4\u04f5\u0005\u0002\u0000"+
		"\u0000\u04f5\u04f6\u0003\u00a0P\u0000\u04f6\u04f7\u0005\u0001\u0000\u0000"+
		"\u04f7\u04fc\u0003\u00a0P\u0000\u04f8\u04f9\u0005\u0001\u0000\u0000\u04f9"+
		"\u04fb\u0003\u00a0P\u0000\u04fa\u04f8\u0001\u0000\u0000\u0000\u04fb\u04fe"+
		"\u0001\u0000\u0000\u0000\u04fc\u04fa\u0001\u0000\u0000\u0000\u04fc\u04fd"+
		"\u0001\u0000\u0000\u0000\u04fd\u04ff\u0001\u0000\u0000\u0000\u04fe\u04fc"+
		"\u0001\u0000\u0000\u0000\u04ff\u0500\u0005\u0003\u0000\u0000\u0500\u053c"+
		"\u0001\u0000\u0000\u0000\u0501\u0502\u0005l\u0000\u0000\u0502\u0503\u0005"+
		"\u0002\u0000\u0000\u0503\u0504\u0003\u00a0P\u0000\u0504\u0505\u0005\u0001"+
		"\u0000\u0000\u0505\u0508\u0003\u0098L\u0000\u0506\u0507\u0005\u0001\u0000"+
		"\u0000\u0507\u0509\u0003\u0098L\u0000\u0508\u0506\u0001\u0000\u0000\u0000"+
		"\u0508\u0509\u0001\u0000\u0000\u0000\u0509\u050a\u0001\u0000\u0000\u0000"+
		"\u050a\u050b\u0005\u0003\u0000\u0000\u050b\u053c\u0001\u0000\u0000\u0000"+
		"\u050c\u050d\u0005r\u0000\u0000\u050d\u0515\u0005\u0002\u0000\u0000\u050e"+
		"\u0510\u0003\u00b6[\u0000\u050f\u050e\u0001\u0000\u0000\u0000\u050f\u0510"+
		"\u0001\u0000\u0000\u0000\u0510\u0512\u0001\u0000\u0000\u0000\u0511\u0513"+
		"\u0003\u00e0p\u0000\u0512\u0511\u0001\u0000\u0000\u0000\u0512\u0513\u0001"+
		"\u0000\u0000\u0000\u0513\u0514\u0001\u0000\u0000\u0000\u0514\u0516\u0005"+
		":\u0000\u0000\u0515\u050f\u0001\u0000\u0000\u0000\u0515\u0516\u0001\u0000"+
		"\u0000\u0000\u0516\u0517\u0001\u0000\u0000\u0000\u0517\u0518\u0003\u00a0"+
		"P\u0000\u0518\u0519\u0005\u0003\u0000\u0000\u0519\u053c\u0001\u0000\u0000"+
		"\u0000\u051a\u051b\u0005P\u0000\u0000\u051b\u051c\u0005\u0002\u0000\u0000"+
		"\u051c\u051d\u0003\u00a0P\u0000\u051d\u051e\u0005\u0003\u0000\u0000\u051e"+
		"\u053c\u0001\u0000\u0000\u0000\u051f\u0520\u0005w\u0000\u0000\u0520\u0521"+
		"\u0005\u0002\u0000\u0000\u0521\u0522\u0003\u00a0P\u0000\u0522\u0523\u0005"+
		"\u0003\u0000\u0000\u0523\u053c\u0001\u0000\u0000\u0000\u0524\u0525\u0005"+
		"b\u0000\u0000\u0525\u0526\u0005\u0002\u0000\u0000\u0526\u0527\u0003\u00a0"+
		"P\u0000\u0527\u0528\u0005\u0001\u0000\u0000\u0528\u0529\u0003\u00a0P\u0000"+
		"\u0529\u052a\u0005\u0001\u0000\u0000\u052a\u052b\u0003\u00a0P\u0000\u052b"+
		"\u052c\u0005\u0003\u0000\u0000\u052c\u053c\u0001\u0000\u0000\u0000\u052d"+
		"\u052e\u0005I\u0000\u0000\u052e\u052f\u0005\u0002\u0000\u0000\u052f\u0530"+
		"\u0003\u00a0P\u0000\u0530\u0531\u0005\u0001\u0000\u0000\u0531\u0532\u0003"+
		"\u0098L\u0000\u0532\u0533\u0005\u0003\u0000\u0000\u0533\u053c\u0001\u0000"+
		"\u0000\u0000\u0534\u0535\u0005c\u0000\u0000\u0535\u0536\u0005\u0002\u0000"+
		"\u0000\u0536\u0537\u0003\u00a0P\u0000\u0537\u0538\u0005\u0001\u0000\u0000"+
		"\u0538\u0539\u0003\u0098L\u0000\u0539\u053a\u0005\u0003\u0000\u0000\u053a"+
		"\u053c\u0001\u0000\u0000\u0000\u053b\u04f3\u0001\u0000\u0000\u0000\u053b"+
		"\u0501\u0001\u0000\u0000\u0000\u053b\u050c\u0001\u0000\u0000\u0000\u053b"+
		"\u051a\u0001\u0000\u0000\u0000\u053b\u051f\u0001\u0000\u0000\u0000\u053b"+
		"\u0524\u0001\u0000\u0000\u0000\u053b\u052d\u0001\u0000\u0000\u0000\u053b"+
		"\u0534\u0001\u0000\u0000\u0000\u053c\u00b5\u0001\u0000\u0000\u0000\u053d"+
		"\u053e\u0007\u0007\u0000\u0000\u053e\u00b7\u0001\u0000\u0000\u0000\u053f"+
		"\u0540\u0005\u001e\u0000\u0000\u0540\u0541\u0005\u0002\u0000\u0000\u0541"+
		"\u0543\u0003\u00a0P\u0000\u0542\u0544\u0005\u0017\u0000\u0000\u0543\u0542"+
		"\u0001\u0000\u0000\u0000\u0543\u0544\u0001\u0000\u0000\u0000\u0544\u0545"+
		"\u0001\u0000\u0000\u0000\u0545\u0546\u0007\b\u0000\u0000\u0546\u0547\u0005"+
		"\u0003\u0000\u0000\u0547\u00b9\u0001\u0000\u0000\u0000\u0548\u0549\u0005"+
		"\u001e\u0000\u0000\u0549\u054a\u0005\u0002\u0000\u0000\u054a\u054c\u0003"+
		"r9\u0000\u054b\u054d\u0005\u0017\u0000\u0000\u054c\u054b\u0001\u0000\u0000"+
		"\u0000\u054c\u054d\u0001\u0000\u0000\u0000\u054d\u054e\u0001\u0000\u0000"+
		"\u0000\u054e\u055a\u0003\u00e2q\u0000\u054f\u0550\u0005\u0002\u0000\u0000"+
		"\u0550\u0555\u0003\u00fa}\u0000\u0551\u0552\u0005\u0001\u0000\u0000\u0552"+
		"\u0554\u0003\u00fa}\u0000\u0553\u0551\u0001\u0000\u0000\u0000\u0554\u0557"+
		"\u0001\u0000\u0000\u0000\u0555\u0553\u0001\u0000\u0000\u0000\u0555\u0556"+
		"\u0001\u0000\u0000\u0000\u0556\u0558\u0001\u0000\u0000\u0000\u0557\u0555"+
		"\u0001\u0000\u0000\u0000\u0558\u0559\u0005\u0003\u0000\u0000\u0559\u055b"+
		"\u0001\u0000\u0000\u0000\u055a\u054f\u0001\u0000\u0000\u0000\u055a\u055b"+
		"\u0001\u0000\u0000\u0000\u055b\u055c\u0001\u0000\u0000\u0000\u055c\u055d"+
		"\u0005\u0003\u0000\u0000\u055d\u00bb\u0001\u0000\u0000\u0000\u055e\u055f"+
		"\u0005\u001e\u0000\u0000\u055f\u0560\u0005\u0002\u0000\u0000\u0560\u0562"+
		"\u0003r9\u0000\u0561\u0563\u0005\u0017\u0000\u0000\u0562\u0561\u0001\u0000"+
		"\u0000\u0000\u0562\u0563\u0001\u0000\u0000\u0000\u0563\u0564\u0001\u0000"+
		"\u0000\u0000\u0564\u0565\u0005k\u0000\u0000\u0565\u0566\u0005\u0003\u0000"+
		"\u0000\u0566\u00bd\u0001\u0000\u0000\u0000\u0567\u056a\u0003\u00c0`\u0000"+
		"\u0568\u056a\u0003\u00c2a\u0000\u0569\u0567\u0001\u0000\u0000\u0000\u0569"+
		"\u0568\u0001\u0000\u0000\u0000\u056a\u00bf\u0001\u0000\u0000\u0000\u056b"+
		"\u056c\u0005>\u0000\u0000\u056c\u056f\u0005\u0002\u0000\u0000\u056d\u0570"+
		"\u0003*\u0015\u0000\u056e\u0570\u00036\u001b\u0000\u056f\u056d\u0001\u0000"+
		"\u0000\u0000\u056f\u056e\u0001\u0000\u0000\u0000\u0570\u0571\u0001\u0000"+
		"\u0000\u0000\u0571\u0572\u0005\u0003\u0000\u0000\u0572\u00c1\u0001\u0000"+
		"\u0000\u0000\u0573\u0574\u0005y\u0000\u0000\u0574\u0577\u0005\u0002\u0000"+
		"\u0000\u0575\u0578\u0003*\u0015\u0000\u0576\u0578\u00036\u001b\u0000\u0577"+
		"\u0575\u0001\u0000\u0000\u0000\u0577\u0576\u0001\u0000\u0000\u0000\u0578"+
		"\u0579\u0001\u0000\u0000\u0000\u0579\u057a\u0005\u0003\u0000\u0000\u057a"+
		"\u00c3\u0001\u0000\u0000\u0000\u057b\u057c\u0005;\u0000\u0000\u057c\u057d"+
		"\u0005\u0002\u0000\u0000\u057d\u0582\u0003\u011a\u008d\u0000\u057e\u057f"+
		"\u0005\u0001\u0000\u0000\u057f\u0581\u0003\u00ceg\u0000\u0580\u057e\u0001"+
		"\u0000\u0000\u0000\u0581\u0584\u0001\u0000\u0000\u0000\u0582\u0580\u0001"+
		"\u0000\u0000\u0000\u0582\u0583\u0001\u0000\u0000\u0000\u0583\u0585\u0001"+
		"\u0000\u0000\u0000\u0584\u0582\u0001\u0000\u0000\u0000\u0585\u0586\u0005"+
		"\u0003\u0000\u0000\u0586\u00c5\u0001\u0000\u0000\u0000\u0587\u0588\u0005"+
		"4\u0000\u0000\u0588\u0589\u0005\u0002\u0000\u0000\u0589\u058a\u0003\u00c8"+
		"d\u0000\u058a\u058b\u0005:\u0000\u0000\u058b\u058c\u0003\u00a2Q\u0000"+
		"\u058c\u058d\u0005\u0003\u0000\u0000\u058d\u00c7\u0001\u0000\u0000\u0000"+
		"\u058e\u058f\u0003\u00e2q\u0000\u058f\u00c9\u0001\u0000\u0000\u0000\u0590"+
		"\u0591\u00054\u0000\u0000\u0591\u0592\u0005\u0002\u0000\u0000\u0592\u0593"+
		"\u0003\u00ccf\u0000\u0593\u0594\u0005:\u0000\u0000\u0594\u0595\u0003\u00a2"+
		"Q\u0000\u0595\u0596\u0005\u0003\u0000\u0000\u0596\u00cb\u0001\u0000\u0000"+
		"\u0000\u0597\u0598\u0003\u00e2q\u0000\u0598\u00cd\u0001\u0000\u0000\u0000"+
		"\u0599\u059a\u0003p8\u0000\u059a\u00cf\u0001\u0000\u0000\u0000\u059b\u05a0"+
		"\u0003\u00d2i\u0000\u059c\u05a0\u0003\u00d6k\u0000\u059d\u05a0\u0003\u00dc"+
		"n\u0000\u059e\u05a0\u0003\u00deo\u0000\u059f\u059b\u0001\u0000\u0000\u0000"+
		"\u059f\u059c\u0001\u0000\u0000\u0000\u059f\u059d\u0001\u0000\u0000\u0000"+
		"\u059f\u059e\u0001\u0000\u0000\u0000\u05a0\u00d1\u0001\u0000\u0000\u0000"+
		"\u05a1\u05a2\u0005\u001d\u0000\u0000\u05a2\u05a6\u0003\u00d4j\u0000\u05a3"+
		"\u05a5\u0003\u00d4j\u0000\u05a4\u05a3\u0001\u0000\u0000\u0000\u05a5\u05a8"+
		"\u0001\u0000\u0000\u0000\u05a6\u05a4\u0001\u0000\u0000\u0000\u05a6\u05a7"+
		"\u0001\u0000\u0000\u0000\u05a7\u05ab\u0001\u0000\u0000\u0000\u05a8\u05a6"+
		"\u0001\u0000\u0000\u0000\u05a9\u05aa\u0005-\u0000\u0000\u05aa\u05ac\u0003"+
		"r9\u0000\u05ab\u05a9\u0001\u0000\u0000\u0000\u05ab\u05ac\u0001\u0000\u0000"+
		"\u0000\u05ac\u05ad\u0001\u0000\u0000\u0000\u05ad\u05ae\u0005,\u0000\u0000"+
		"\u05ae\u00d3\u0001\u0000\u0000\u0000\u05af\u05b0\u0005z\u0000\u0000\u05b0"+
		"\u05b1\u0003t:\u0000\u05b1\u05b2\u0005n\u0000\u0000\u05b2\u05b3\u0003"+
		"r9\u0000\u05b3\u00d5\u0001\u0000\u0000\u0000\u05b4\u05b5\u0005\u001d\u0000"+
		"\u0000\u05b5\u05b6\u0003\u00d8l\u0000\u05b6\u05ba\u0003\u00dam\u0000\u05b7"+
		"\u05b9\u0003\u00dam\u0000\u05b8\u05b7\u0001\u0000\u0000\u0000\u05b9\u05bc"+
		"\u0001\u0000\u0000\u0000\u05ba\u05b8\u0001\u0000\u0000\u0000\u05ba\u05bb"+
		"\u0001\u0000\u0000\u0000\u05bb\u05bf\u0001\u0000\u0000\u0000\u05bc\u05ba"+
		"\u0001\u0000\u0000\u0000\u05bd\u05be\u0005-\u0000\u0000\u05be\u05c0\u0003"+
		"r9\u0000\u05bf\u05bd\u0001\u0000\u0000\u0000\u05bf\u05c0\u0001\u0000\u0000"+
		"\u0000\u05c0\u05c1\u0001\u0000\u0000\u0000\u05c1\u05c2\u0005,\u0000\u0000"+
		"\u05c2\u00d7\u0001\u0000\u0000\u0000\u05c3\u05c6\u00034\u001a\u0000\u05c4"+
		"\u05c6\u0003\u00aeW\u0000\u05c5\u05c3\u0001\u0000\u0000\u0000\u05c5\u05c4"+
		"\u0001\u0000\u0000\u0000\u05c6\u00d9\u0001\u0000\u0000\u0000\u05c7\u05c8"+
		"\u0005z\u0000\u0000\u05c8\u05c9\u0003r9\u0000\u05c9\u05ca\u0005n\u0000"+
		"\u0000\u05ca\u05cb\u0003r9\u0000\u05cb\u00db\u0001\u0000\u0000\u0000\u05cc"+
		"\u05cd\u0005 \u0000\u0000\u05cd\u05ce\u0005\u0002\u0000\u0000\u05ce\u05d1"+
		"\u0003r9\u0000\u05cf\u05d0\u0005\u0001\u0000\u0000\u05d0\u05d2\u0003r"+
		"9\u0000\u05d1\u05cf\u0001\u0000\u0000\u0000\u05d2\u05d3\u0001\u0000\u0000"+
		"\u0000\u05d3\u05d1\u0001\u0000\u0000\u0000\u05d3\u05d4\u0001\u0000\u0000"+
		"\u0000\u05d4\u05d5\u0001\u0000\u0000\u0000\u05d5\u05d6\u0005\u0003\u0000"+
		"\u0000\u05d6\u00dd\u0001\u0000\u0000\u0000\u05d7\u05d8\u0005X\u0000\u0000"+
		"\u05d8\u05d9\u0005\u0002\u0000\u0000\u05d9\u05da\u0003r9\u0000\u05da\u05db"+
		"\u0005\u0001\u0000\u0000\u05db\u05dc\u0003r9\u0000\u05dc\u05dd\u0005\u0003"+
		"\u0000\u0000\u05dd\u00df\u0001\u0000\u0000\u0000\u05de\u05e1\u0005~\u0000"+
		"\u0000\u05df\u05e1\u0003\u011c\u008e\u0000\u05e0\u05de\u0001\u0000\u0000"+
		"\u0000\u05e0\u05df\u0001\u0000\u0000\u0000\u05e1\u00e1\u0001\u0000\u0000"+
		"\u0000\u05e2\u05e6\u0005\u007f\u0000\u0000\u05e3\u05e6\u0007\t\u0000\u0000"+
		"\u05e4\u05e6\u0003\u00fc~\u0000\u05e5\u05e2\u0001\u0000\u0000\u0000\u05e5"+
		"\u05e3\u0001\u0000\u0000\u0000\u05e5\u05e4\u0001\u0000\u0000\u0000\u05e6"+
		"\u00e3\u0001\u0000\u0000\u0000\u05e7\u05e8\u0003\u0110\u0088\u0000\u05e8"+
		"\u00e5\u0001\u0000\u0000\u0000\u05e9\u05f2\u0005\u0080\u0000\u0000\u05ea"+
		"\u05f2\u0005~\u0000\u0000\u05eb\u05f2\u0005\u0081\u0000\u0000\u05ec\u05f2"+
		"\u0005\u0083\u0000\u0000\u05ed\u05f2\u0005\u0082\u0000\u0000\u05ee\u05f2"+
		"\u0005\u0084\u0000\u0000\u05ef\u05f2\u0003\u00fe\u007f\u0000\u05f0\u05f2"+
		"\u0003\u00f6{\u0000\u05f1\u05e9\u0001\u0000\u0000\u0000\u05f1\u05ea\u0001"+
		"\u0000\u0000\u0000\u05f1\u05eb\u0001\u0000\u0000\u0000\u05f1\u05ec\u0001"+
		"\u0000\u0000\u0000\u05f1\u05ed\u0001\u0000\u0000\u0000\u05f1\u05ee\u0001"+
		"\u0000\u0000\u0000\u05f1\u05ef\u0001\u0000\u0000\u0000\u05f1\u05f0\u0001"+
		"\u0000\u0000\u0000\u05f2\u00e7\u0001\u0000\u0000\u0000\u05f3\u05f4\u0005"+
		"\u000e\u0000\u0000\u05f4\u05f8\u0005\u0083\u0000\u0000\u05f5\u05f6\u0005"+
		"\u000f\u0000\u0000\u05f6\u05f8\u0003\u00e2q\u0000\u05f7\u05f3\u0001\u0000"+
		"\u0000\u0000\u05f7\u05f5\u0001\u0000\u0000\u0000\u05f8\u00e9\u0001\u0000"+
		"\u0000\u0000\u05f9\u05fa\u0003\u00a0P\u0000\u05fa\u00eb\u0001\u0000\u0000"+
		"\u0000\u05fb\u0600\u0005\u0080\u0000\u0000\u05fc\u0600\u0003\u00eew\u0000"+
		"\u05fd\u0600\u0003\u00f0x\u0000\u05fe\u0600\u0003\u00f2y\u0000\u05ff\u05fb"+
		"\u0001\u0000\u0000\u0000\u05ff\u05fc\u0001\u0000\u0000\u0000\u05ff\u05fd"+
		"\u0001\u0000\u0000\u0000\u05ff\u05fe\u0001\u0000\u0000\u0000\u0600\u00ed"+
		"\u0001\u0000\u0000\u0000\u0601\u0602\u0005\u0086\u0000\u0000\u0602\u0603"+
		"\u0003\u00f4z\u0000\u0603\u0604\u0005\u0010\u0000\u0000\u0604\u00ef\u0001"+
		"\u0000\u0000\u0000\u0605\u0606\u0005\u0087\u0000\u0000\u0606\u0607\u0003"+
		"\u00f4z\u0000\u0607\u0608\u0005\u0010\u0000\u0000\u0608\u00f1\u0001\u0000"+
		"\u0000\u0000\u0609\u060a\u0005\u0085\u0000\u0000\u060a\u060b\u0003\u00f4"+
		"z\u0000\u060b\u060c\u0005\u0010\u0000\u0000\u060c\u00f3\u0001\u0000\u0000"+
		"\u0000\u060d\u060e\u0005\u0080\u0000\u0000\u060e\u00f5\u0001\u0000\u0000"+
		"\u0000\u060f\u0610\u0003\u00e2q\u0000\u0610\u00f7\u0001\u0000\u0000\u0000"+
		"\u0611\u0615\u0005~\u0000\u0000\u0612\u0615\u0003\u0102\u0081\u0000\u0613"+
		"\u0615\u0003\u011c\u008e\u0000\u0614\u0611\u0001\u0000\u0000\u0000\u0614"+
		"\u0612\u0001\u0000\u0000\u0000\u0614\u0613\u0001\u0000\u0000\u0000\u0615"+
		"\u00f9\u0001\u0000\u0000\u0000\u0616\u0617\u0007\n\u0000\u0000\u0617\u00fb"+
		"\u0001\u0000\u0000\u0000\u0618\u0619\u0007\u000b\u0000\u0000\u0619\u00fd"+
		"\u0001\u0000\u0000\u0000\u061a\u061b\u0007\f\u0000\u0000\u061b\u00ff\u0001"+
		"\u0000\u0000\u0000\u061c\u061d\u00032\u0019\u0000\u061d\u0101\u0001\u0000"+
		"\u0000\u0000\u061e\u061f\u0007\r\u0000\u0000\u061f\u0103\u0001\u0000\u0000"+
		"\u0000\u0620\u0621\u0003\u00e2q\u0000\u0621\u0105\u0001\u0000\u0000\u0000"+
		"\u0622\u0623\u0003\u00e2q\u0000\u0623\u0107\u0001\u0000\u0000\u0000\u0624"+
		"\u0627\u0003\u00e2q\u0000\u0625\u0627\u0003\u011e\u008f\u0000\u0626\u0624"+
		"\u0001\u0000\u0000\u0000\u0626\u0625\u0001\u0000\u0000\u0000\u0627\u0109"+
		"\u0001\u0000\u0000\u0000\u0628\u062b\u0003\u00e2q\u0000\u0629\u062b\u0003"+
		"\u011e\u008f\u0000\u062a\u0628\u0001\u0000\u0000\u0000\u062a\u0629\u0001"+
		"\u0000\u0000\u0000\u062b\u010b\u0001\u0000\u0000\u0000\u062c\u062f\u0003"+
		"\u00e2q\u0000\u062d\u062f\u0003\u011e\u008f\u0000\u062e\u062c\u0001\u0000"+
		"\u0000\u0000\u062e\u062d\u0001\u0000\u0000\u0000\u062f\u010d\u0001\u0000"+
		"\u0000\u0000\u0630\u0633\u0003\u00e2q\u0000\u0631\u0633\u0003\u011e\u008f"+
		"\u0000\u0632\u0630\u0001\u0000\u0000\u0000\u0632\u0631\u0001\u0000\u0000"+
		"\u0000\u0633\u010f\u0001\u0000\u0000\u0000\u0634\u0639\u0003\u011e\u008f"+
		"\u0000\u0635\u0636\u0005\u0004\u0000\u0000\u0636\u0638\u0003\u011e\u008f"+
		"\u0000\u0637\u0635\u0001\u0000\u0000\u0000\u0638\u063b\u0001\u0000\u0000"+
		"\u0000\u0639\u0637\u0001\u0000\u0000\u0000\u0639\u063a\u0001\u0000\u0000"+
		"\u0000\u063a\u0111\u0001\u0000\u0000\u0000\u063b\u0639\u0001\u0000\u0000"+
		"\u0000\u063c\u063d\u0003\u00e2q\u0000\u063d\u0113\u0001\u0000\u0000\u0000"+
		"\u063e\u063f\u0003\u00e2q\u0000\u063f\u0115\u0001\u0000\u0000\u0000\u0640"+
		"\u0641\u0003\u00e8t\u0000\u0641\u0117\u0001\u0000\u0000\u0000\u0642\u0643"+
		"\u0003\u00e8t\u0000\u0643\u0119\u0001\u0000\u0000\u0000\u0644\u0645\u0003"+
		"\u0102\u0081\u0000\u0645\u011b\u0001\u0000\u0000\u0000\u0646\u0649\u0005"+
		"~\u0000\u0000\u0647\u0649\u0003\u00e8t\u0000\u0648\u0646\u0001\u0000\u0000"+
		"\u0000\u0648\u0647\u0001\u0000\u0000\u0000\u0649\u011d\u0001\u0000\u0000"+
		"\u0000\u064a\u064d\u0005\u007f\u0000\u0000\u064b\u064d\u0007\u000e\u0000"+
		"\u0000\u064c\u064a\u0001\u0000\u0000\u0000\u064c\u064b\u0001\u0000\u0000"+
		"\u0000\u064d\u011f\u0001\u0000\u0000\u0000\u00ac\u0126\u012b\u012e\u0131"+
		"\u0134\u0137\u013b\u013e\u0141\u0144\u0147\u0149\u014d\u0151\u0155\u0157"+
		"\u015e\u0162\u016a\u0173\u0176\u0178\u017d\u017f\u0184\u0187\u018c\u018f"+
		"\u0192\u0198\u019b\u019e\u01a2\u01a5\u01b4\u01b9\u01c0\u01ca\u01cd\u01d5"+
		"\u01e1\u01ed\u01f1\u01f9\u01fc\u0203\u0213\u0220\u0223\u022b\u0231\u0238"+
		"\u023d\u0245\u024b\u024e\u0252\u0259\u025e\u0261\u026d\u0277\u0281\u0286"+
		"\u028e\u0294\u02a0\u02a5\u02b1\u02b6\u02b9\u02bf\u02c7\u02ca\u02cd\u02d4"+
		"\u02d8\u02de\u02e1\u02e6\u02ea\u02f4\u02fc\u02ff\u0306\u0318\u031f\u0327"+
		"\u0331\u033b\u0346\u034a\u0353\u035d\u0361\u036a\u0373\u037a\u037e\u0381"+
		"\u038a\u0394\u039d\u03a1\u03a7\u03ab\u03af\u03b6\u03bc\u03c0\u03c8\u03cd"+
		"\u03d0\u03e0\u03e6\u03ed\u03f3\u03f9\u03ff\u040d\u0415\u041f\u042a\u042e"+
		"\u0442\u0451\u0458\u0465\u0470\u047a\u047e\u0482\u0487\u048e\u049e\u04e5"+
		"\u04f1\u04fc\u0508\u050f\u0512\u0515\u053b\u0543\u054c\u0555\u055a\u0562"+
		"\u0569\u056f\u0577\u0582\u059f\u05a6\u05ab\u05ba\u05bf\u05c5\u05d3\u05e0"+
		"\u05e5\u05f1\u05f7\u05ff\u0614\u0626\u062a\u062e\u0632\u0639\u0648\u064c";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}