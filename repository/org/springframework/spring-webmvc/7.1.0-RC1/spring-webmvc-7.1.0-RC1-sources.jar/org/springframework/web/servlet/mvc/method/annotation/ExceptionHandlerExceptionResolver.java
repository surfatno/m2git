/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.web.servlet.mvc.method.annotation;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jspecify.annotations.Nullable;

import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverters;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.multipart.MultipartHttpMessageConverter;
import org.springframework.ui.ModelMap;
import org.springframework.web.ErrorResponse;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.filter.ServerHttpObservationFilter;
import org.springframework.web.method.ControllerAdviceBean;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.method.annotation.ExceptionHandlerMappingInfo;
import org.springframework.web.method.annotation.ExceptionHandlerMethodResolver;
import org.springframework.web.method.annotation.MapMethodProcessor;
import org.springframework.web.method.annotation.ModelMethodProcessor;
import org.springframework.web.method.annotation.ProblemDetailExceptionHandler;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.HandlerMethodArgumentResolverComposite;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.HandlerMethodReturnValueHandlerComposite;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ErrorResponseViewResolver;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.function.HandlerFunction;
import org.springframework.web.servlet.handler.AbstractHandlerMethodExceptionResolver;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;
import org.springframework.web.servlet.support.RequestContextUtils;
import org.springframework.web.util.DisconnectedClientHelper;

/**
 * An {@link AbstractHandlerMethodExceptionResolver} that resolves exceptions
 * through {@code @ExceptionHandler} methods.
 *
 * <p>Support for custom argument and return value types can be added via
 * {@link #setCustomArgumentResolvers} and {@link #setCustomReturnValueHandlers}.
 * Or alternatively to re-configure all argument and return value types use
 * {@link #setArgumentResolvers} and {@link #setReturnValueHandlers(List)}.
 *
 * <p>As of 7.1, exceptions not handled by any {@code @ExceptionHandler} method
 * can be rendered as RFC 9457 problem details, see
 * {@link #setRenderUnhandledExceptionsAsProblemDetails(boolean)}.
 *
 * @author Rossen Stoyanchev
 * @author Juergen Hoeller
 * @author Sebastien Deleuze
 * @author Brian Clozel
 * @since 3.1
 */
public class ExceptionHandlerExceptionResolver extends AbstractHandlerMethodExceptionResolver
		implements ApplicationContextAware, InitializingBean {

	/**
	 * Log category to use for network failure after a client has gone away.
	 * @see DisconnectedClientHelper
	 */
	private static final String DISCONNECTED_CLIENT_LOG_CATEGORY =
			"org.springframework.web.servlet.mvc.method.annotation.DisconnectedClient";

	private static final DisconnectedClientHelper disconnectedClientHelper =
			new DisconnectedClientHelper(DISCONNECTED_CLIENT_LOG_CATEGORY);


	private @Nullable List<HandlerMethodArgumentResolver> customArgumentResolvers;

	private @Nullable HandlerMethodArgumentResolverComposite argumentResolvers;

	private @Nullable List<HandlerMethodReturnValueHandler> customReturnValueHandlers;

	private @Nullable HandlerMethodReturnValueHandlerComposite returnValueHandlers;

	private final List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();

	private ContentNegotiationManager contentNegotiationManager = new ContentNegotiationManager();

	private final List<Object> responseBodyAdvice = new ArrayList<>();

	private final List<ErrorResponse.Interceptor> errorResponseInterceptors = new ArrayList<>();

	private @Nullable ApplicationContext applicationContext;

	private final Map<Class<?>, ExceptionHandlerMethodResolver> exceptionHandlerCache =
			new ConcurrentHashMap<>(64);

	private final Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> exceptionHandlerAdviceCache =
			new LinkedHashMap<>();

	private boolean renderUnhandledExceptionsAsProblemDetails;

	private @Nullable ErrorResponseViewResolver errorResponseViewResolver;

	private @Nullable ProblemDetailExceptionHandler problemDetailExceptionHandler;

	private @Nullable Method problemDetailHandlerMethod;


	/**
	 * Provide resolvers for custom argument types. Custom resolvers are ordered
	 * after built-in ones. To override the built-in support for argument
	 * resolution use {@link #setArgumentResolvers} instead.
	 */
	public void setCustomArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
		this.customArgumentResolvers = argumentResolvers;
	}

	/**
	 * Return the custom argument resolvers, or {@code null}.
	 */
	public @Nullable List<HandlerMethodArgumentResolver> getCustomArgumentResolvers() {
		return this.customArgumentResolvers;
	}

	/**
	 * Configure the complete list of supported argument types thus overriding
	 * the resolvers that would otherwise be configured by default.
	 */
	public void setArgumentResolvers(@Nullable List<HandlerMethodArgumentResolver> argumentResolvers) {
		if (argumentResolvers == null) {
			this.argumentResolvers = null;
		}
		else {
			this.argumentResolvers = new HandlerMethodArgumentResolverComposite();
			this.argumentResolvers.addResolvers(argumentResolvers);
		}
	}

	/**
	 * Return the configured argument resolvers, or possibly {@code null} if
	 * not initialized yet via {@link #afterPropertiesSet()}.
	 */
	public @Nullable HandlerMethodArgumentResolverComposite getArgumentResolvers() {
		return this.argumentResolvers;
	}

	/**
	 * Provide handlers for custom return value types. Custom handlers are
	 * ordered after built-in ones. To override the built-in support for
	 * return value handling use {@link #setReturnValueHandlers}.
	 */
	public void setCustomReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers) {
		this.customReturnValueHandlers = returnValueHandlers;
	}

	/**
	 * Return the custom return value handlers, or {@code null}.
	 */
	public @Nullable List<HandlerMethodReturnValueHandler> getCustomReturnValueHandlers() {
		return this.customReturnValueHandlers;
	}

	/**
	 * Configure the complete list of supported return value types thus
	 * overriding handlers that would otherwise be configured by default.
	 */
	public void setReturnValueHandlers(@Nullable List<HandlerMethodReturnValueHandler> returnValueHandlers) {
		if (returnValueHandlers == null) {
			this.returnValueHandlers = null;
		}
		else {
			this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite();
			this.returnValueHandlers.addHandlers(returnValueHandlers);
		}
	}

	/**
	 * Return the configured handlers, or possibly {@code null} if not
	 * initialized yet via {@link #afterPropertiesSet()}.
	 */
	public @Nullable HandlerMethodReturnValueHandlerComposite getReturnValueHandlers() {
		return this.returnValueHandlers;
	}

	/**
	 * Set the message body converters to use.
	 * <p>These converters are used to convert from and to HTTP requests and responses.
	 */
	public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters) {
		this.messageConverters.clear();
		this.messageConverters.addAll(messageConverters);
	}

	/**
	 * Return the configured message body converters.
	 */
	public List<HttpMessageConverter<?>> getMessageConverters() {
		return this.messageConverters;
	}

	/**
	 * Set the {@link ContentNegotiationManager} to use to determine requested media types.
	 * If not set, the default constructor is used.
	 */
	public void setContentNegotiationManager(ContentNegotiationManager contentNegotiationManager) {
		this.contentNegotiationManager = contentNegotiationManager;
	}

	/**
	 * Return the configured {@link ContentNegotiationManager}.
	 */
	public ContentNegotiationManager getContentNegotiationManager() {
		return this.contentNegotiationManager;
	}

	/**
	 * Add one or more components to be invoked after the execution of a controller
	 * method annotated with {@code @ResponseBody} or returning {@code ResponseEntity}
	 * but before the body is written to the response with the selected
	 * {@code HttpMessageConverter}.
	 */
	public void setResponseBodyAdvice(@Nullable List<ResponseBodyAdvice<?>> responseBodyAdvice) {
		if (responseBodyAdvice != null) {
			this.responseBodyAdvice.addAll(responseBodyAdvice);
		}
	}

	/**
	 * Configure a list of {@link ErrorResponse.Interceptor}'s to apply when
	 * rendering an RFC 9457 {@link org.springframework.http.ProblemDetail}
	 * error response.
	 * @param interceptors the handlers to use
	 * @since 6.2
	 */
	public void setErrorResponseInterceptors(List<ErrorResponse.Interceptor> interceptors) {
		this.errorResponseInterceptors.clear();
		this.errorResponseInterceptors.addAll(interceptors);
	}

	/**
	 * Return the {@link #setErrorResponseInterceptors(List) configured}
	 * {@link ErrorResponse.Interceptor}'s.
	 * @since 6.2
	 */
	public List<ErrorResponse.Interceptor> getErrorResponseInterceptors() {
		return this.errorResponseInterceptors;
	}

	/**
	 * Whether to render exceptions that are not handled by any
	 * {@code @ExceptionHandler} method as RFC 9457 problem details.
	 * <p>When enabled, a {@link ProblemDetailExceptionHandler} is invoked after
	 * local {@code @ExceptionHandler} methods and those declared in
	 * {@link ControllerAdvice @ControllerAdvice} beans, and also when one of them
	 * rethrows the exception or fails. The resulting problem detail is rendered
	 * like any other {@code @ExceptionHandler} return value, with content
	 * negotiation, {@link ErrorResponse.Interceptor}s and {@code MessageSource}
	 * lookups through the {@code ApplicationContext}.
	 * <p>Exceptions resulting in a 5xx server error are recorded as the error
	 * of the current HTTP server observation, if any.
	 * <p>The problem detail is not rendered if the response is already committed.
	 * <p>By default this is set to {@code false}.
	 * @param renderUnhandledExceptionsAsProblemDetails whether to render
	 * unhandled exceptions as problem details
	 * @since 7.1
	 * @see ProblemDetailExceptionHandler
	 */
	public void setRenderUnhandledExceptionsAsProblemDetails(boolean renderUnhandledExceptionsAsProblemDetails) {
		this.renderUnhandledExceptionsAsProblemDetails = renderUnhandledExceptionsAsProblemDetails;
	}

	/**
	 * Whether exceptions not handled by any {@code @ExceptionHandler} method
	 * are rendered as RFC 9457 problem details.
	 * @since 7.1
	 * @see #setRenderUnhandledExceptionsAsProblemDetails(boolean)
	 */
	public boolean isRenderUnhandledExceptionsAsProblemDetails() {
		return this.renderUnhandledExceptionsAsProblemDetails;
	}

	/**
	 * Configure an {@link ErrorResponseViewResolver} to render problem details
	 * returned by {@code @ExceptionHandler} methods as views, typically HTML
	 * error pages, when the client prefers HTML.
	 * <p>This applies to {@code ProblemDetail}, {@code ErrorResponse} and
	 * {@code ResponseEntity<ProblemDetail>} return values, including problem details
	 * rendered for {@link #setRenderUnhandledExceptionsAsProblemDetails(boolean)
	 * unhandled exceptions}. It is not applied to custom
	 * {@link #setReturnValueHandlers(List) return value handlers}.
	 * <p>By default, this is not set and problem details are always written
	 * with message converters.
	 * @param errorResponseViewResolver the resolver to use
	 * @since 7.1
	 */
	public void setErrorResponseViewResolver(@Nullable ErrorResponseViewResolver errorResponseViewResolver) {
		this.errorResponseViewResolver = errorResponseViewResolver;
	}

	/**
	 * Return the {@link #setErrorResponseViewResolver configured}
	 * {@link ErrorResponseViewResolver}, if any.
	 * @since 7.1
	 */
	public @Nullable ErrorResponseViewResolver getErrorResponseViewResolver() {
		return this.errorResponseViewResolver;
	}

	@Override
	public void setApplicationContext(@Nullable ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public @Nullable ApplicationContext getApplicationContext() {
		return this.applicationContext;
	}


	@Override
	public void afterPropertiesSet() {
		// Do this first, it may add ResponseBodyAdvice beans
		initExceptionHandlerAdviceCache();
		initMessageConverters();
		initProblemDetailExceptionHandler();

		if (this.argumentResolvers == null) {
			List<HandlerMethodArgumentResolver> resolvers = getDefaultArgumentResolvers();
			this.argumentResolvers = new HandlerMethodArgumentResolverComposite().addResolvers(resolvers);
		}
		if (this.returnValueHandlers == null) {
			List<HandlerMethodReturnValueHandler> handlers = getDefaultReturnValueHandlers();
			this.returnValueHandlers = new HandlerMethodReturnValueHandlerComposite().addHandlers(handlers);
		}
	}

	private void initMessageConverters() {
		if (!this.messageConverters.isEmpty()) {
			return;
		}
		this.messageConverters.add(new ByteArrayHttpMessageConverter());
		this.messageConverters.add(new StringHttpMessageConverter());
		this.messageConverters.add(new FormHttpMessageConverter());
		this.messageConverters.add(new MultipartHttpMessageConverter(HttpMessageConverters.forServer()
				.registerDefaults().build()));
	}

	private void initProblemDetailExceptionHandler() {
		if (this.renderUnhandledExceptionsAsProblemDetails) {
			this.problemDetailExceptionHandler = new ProblemDetailExceptionHandler(getApplicationContext());
			this.problemDetailHandlerMethod = new ExceptionHandlerMethodResolver(ProblemDetailExceptionHandler.class)
					.resolveMethodByExceptionType(Exception.class);
		}
		else {
			this.problemDetailExceptionHandler = null;
			this.problemDetailHandlerMethod = null;
		}
	}

	private void initExceptionHandlerAdviceCache() {
		if (getApplicationContext() == null) {
			return;
		}

		List<ControllerAdviceBean> adviceBeans = ControllerAdviceBean.findAnnotatedBeans(getApplicationContext());
		for (ControllerAdviceBean adviceBean : adviceBeans) {
			Class<?> beanType = adviceBean.getBeanType();
			if (beanType == null) {
				throw new IllegalStateException("Unresolvable type for ControllerAdviceBean: " + adviceBean);
			}
			ExceptionHandlerMethodResolver resolver = new ExceptionHandlerMethodResolver(beanType);
			if (resolver.hasExceptionMappings()) {
				this.exceptionHandlerAdviceCache.put(adviceBean, resolver);
			}
			if (ResponseBodyAdvice.class.isAssignableFrom(beanType)) {
				this.responseBodyAdvice.add(adviceBean);
			}
		}

		if (logger.isDebugEnabled()) {
			int handlerSize = this.exceptionHandlerAdviceCache.size();
			int adviceSize = this.responseBodyAdvice.size();
			if (handlerSize == 0 && adviceSize == 0) {
				logger.debug("ControllerAdvice beans: none");
			}
			else {
				logger.debug("ControllerAdvice beans: " +
						handlerSize + " @ExceptionHandler, " + adviceSize + " ResponseBodyAdvice");
			}
		}
	}

	/**
	 * Return an unmodifiable Map with the {@link ControllerAdvice @ControllerAdvice}
	 * beans discovered in the ApplicationContext. The returned map will be empty if
	 * the method is invoked before the bean has been initialized via
	 * {@link #afterPropertiesSet()}.
	 */
	public Map<ControllerAdviceBean, ExceptionHandlerMethodResolver> getExceptionHandlerAdviceCache() {
		return Collections.unmodifiableMap(this.exceptionHandlerAdviceCache);
	}

	/**
	 * Return the list of argument resolvers to use including built-in resolvers
	 * and custom resolvers provided via {@link #setCustomArgumentResolvers}.
	 */
	protected List<HandlerMethodArgumentResolver> getDefaultArgumentResolvers() {
		List<HandlerMethodArgumentResolver> resolvers = new ArrayList<>();

		// Annotation-based argument resolution
		resolvers.add(new SessionAttributeMethodArgumentResolver());
		resolvers.add(new RequestAttributeMethodArgumentResolver());

		// Type-based argument resolution
		resolvers.add(new ServletRequestMethodArgumentResolver());
		resolvers.add(new ServletResponseMethodArgumentResolver());
		resolvers.add(new RedirectAttributesMethodArgumentResolver());
		resolvers.add(new ModelMethodProcessor());

		// Custom arguments
		if (getCustomArgumentResolvers() != null) {
			resolvers.addAll(getCustomArgumentResolvers());
		}

		// Catch-all
		resolvers.add(new PrincipalMethodArgumentResolver());

		return resolvers;
	}

	/**
	 * Return the list of return value handlers to use including built-in and
	 * custom handlers provided via {@link #setReturnValueHandlers}.
	 */
	protected List<HandlerMethodReturnValueHandler> getDefaultReturnValueHandlers() {
		List<HandlerMethodReturnValueHandler> handlers = new ArrayList<>();

		// Single-purpose return value types
		handlers.add(new ModelAndViewMethodReturnValueHandler());
		handlers.add(new ModelMethodProcessor());
		handlers.add(new ViewMethodReturnValueHandler());
		HttpEntityMethodProcessor httpEntityProcessor = new HttpEntityMethodProcessor(
				getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice,
				this.errorResponseInterceptors);
		httpEntityProcessor.setErrorResponseViewResolver(this.errorResponseViewResolver);
		handlers.add(httpEntityProcessor);

		// Annotation-based return value types
		handlers.add(new ServletModelAttributeMethodProcessor(false));
		RequestResponseBodyMethodProcessor responseBodyProcessor = new RequestResponseBodyMethodProcessor(
				getMessageConverters(), this.contentNegotiationManager, this.responseBodyAdvice,
				this.errorResponseInterceptors);
		responseBodyProcessor.setErrorResponseViewResolver(this.errorResponseViewResolver);
		handlers.add(responseBodyProcessor);

		// Multi-purpose return value types
		handlers.add(new ViewNameMethodReturnValueHandler());
		handlers.add(new MapMethodProcessor());

		// Custom return value types
		if (getCustomReturnValueHandlers() != null) {
			handlers.addAll(getCustomReturnValueHandlers());
		}

		// Catch-all
		handlers.add(new ServletModelAttributeMethodProcessor(true));

		return handlers;
	}

	@Override
	protected boolean hasGlobalExceptionHandlers() {
		return (!this.exceptionHandlerAdviceCache.isEmpty() || this.problemDetailExceptionHandler != null);
	}

	@Override
	protected boolean shouldApplyTo(HttpServletRequest request, @Nullable Object handler) {
		if (this.problemDetailExceptionHandler != null && !hasHandlerMappings()) {
			return true;  // render problem details for any handler
		}
		else if ((handler instanceof ResourceHttpRequestHandler || handler instanceof HandlerFunction) &&
				hasGlobalExceptionHandlers() && !hasHandlerMappings()) {
			return true;  // apply to ResourceHttpRequestHandler and HandlerFunction by default
		}
		else {
			return super.shouldApplyTo(request, handler);
		}
	}

	/**
	 * Find an {@code @ExceptionHandler} method and invoke it to handle the raised exception.
	 */
	@Override
	protected @Nullable ModelAndView doResolveHandlerMethodException(HttpServletRequest request,
			HttpServletResponse response, @Nullable HandlerMethod handlerMethod, Exception exception) {

		ServletWebRequest webRequest = new ServletWebRequest(request, response);
		ServletInvocableHandlerMethod exceptionHandlerMethod = getExceptionHandlerMethod(handlerMethod, exception, webRequest);

		if (exceptionHandlerMethod == null) {
			return null;
		}
		return invokeExceptionHandlerMethod(exceptionHandlerMethod, webRequest, handlerMethod, exception);
	}

	private @Nullable ModelAndView invokeExceptionHandlerMethod(ServletInvocableHandlerMethod exceptionHandlerMethod,
			ServletWebRequest webRequest, @Nullable HandlerMethod handlerMethod, Exception exception) {

		HttpServletRequest request = webRequest.getRequest();
		boolean isProblemDetailHandler = isProblemDetailHandlerMethod(exceptionHandlerMethod);

		if (this.argumentResolvers != null) {
			exceptionHandlerMethod.setHandlerMethodArgumentResolvers(this.argumentResolvers);
		}
		if (this.returnValueHandlers != null) {
			exceptionHandlerMethod.setHandlerMethodReturnValueHandlers(this.returnValueHandlers);
		}

		ModelAndViewContainer mavContainer = new ModelAndViewContainer();

		ArrayList<Throwable> exceptions = new ArrayList<>();
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("Using @ExceptionHandler " + exceptionHandlerMethod);
			}
			// Expose causes as provided arguments as well
			Throwable exToExpose = exception;
			while (exToExpose != null) {
				exceptions.add(exToExpose);
				Throwable cause = exToExpose.getCause();
				exToExpose = (cause != exToExpose ? cause : null);
			}
			@Nullable Object[] arguments = new Object[exceptions.size() + 1];
			exceptions.toArray(arguments);  // efficient arraycopy call in ArrayList
			arguments[arguments.length - 1] = handlerMethod;
			exceptionHandlerMethod.invokeAndHandle(webRequest, mavContainer, arguments);
		}
		catch (Throwable invocationEx) {
			if (disconnectedClientHelper.checkAndLogClientDisconnectedException(invocationEx)) {
				if (isProblemDetailHandler) {
					recordServerError(exception, webRequest);
				}
				return new ModelAndView();
			}
			// Any other than the original exception (or a cause) is unintended here,
			// probably an accident (for example, failed assertion or the like).
			if (!exceptions.contains(invocationEx) && logger.isWarnEnabled()) {
				logger.warn("Failure in @ExceptionHandler " + exceptionHandlerMethod, invocationEx);
			}
			if (!isProblemDetailHandler) {
				ServletInvocableHandlerMethod problemDetailHandlerMethod = getProblemDetailHandlerMethod(webRequest);
				if (problemDetailHandlerMethod != null) {
					// Producible media types are those of the handler method that did not handle the exception
					request.removeAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE);
					return invokeExceptionHandlerMethod(problemDetailHandlerMethod, webRequest, handlerMethod, exception);
				}
			}
			// Continue with default processing of the original exception...
			return null;
		}

		if (isProblemDetailHandler) {
			recordServerError(exception, webRequest);
		}

		if (mavContainer.isRequestHandled()) {
			return new ModelAndView();
		}
		else {
			ModelMap model = mavContainer.getModel();
			HttpStatusCode status = mavContainer.getStatus();
			ModelAndView mav = new ModelAndView(mavContainer.getViewName(), model, status);
			mav.setViewName(mavContainer.getViewName());
			if (!mavContainer.isViewReference()) {
				mav.setView((View) mavContainer.getView());
			}
			if (model instanceof RedirectAttributes redirectAttributes) {
				Map<String, ?> flashAttributes = redirectAttributes.getFlashAttributes();
				RequestContextUtils.getOutputFlashMap(request).putAll(flashAttributes);
			}
			return mav;
		}
	}

	private boolean isProblemDetailHandlerMethod(ServletInvocableHandlerMethod handlerMethod) {
		return (this.problemDetailExceptionHandler != null &&
				handlerMethod.getBean() == this.problemDetailExceptionHandler);
	}

	private void recordServerError(Exception exception, ServletWebRequest webRequest) {
		HttpServletResponse response = webRequest.getResponse();
		if (response != null && HttpStatusCode.valueOf(response.getStatus()).is5xxServerError()) {
			ServerHttpObservationFilter.findObservationContext(webRequest.getRequest())
					.ifPresent(context -> context.setError(exception));
		}
	}

	/**
	 * Find an {@code @ExceptionHandler} method for the given exception. The default
	 * implementation searches methods in the class hierarchy of the controller first
	 * and if not found, it continues searching for additional {@code @ExceptionHandler}
	 * methods assuming some {@linkplain ControllerAdvice @ControllerAdvice}
	 * Spring-managed beans were detected. As a last resort, if
	 * {@link #setRenderUnhandledExceptionsAsProblemDetails(boolean) enabled},
	 * a {@link ProblemDetailExceptionHandler} method is returned.
	 * @param handlerMethod the method where the exception was raised (may be {@code null})
	 * @param exception the raised exception
	 * @param webRequest the original web request that resulted in a handler error
	 * @return a method to handle the exception, or {@code null} if none
	 */
	protected @Nullable ServletInvocableHandlerMethod getExceptionHandlerMethod(
			@Nullable HandlerMethod handlerMethod, Exception exception, ServletWebRequest webRequest) {

		List<MediaType> acceptedMediaTypes = List.of(MediaType.ALL);
		try {
			acceptedMediaTypes = this.contentNegotiationManager.resolveMediaTypes(webRequest);
		}
		catch (HttpMediaTypeNotAcceptableException mediaTypeExc) {
			if (logger.isDebugEnabled()) {
				logger.debug("Could not resolve accepted media types for @ExceptionHandler [" + webRequest.getHeader(HttpHeaders.ACCEPT) + "]", mediaTypeExc);
			}
		}

		Class<?> handlerType = null;

		if (handlerMethod != null) {
			// Local exception handler methods on the controller class itself.
			// To be invoked through the proxy, even in case of an interface-based proxy.
			handlerType = handlerMethod.getBeanType();
			ExceptionHandlerMethodResolver resolver = this.exceptionHandlerCache.computeIfAbsent(
					handlerType, ExceptionHandlerMethodResolver::new);

			for (MediaType mediaType : acceptedMediaTypes) {
				ExceptionHandlerMappingInfo mappingInfo = resolver.resolveExceptionMapping(exception, mediaType);
				if (mappingInfo != null) {
					if (!mappingInfo.getProducibleTypes().isEmpty()) {
						webRequest.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, mappingInfo.getProducibleTypes(), RequestAttributes.SCOPE_REQUEST);
					}
					return new ServletInvocableHandlerMethod(handlerMethod.getBean(), mappingInfo.getHandlerMethod(), this.applicationContext);
				}
			}
			// For advice applicability check below (involving base packages, assignable types
			// and annotation presence), use target class instead of interface-based proxy.
			if (Proxy.isProxyClass(handlerType)) {
				handlerType = AopUtils.getTargetClass(handlerMethod.getBean());
			}
		}

		for (Map.Entry<ControllerAdviceBean, ExceptionHandlerMethodResolver> entry : this.exceptionHandlerAdviceCache.entrySet()) {
			ControllerAdviceBean advice = entry.getKey();
			if (advice.isApplicableToBeanType(handlerType)) {
				ExceptionHandlerMethodResolver resolver = entry.getValue();
				for (MediaType mediaType : acceptedMediaTypes) {
					ExceptionHandlerMappingInfo mappingInfo = resolver.resolveExceptionMapping(exception, mediaType);
					if (mappingInfo != null) {
						if (!mappingInfo.getProducibleTypes().isEmpty()) {
							webRequest.setAttribute(HandlerMapping.PRODUCIBLE_MEDIA_TYPES_ATTRIBUTE, mappingInfo.getProducibleTypes(), RequestAttributes.SCOPE_REQUEST);
						}
						return new ServletInvocableHandlerMethod(advice.resolveBean(), mappingInfo.getHandlerMethod(), this.applicationContext);
					}
				}
			}
		}

		return getProblemDetailHandlerMethod(webRequest);
	}

	private @Nullable ServletInvocableHandlerMethod getProblemDetailHandlerMethod(ServletWebRequest webRequest) {
		if (this.problemDetailExceptionHandler == null || this.problemDetailHandlerMethod == null) {
			return null;
		}
		HttpServletResponse response = webRequest.getResponse();
		if (response != null && response.isCommitted()) {
			if (logger.isDebugEnabled()) {
				logger.debug("Response already committed, not rendering a problem detail");
			}
			return null;
		}
		return new ServletInvocableHandlerMethod(
				this.problemDetailExceptionHandler, this.problemDetailHandlerMethod, this.applicationContext);
	}

}
