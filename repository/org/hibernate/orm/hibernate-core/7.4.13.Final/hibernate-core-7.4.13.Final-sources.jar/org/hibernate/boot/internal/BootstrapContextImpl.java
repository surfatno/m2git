/*
 * SPDX-License-Identifier: Apache-2.0
 * Copyright Red Hat Inc. and Hibernate Authors
 */
package org.hibernate.boot.internal;

import org.hibernate.AssertionFailure;
import org.hibernate.boot.CacheRegionDefinition;
import org.hibernate.boot.archive.scan.internal.StandardScanOptions;
import org.hibernate.boot.archive.scan.spi.ScanEnvironment;
import org.hibernate.boot.archive.scan.spi.ScanOptions;
import org.hibernate.boot.archive.scan.spi.Scanner;
import org.hibernate.boot.archive.spi.ArchiveDescriptorFactory;
import org.hibernate.boot.model.convert.spi.ConverterDescriptor;
import org.hibernate.boot.model.relational.AuxiliaryDatabaseObject;
import org.hibernate.boot.models.internal.ClassLoaderServiceLoading;
import org.hibernate.boot.models.internal.ModelsHelper;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;
import org.hibernate.boot.registry.selector.spi.StrategySelector;
import org.hibernate.boot.spi.BootstrapContext;
import org.hibernate.boot.spi.ClassLoaderAccess;
import org.hibernate.boot.spi.MetadataBuildingOptions;
import org.hibernate.cfg.PersistenceSettings;
import org.hibernate.engine.config.spi.ConfigurationService;
import org.hibernate.jpa.internal.MutableJpaComplianceImpl;
import org.hibernate.jpa.spi.MutableJpaCompliance;
import org.hibernate.metamodel.internal.ManagedTypeRepresentationResolverStandard;
import org.hibernate.metamodel.spi.ManagedTypeRepresentationResolver;
import org.hibernate.models.spi.ModelsConfiguration;
import org.hibernate.models.spi.ModelsContext;
import org.hibernate.query.sqm.function.SqmFunctionDescriptor;
import org.hibernate.query.sqm.function.SqmFunctionRegistry;
import org.hibernate.resource.beans.spi.BeanInstanceProducer;
import org.hibernate.resource.beans.spi.ManagedBeanRegistry;
import org.hibernate.type.BasicType;
import org.hibernate.type.descriptor.java.JavaType;
import org.hibernate.type.descriptor.jdbc.JdbcType;
import org.hibernate.type.internal.BasicTypeImpl;
import org.hibernate.type.spi.TypeConfiguration;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static org.hibernate.boot.BootLogging.BOOT_LOGGER;
import static org.hibernate.cfg.PersistenceSettings.SCANNER;
import static org.hibernate.cfg.PersistenceSettings.SCANNER_ARCHIVE_INTERPRETER;

/**
 * @author Andrea Boriero
 */
public class BootstrapContextImpl implements BootstrapContext {

	private final StandardServiceRegistry serviceRegistry;
	private final MetadataBuildingOptions metadataBuildingOptions;

	private final TypeConfiguration typeConfiguration;
	private final SqmFunctionRegistry sqmFunctionRegistry;
	private final MutableJpaCompliance jpaCompliance;

	private final ClassLoaderService classLoaderService;
	private final ClassLoaderAccessImpl classLoaderAccess;
	private final BeanInstanceProducer beanInstanceProducer;
	private final ManagedBeanRegistry managedBeanRegistry;

	private boolean isJpaBootstrap;

	private ScanOptions scanOptions;
	private ScanEnvironment scanEnvironment;
	private Object scannerSetting;
	private ArchiveDescriptorFactory archiveDescriptorFactory;

	private HashMap<String,SqmFunctionDescriptor> sqlFunctionMap;
	private ArrayList<AuxiliaryDatabaseObject> auxiliaryDatabaseObjectList;
	private HashMap<Class<?>, ConverterDescriptor<?,?>> attributeConverterDescriptorMap;
	private ArrayList<CacheRegionDefinition> cacheRegionDefinitions;
	private final ManagedTypeRepresentationResolver representationStrategySelector;
	private final ConfigurationService configurationService;

	private final ModelsContext modelsContext;

	public BootstrapContextImpl(
			StandardServiceRegistry serviceRegistry,
			MetadataBuildingOptions metadataBuildingOptions) {
		this.serviceRegistry = serviceRegistry;
		this.metadataBuildingOptions = metadataBuildingOptions;

		classLoaderService = serviceRegistry.requireService( ClassLoaderService.class );
		classLoaderAccess = new ClassLoaderAccessImpl( classLoaderService );

		final var strategySelector = serviceRegistry.requireService( StrategySelector.class );
		final var configService = serviceRegistry.requireService( ConfigurationService.class );

		jpaCompliance = new MutableJpaComplianceImpl( configService.getSettings() );
		scanOptions = new StandardScanOptions(
				(String) configService.getSettings().get( PersistenceSettings.SCANNER_DISCOVERY ),
				false
		);

		// ScanEnvironment must be set explicitly
		scannerSetting = configService.getSettings().get( SCANNER );
		archiveDescriptorFactory = strategySelector.resolveStrategy(
				ArchiveDescriptorFactory.class,
				configService.getSettings().get( SCANNER_ARCHIVE_INTERPRETER )
		);

		representationStrategySelector = ManagedTypeRepresentationResolverStandard.INSTANCE;

		typeConfiguration = new TypeConfiguration();
		beanInstanceProducer = new TypeBeanInstanceProducer( configService, serviceRegistry );
		sqmFunctionRegistry = new SqmFunctionRegistry();

		managedBeanRegistry = serviceRegistry.requireService( ManagedBeanRegistry.class );
		configurationService = serviceRegistry.requireService( ConfigurationService.class );

		modelsContext = createModelBuildingContext( classLoaderService, configService );
	}

	@Override
	public StandardServiceRegistry getServiceRegistry() {
		return serviceRegistry;
	}

	@Override
	public MutableJpaCompliance getJpaCompliance() {
		return jpaCompliance;
	}

	@Override
	public TypeConfiguration getTypeConfiguration() {
		return typeConfiguration;
	}

	@Override
	public ModelsContext getModelsContext() {
		return modelsContext;
	}

	@Override
	public SqmFunctionRegistry getFunctionRegistry() {
		return sqmFunctionRegistry;
	}

	@Override
	public BeanInstanceProducer getCustomTypeProducer() {
		return beanInstanceProducer;
	}

	@Override
	public MetadataBuildingOptions getMetadataBuildingOptions() {
		return metadataBuildingOptions;
	}

	@Override
	public ClassLoaderService getClassLoaderService() {
		return classLoaderService;
	}

	@Override
	public ManagedBeanRegistry getManagedBeanRegistry() {
		return managedBeanRegistry;
	}

	@Override
	public ConfigurationService getConfigurationService() {
		return configurationService;
	}

	@Override
	public boolean isJpaBootstrap() {
		return isJpaBootstrap;
	}

	@Override
	public void markAsJpaBootstrap() {
		isJpaBootstrap = true;
	}

	@Override
	public ClassLoader getJpaTempClassLoader() {
		return classLoaderAccess.getJpaTempClassLoader();
	}

	@Override
	public ClassLoaderAccess getClassLoaderAccess() {
		return classLoaderAccess;
	}

	@Override
	public ArchiveDescriptorFactory getArchiveDescriptorFactory() {
		return archiveDescriptorFactory;
	}

	@Override
	public ScanOptions getScanOptions() {
		return scanOptions;
	}

	@Override
	public ScanEnvironment getScanEnvironment() {
		return scanEnvironment;
	}

	@Override
	public Object getScanner() {
		return scannerSetting;
	}

	@Override
	public Object getJandexView() {
		return null;
	}

	@Override
	public Map<String, SqmFunctionDescriptor> getSqlFunctions() {
		return sqlFunctionMap == null ? emptyMap() : sqlFunctionMap;
	}

	@Override
	public Collection<AuxiliaryDatabaseObject> getAuxiliaryDatabaseObjectList() {
		return auxiliaryDatabaseObjectList == null ? emptyList() : auxiliaryDatabaseObjectList;
	}

	@Override
	public Collection<ConverterDescriptor<?, ?>> getAttributeConverters() {
		return attributeConverterDescriptorMap != null
				? attributeConverterDescriptorMap.values()
				: emptyList();
	}

	@Override
	public Collection<CacheRegionDefinition> getCacheRegionDefinitions() {
		return cacheRegionDefinitions == null ? emptyList() : cacheRegionDefinitions;
	}

	private final Map<String,BasicType<?>> adHocBasicTypeRegistrations = new HashMap<>();

	@Override
	public void registerAdHocBasicType(BasicType<?> basicType) {
		adHocBasicTypeRegistrations.put( basicType.getName(), basicType );
	}

	@Override
	public <T> BasicType<T> resolveAdHocBasicType(String key) {
		//noinspection unchecked
		return (BasicType<T>) adHocBasicTypeRegistrations.get( key );
	}

	@Override
	public <T> BasicType<T> findAdHocBasicType(JavaType<T> javaType, JdbcType jdbcType) {
		for ( BasicType<?> basicType : adHocBasicTypeRegistrations.values() ) {
			if ( basicType.getClass() == BasicTypeImpl.class
				&& basicType.getJavaTypeDescriptor() == javaType
				&& basicType.getJdbcType() == jdbcType ) {
				//noinspection unchecked
				return (BasicType<T>) basicType;
			}
		}

		return null;
	}

	@Override
	public void release() {
		classLoaderAccess.release();

		scanOptions = null;
		scanEnvironment = null;
		scannerSetting = null;
		archiveDescriptorFactory = null;

		if ( sqlFunctionMap != null ) {
			sqlFunctionMap.clear();
		}

		if ( auxiliaryDatabaseObjectList != null ) {
			auxiliaryDatabaseObjectList.clear();
		}

		if ( attributeConverterDescriptorMap != null ) {
			attributeConverterDescriptorMap.clear();
		}

		if ( cacheRegionDefinitions != null ) {
			cacheRegionDefinitions.clear();
		}
	}

	@Override
	public ManagedTypeRepresentationResolver getRepresentationStrategySelector() {
		return representationStrategySelector;
	}


	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	// Mutations

	public void addAttributeConverterDescriptor(ConverterDescriptor<?,?> descriptor) {
		if ( attributeConverterDescriptorMap == null ) {
			attributeConverterDescriptorMap = new HashMap<>();
		}

		final var attributeConverterClass = descriptor.getAttributeConverterClass();
		final Object old = attributeConverterDescriptorMap.put( attributeConverterClass, descriptor );
		if ( old != null ) {
			throw new AssertionFailure(
					String.format(
							"AttributeConverter class [%s] registered multiple times",
							attributeConverterClass
					)
			);
		}
	}

	void injectJpaTempClassLoader(ClassLoader classLoader) {
		if ( BOOT_LOGGER.isTraceEnabled() && classLoader != getJpaTempClassLoader() ) {
			BOOT_LOGGER.injectingJpaTempClassLoader( classLoader, getJpaTempClassLoader() );
		}
		this.classLoaderAccess.injectTempClassLoader( classLoader );
	}

	void injectScanOptions(ScanOptions scanOptions) {
		if ( scanOptions != this.scanOptions ) {
			BOOT_LOGGER.injectingScanOptions( scanOptions, this.scanOptions );
		}
		this.scanOptions = scanOptions;
	}

	void injectScanEnvironment(ScanEnvironment scanEnvironment) {
		if ( scanEnvironment != this.scanEnvironment ) {
			BOOT_LOGGER.injectingScanEnvironment( scanEnvironment, this.scanEnvironment );
		}
		this.scanEnvironment = scanEnvironment;
	}

	void injectScanner(Scanner scanner) {
		if ( scanner != this.scannerSetting ) {
			BOOT_LOGGER.injectingScanner( scanner, this.scannerSetting );
		}
		this.scannerSetting = scanner;
	}

	void injectArchiveDescriptorFactory(ArchiveDescriptorFactory factory) {
		if ( factory != archiveDescriptorFactory ) {
			BOOT_LOGGER.injectingArchiveDescriptorFactory( factory, archiveDescriptorFactory );
		}
		this.archiveDescriptorFactory = factory;
	}

	public void addSqlFunction(String functionName, SqmFunctionDescriptor function) {
		if ( sqlFunctionMap == null ) {
			sqlFunctionMap = new HashMap<>();
		}
		sqlFunctionMap.put( functionName, function );
	}

	public void addAuxiliaryDatabaseObject(AuxiliaryDatabaseObject auxiliaryDatabaseObject) {
		if ( auxiliaryDatabaseObjectList == null ) {
			auxiliaryDatabaseObjectList = new ArrayList<>();
		}
		auxiliaryDatabaseObjectList.add( auxiliaryDatabaseObject );
	}


	public void addCacheRegionDefinition(CacheRegionDefinition cacheRegionDefinition) {
		if ( cacheRegionDefinitions == null ) {
			cacheRegionDefinitions = new ArrayList<>();
		}
		cacheRegionDefinitions.add( cacheRegionDefinition );
	}

	public static ModelsContext createModelBuildingContext(
			ClassLoaderService classLoaderService,
			ConfigurationService configService) {
		final var classLoading = new ClassLoaderServiceLoading( classLoaderService );
		final var modelsConfiguration = new ModelsConfiguration();
		modelsConfiguration.setClassLoading( classLoading );
		modelsConfiguration.setRegistryPrimer( ModelsHelper::preFillRegistries );
		configService.getSettings().forEach( (key, value) -> {
			if ( key.startsWith( "hibernate.models." ) ) {
				modelsConfiguration.configValue( key, value );
			}
		} );
		return modelsConfiguration.bootstrap();
	}
}
