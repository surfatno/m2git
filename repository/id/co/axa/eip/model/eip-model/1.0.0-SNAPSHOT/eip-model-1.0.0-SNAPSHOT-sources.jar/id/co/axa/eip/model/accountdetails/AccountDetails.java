package id.co.axa.eip.model.accountdetails;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 26, 2021
 * Time: 12:05:12 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class AccountDetails {

	public AccountDetails() {
	}

}
