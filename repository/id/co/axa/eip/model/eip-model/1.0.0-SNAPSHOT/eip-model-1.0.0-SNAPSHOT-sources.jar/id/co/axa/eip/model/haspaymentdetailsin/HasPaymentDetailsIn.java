package id.co.axa.eip.model.haspaymentdetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.accountdetails.AccountDetails;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 26, 2021
 * Time: 12:02:18 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "accountDetails" })
@Component
public class HasPaymentDetailsIn {

	@JsonProperty("accountDetails")
	private AccountDetails accountDetails;
	
	public HasPaymentDetailsIn() {

		
	}
	/**
	 * @param accountDetails
	 */
	public HasPaymentDetailsIn(AccountDetails accountDetails) {
		this.accountDetails = accountDetails;
	}


	@JsonProperty("accountDetails")
	public AccountDetails getAccountDetails() {
		return accountDetails;
	}

	@JsonProperty("accountDetails")
	public void setAccountDetails(AccountDetails accountDetails) {
		this.accountDetails = accountDetails;
	}
	
	
}
