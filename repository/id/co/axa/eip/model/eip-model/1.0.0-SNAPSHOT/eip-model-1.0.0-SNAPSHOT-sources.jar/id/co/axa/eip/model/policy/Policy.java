package id.co.axa.eip.model.policy;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.forlifeunitofexposure.ForLifeUnitofExposure;
import id.co.axa.eip.model.hasaccountdetailsin.HasAccountDetailsIn;
import id.co.axa.eip.model.haslifepolicytransactiondetailsin.HasLifePolicyTransactionDetailsIn;
import id.co.axa.eip.model.haspolicyassessmentdetailsin.HasPolicyAssessmentDetailsIn;
import id.co.axa.eip.model.isassociatedwithlifeinsuranceproduct.IsAssociatedWithLifeInsuranceProduct;

/**
 * Created by Spring Tool Suite.
 * 
 * @author Ade Hidayat 
 * Date: Aug 25, 2021 
 * Time: 11:10:36 AM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "processedDttm","hasLifePolicyTransactionDetailsIn", "policyNO", "hasAccountDetailsIn", "isAssociatedWithLifeInsuranceProduct", "key",
		"forLifeUnitofExposure", "hasPolicyAssessmentDetailsIn" })
@Component
public class Policy {

	@JsonProperty("processedDttm")
	private String processedDttm;

	@JsonProperty("policyNO")
	private String policyNO;

	@JsonProperty("hasAccountDetailsIn")
	private List<HasAccountDetailsIn> hasAccountDetailsIn;

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	private List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct;

	@JsonProperty("key")
	private String key;
	
	@JsonProperty("premiumAMT")
	private String premiumAMT;

	@JsonProperty("forLifeUnitofExposure")
	private List<ForLifeUnitofExposure> forLifeUnitofExposure;

	@JsonProperty("hasPolicyAssessmentDetailsIn")
	private List<HasPolicyAssessmentDetailsIn> hasPolicyAssessmentDetailsIn;
	
	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	private List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn;

	public Policy() {

	}

	/**
	 * @param processedDttm
	 * @param policyNO
	 * @param hasAccountDetailsIn
	 * @param isAssociatedWithLifeInsuranceProduct
	 * @param key
	 * @param premiumAMT
	 * @param forLifeUnitofExposure
	 * @param hasPolicyAssessmentDetailsIn
	 * @param hasLifePolicyTransactionDetailsIn
	 */
	public Policy(String processedDttm, String policyNO, List<HasAccountDetailsIn> hasAccountDetailsIn,
			List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct, String key,
			String premiumAMT, List<ForLifeUnitofExposure> forLifeUnitofExposure,
			List<HasPolicyAssessmentDetailsIn> hasPolicyAssessmentDetailsIn,
			List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn) {
		super();
		this.processedDttm = processedDttm;
		this.policyNO = policyNO;
		this.hasAccountDetailsIn = hasAccountDetailsIn;
		this.isAssociatedWithLifeInsuranceProduct = isAssociatedWithLifeInsuranceProduct;
		this.key = key;
		this.premiumAMT = premiumAMT;
		this.forLifeUnitofExposure = forLifeUnitofExposure;
		this.hasPolicyAssessmentDetailsIn = hasPolicyAssessmentDetailsIn;
		this.hasLifePolicyTransactionDetailsIn = hasLifePolicyTransactionDetailsIn;
	}

	@JsonProperty("policyNO")
	public String getPolicyNO() {
		return policyNO;
	}

	@JsonProperty("policyNO")
	public void setPolicyNO(String policyNO) {
		this.policyNO = policyNO;
	}

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	public List<IsAssociatedWithLifeInsuranceProduct> getIsAssociatedWithLifeInsuranceProduct() {
		return isAssociatedWithLifeInsuranceProduct;
	}

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	public void setIsAssociatedWithLifeInsuranceProduct(
			List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct) {
		this.isAssociatedWithLifeInsuranceProduct = isAssociatedWithLifeInsuranceProduct;
	}

	@JsonProperty("processedDttm")
	public String getProcessedDttm() {
		return processedDttm;
	}

	@JsonProperty("processedDttm")
	public void setProcessedDttm(String processedDttm) {
		this.processedDttm = processedDttm;
	}

	@JsonProperty("hasAccountDetailsIn")
	public List<HasAccountDetailsIn> getHasAccountDetailsIn() {
		return hasAccountDetailsIn;
	}

	@JsonProperty("hasAccountDetailsIn")
	public void setHasAccountDetailsIn(List<HasAccountDetailsIn> hasAccountDetailsIn) {
		this.hasAccountDetailsIn = hasAccountDetailsIn;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	@JsonProperty("forLifeUnitofExposure")
	public List<ForLifeUnitofExposure> getForLifeUnitofExposure() {
		return forLifeUnitofExposure;
	}

	@JsonProperty("forLifeUnitofExposure")
	public void setForLifeUnitofExposure(List<ForLifeUnitofExposure> forLifeUnitofExposure) {
		this.forLifeUnitofExposure = forLifeUnitofExposure;
	}

	@JsonProperty("hasPolicyAssessmentDetailsIn")
	public List<HasPolicyAssessmentDetailsIn> getHasPolicyAssessmentDetailsIn() {
		return hasPolicyAssessmentDetailsIn;
	}

	@JsonProperty("hasPolicyAssessmentDetailsIn")
	public void setHasPolicyAssessmentDetailsIn(List<HasPolicyAssessmentDetailsIn> hasPolicyAssessmentDetailsIn) {
		this.hasPolicyAssessmentDetailsIn = hasPolicyAssessmentDetailsIn;
	}

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	public List<HasLifePolicyTransactionDetailsIn> getHasLifePolicyTransactionDetailsIn() {
		return hasLifePolicyTransactionDetailsIn;
	}

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	public void setHasLifePolicyTransactionDetailsIn(
			List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn) {
		this.hasLifePolicyTransactionDetailsIn = hasLifePolicyTransactionDetailsIn;
	}
	
	@JsonProperty("premiumAMT")
	public String getPremiumAMT() {
		return premiumAMT;
	}
	
	@JsonProperty("premiumAMT")
	public void setPremiumAMT(String premiumAMT) {
		this.premiumAMT = premiumAMT;
	}

}
