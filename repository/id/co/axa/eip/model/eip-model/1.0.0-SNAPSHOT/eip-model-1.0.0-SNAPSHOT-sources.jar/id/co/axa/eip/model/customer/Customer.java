/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.customer;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.canbeindividual.CanBeIndividual;
import id.co.axa.eip.model.hasnamevalue.HasNameValue;
import id.co.axa.eip.model.haspolicyaccount.HasPolicyAccount;
import id.co.axa.eip.model.havecommunicatedmessage.HaveCommunicatedMessage;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "hasPolicyAccount", "haveCommunicatedMessage", "canBeIndividual", "customerRK", "mailableFlg", "numRelations", "customerStatusCD",
		"customerID", "documentID", "dependentNO", "ownerIND", "watchlistInd", "key", "validToDttm", "customerPoiseCd", "relatedPolicy", "sourceCInd" })
@Component("customer")
public class Customer {

	@JsonProperty("hasPolicyAccount")
	private List<HasPolicyAccount>hasPolicyAccount;

	@JsonProperty("canBeIndividual")
	private CanBeIndividual canBeIndividual;

	@JsonProperty("customerID")
	private String customerID;

	@JsonProperty("watchlistInd")
	private String watchlistInd;

	@JsonProperty("documentID")
	private String documentId;

	@JsonProperty("ownerIND")
	private String ownerInd;

	@JsonProperty("dependentNO")
	private String dependentNo;

	@JsonProperty("customerStatusCD")
	private String customerStatusCD;

	@JsonProperty("key")
	private String key;

	@JsonProperty("validToDttm")
	private String validToDttm;

	@JsonProperty("customerPoiseCd")
	private String customerPoiseCd;

	@JsonProperty("customerRK")
	private String customerRK;

	@JsonProperty("mailableFlg")
	private String mailableFlg;

	@JsonProperty("numRelations")
	private String numRelations;

	@JsonProperty("relatedPolicy")
	private String relatedPolicy;

	@JsonProperty("sourceCInd")
	private String sourceCInd;

	@JsonProperty("hasNameValue")
	private List<HasNameValue> hasNameValue;


	public Customer() {

	}

	/**
	 * @param hasPolicyAccount
	 * @param canBeIndividual
	 * @param hasNameValue
	 * @param customerID
	 * @param watchlistInd
	 * @param dependentNo
	 * @param documentId
	 * @param ownerInd
	 * @param customerStatusCD
	 * @param haveCommunicatedMessage
	 */
	public Customer(List<HasPolicyAccount> hasPolicyAccount, CanBeIndividual canBeIndividual, String customerID, String customerStatusCD,
			String dependentNo, String documentId, String ownerInd, String watchlistInd, String key, String validToDttm, String numRelations,
			String customerPoiseCd, String customerRK, String mailableFlg, List<HasNameValue> hasNameValue, List<HaveCommunicatedMessage> haveCommunicatedMessage) {
		this.hasPolicyAccount = hasPolicyAccount;
		this.canBeIndividual = canBeIndividual;
		this.hasNameValue = hasNameValue;
		this.customerID = customerID;
		this.dependentNo = dependentNo;
		this.documentId = documentId;
		this.key = key;
		this.validToDttm = validToDttm;
		this.customerPoiseCd = customerPoiseCd;
		this.mailableFlg = mailableFlg;
		this.numRelations = numRelations;
		this.customerRK = customerRK;
		this.customerStatusCD = customerStatusCD;
		this.watchlistInd = watchlistInd;
		this.ownerInd = ownerInd;
		this.haveCommunicatedMessage = haveCommunicatedMessage;
	}

	@JsonProperty("canBeIndividual")
	public CanBeIndividual getCanBeIndividual() {
		return canBeIndividual;
	}

	@JsonProperty("canBeIndividual")
	public void setCanBeIndividual(CanBeIndividual canBeIndividual) {
		this.canBeIndividual = canBeIndividual;
	}

	@JsonProperty("hasPolicyAccount")
	public List<HasPolicyAccount> getHasPolicyAccount() {
		return hasPolicyAccount;
	}

	@JsonProperty("hasPolicyAccount")
	public void setHasPolicyAccount(List<HasPolicyAccount> hasPolicyAccount) {
		this.hasPolicyAccount = hasPolicyAccount;
	}

	@JsonProperty("customerID")
	public String getCustomerID() {
		return customerID;
	}

	@JsonProperty("customerID")
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	@JsonProperty("watchlistInd")
	public String getWatchlistInd() {
		return watchlistInd;
	}

	@JsonProperty("watchlistInd")
	public void setWatchlistInd(String watchlistInd) {
		this.watchlistInd = watchlistInd;
	}

	@JsonProperty("documentID")
	public String getDocumentId() {
		return documentId;
	}

	@JsonProperty("documentID")
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	@JsonProperty("customerStatusCD")
	public String getCustomerStatusCD() {
		return customerStatusCD;
	}

	@JsonProperty("customerStatusCD")
	public void setCustomerStatusCD(String customerStatusCD) {
		this.customerStatusCD = customerStatusCD;
	}

	@JsonProperty("ownerIND")
	public String getOwnerInd() {
		return ownerInd;
	}

	@JsonProperty("ownerIND")
	public void setOwnerInd(String ownerInd) {
		this.ownerInd = ownerInd;
	}

	@JsonProperty("dependentNO")
	public String getDependentNo() {
		return dependentNo;
	}

	@JsonProperty("dependentNO")
	public void setDependentNo(String dependentNo) {
		this.dependentNo = dependentNo;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	@JsonProperty("validToDttm")
	public String getValidToDttm() {
		return validToDttm;
	}

	@JsonProperty("validToDttm")
	public void setValidToDttm(String validToDttm) {
		this.validToDttm = validToDttm;
	}

	@JsonProperty("customerPoiseCd")
	public String getCustomerPoiseCd() {
		return customerPoiseCd;
	}

	@JsonProperty("customerPoiseCd")
	public void setCustomerPoiseCd(String customerPoiseCd) {
		this.customerPoiseCd = customerPoiseCd;
	}

	@JsonProperty("customerRK")
	public String getCustomerRK() {
		return customerRK;
	}

	@JsonProperty("customerRK")
	public void setCustomerRK(String customerRK) {
		this.customerRK = customerRK;
	}

	@JsonProperty("mailableFlg")
	public String getMailableFlg() {
		return mailableFlg;
	}

	@JsonProperty("mailableFlg")
	public void setMailableFlg(String mailableFlg) {
		this.mailableFlg = mailableFlg;
	}

	@JsonProperty("numRelations")
	public String getNumRelations() {
		return numRelations;
	}

	@JsonProperty("numRelations")
	public void setNumRelations(String numRelations) {
		this.numRelations = numRelations;
	}

	public String getRelatedPolicy() {
		return relatedPolicy;
	}

	public void setRelatedPolicy(String relatedPolicy) {
		this.relatedPolicy = relatedPolicy;
	}

	public String getSourceCInd() {
		return sourceCInd;
	}

	public void setSourceCInd(String sourceCInd) {
		this.sourceCInd = sourceCInd;
	}

	@JsonProperty("haveCommunicatedMessage")
	private List<HaveCommunicatedMessage> haveCommunicatedMessage;

	@JsonProperty("haveCommunicatedMessage")
	public List<HaveCommunicatedMessage> getHaveCommunicatedMessage() {
		return haveCommunicatedMessage;
	}

	@JsonProperty("haveCommunicatedMessage")
	public void setHaveCommunicatedMessage(List<HaveCommunicatedMessage> haveCommunicatedMessage) {
		this.haveCommunicatedMessage = haveCommunicatedMessage;
	}

	public Customer withHaveCommunicatedMessage(List<HaveCommunicatedMessage> haveCommunicatedMessage) {
		this.haveCommunicatedMessage = haveCommunicatedMessage;
		return this;
	}

	@JsonProperty("hasNameValue")
	public List<HasNameValue> getHasNameValue() {
		return hasNameValue;
	}

	@JsonProperty("hasNameValue")
	public void setHasNameValue(List<HasNameValue> hasNameValue) {
		this.hasNameValue = hasNameValue;
	}

}
