package id.co.axa.eip.model.hasinvestmentfunddetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 26, 2021
 * Time: 12:36:23 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "totalUnits", "fundAllocation", "guarLifetimeRt", "totalFundAmount", "investmentFundCd",
		"guarInvestmentRt", "unitPrice", "navDt" })
@Component("hasInvestmentFundDetailsIn")
public class HasInvestmentFundDetailsIn {

	@JsonProperty("totalUnits")
	private String totalUnits;

	@JsonProperty("fundAllocation")
	private String fundAllocation;

	@JsonProperty("guarLifetimeRt")
	private String guarLifetimeRt;

	@JsonProperty("totalFundAmount")
	private String totalFundAmount;

	@JsonProperty("investmentFundCd")
	private String investmentFundCd;

	@JsonProperty("guarInvestmentRt")
	private String guarInvestmentRt;

	@JsonProperty("unitPrice")
	private String unitPrice;

	@JsonProperty("navDt")
	private String navDt;

	public HasInvestmentFundDetailsIn() {
		
	}

	/**
	 * @param totalUnits
	 * @param fundAllocation
	 * @param guarLifetimeRt
	 * @param totalFundAmount
	 * @param investmentFundCd
	 * @param guarInvestmentRt
	 * @param unitPrice
	 * @param navDt
	 */
	public HasInvestmentFundDetailsIn(String totalUnits, String fundAllocation, String guarLifetimeRt,
			String totalFundAmount, String investmentFundCd, String guarInvestmentRt, String unitPrice, String navDt) {
		this.totalUnits = totalUnits;
		this.fundAllocation = fundAllocation;
		this.guarLifetimeRt = guarLifetimeRt;
		this.totalFundAmount = totalFundAmount;
		this.investmentFundCd = investmentFundCd;
		this.guarInvestmentRt = guarInvestmentRt;
		this.unitPrice = unitPrice;
		this.navDt = navDt;
	}

	@JsonProperty("totalUnits")
	public String getTotalUnits() {
		return totalUnits;
	}

	@JsonProperty("totalUnits")
	public void setTotalUnits(String totalUnits) {
		this.totalUnits = totalUnits;
	}

	@JsonProperty("fundAllocation")
	public String getFundAllocation() {
		return fundAllocation;
	}

	@JsonProperty("fundAllocation")
	public void setFundAllocation(String fundAllocation) {
		this.fundAllocation = fundAllocation;
	}

	@JsonProperty("guarLifetimeRt")
	public String getGuarLifetimeRt() {
		return guarLifetimeRt;
	}

	@JsonProperty("guarLifetimeRt")
	public void setGuarLifetimeRt(String guarLifetimeRt) {
		this.guarLifetimeRt = guarLifetimeRt;
	}

	@JsonProperty("totalFundAmount")
	public String getTotalFundAmount() {
		return totalFundAmount;
	}

	@JsonProperty("totalFundAmount")
	public void setTotalFundAmount(String totalFundAmount) {
		this.totalFundAmount = totalFundAmount;
	}

	@JsonProperty("investmentFundCd")
	public String getInvestmentFundCd() {
		return investmentFundCd;
	}

	@JsonProperty("investmentFundCd")
	public void setInvestmentFundCd(String investmentFundCd) {
		this.investmentFundCd = investmentFundCd;
	}

	@JsonProperty("guarInvestmentRt")
	public String getGuarInvestmentRt() {
		return guarInvestmentRt;
	}

	@JsonProperty("guarInvestmentRt")
	public void setGuarInvestmentRt(String guarInvestmentRt) {
		this.guarInvestmentRt = guarInvestmentRt;
	}

	@JsonProperty("unitPrice")
	public String getUnitPrice() {
		return unitPrice;
	}

	@JsonProperty("unitPrice")
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	@JsonProperty("navDt")
	public String getNavDt() {
		return navDt;
	}

	@JsonProperty("navDt")
	public void setNavDt(String navDt) {
		this.navDt = navDt;
	}	
	


}
