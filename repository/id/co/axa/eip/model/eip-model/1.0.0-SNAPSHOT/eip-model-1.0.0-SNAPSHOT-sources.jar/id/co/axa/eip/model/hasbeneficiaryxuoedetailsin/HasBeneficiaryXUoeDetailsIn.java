package id.co.axa.eip.model.hasbeneficiaryxuoedetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 26, 2021
 * Time: 12:19:27 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "benefitDistributionPCT", "relationshipToInsuredCD"})
@Component
public class HasBeneficiaryXUoeDetailsIn {

	@JsonProperty("benefitDistributionPCT")
	private String benefitDistributionPCT;
	
	@JsonProperty("relationshipToInsuredCD")
	private String relationshipToInsuredCD;

	public HasBeneficiaryXUoeDetailsIn() {
	}

	/**
	 * @param benefitDistributionPCT
	 * @param relationshipToInsuredCD
	 */
	public HasBeneficiaryXUoeDetailsIn(String benefitDistributionPCT, String relationshipToInsuredCD) {
		super();
		this.benefitDistributionPCT = benefitDistributionPCT;
		this.relationshipToInsuredCD = relationshipToInsuredCD;
	}

	@JsonProperty("benefitDistributionPCT")
	public String getBenefitDistributionPCT() {
		return benefitDistributionPCT;
	}

	@JsonProperty("benefitDistributionPCT")
	public void setBenefitDistributionPCT(String benefitDistributionPCT) {
		this.benefitDistributionPCT = benefitDistributionPCT;
	}

	@JsonProperty("relationshipToInsuredCD")
	public String getRelationshipToInsuredCD() {
		return relationshipToInsuredCD;
	}

	@JsonProperty("relationshipToInsuredCD")
	public void setRelationshipToInsuredCD(String relationshipToInsuredCD) {
		this.relationshipToInsuredCD = relationshipToInsuredCD;
	}
	
	
}
