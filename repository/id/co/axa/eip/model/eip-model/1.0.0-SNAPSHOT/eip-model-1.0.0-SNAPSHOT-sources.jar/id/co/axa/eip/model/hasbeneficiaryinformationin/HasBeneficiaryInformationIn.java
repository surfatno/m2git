package id.co.axa.eip.model.hasbeneficiaryinformationin;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.canbeindividual.CanBeIndividual;
import id.co.axa.eip.model.hasbeneficiaryxuoedetailsin.HasBeneficiaryXUoeDetailsIn;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"canBeIndividual", "hasBeneficiaryXUoeDetailsIn"})
@Component
public class HasBeneficiaryInformationIn {

	@JsonProperty("canBeIndividual")
	private List<CanBeIndividual> canBeIndividual;
	
	@JsonProperty("hasBeneficiaryXUoeDetailsIn")
	private List<HasBeneficiaryXUoeDetailsIn> hasBeneficiaryXUoeDetailsIn;	

	public HasBeneficiaryInformationIn() {
		
	}

	/**
	 * @param canBeIndividual
	 * @param hasBeneficiaryXUoeDetailsIn
	 */
	public HasBeneficiaryInformationIn(List<CanBeIndividual> canBeIndividual,
			List<HasBeneficiaryXUoeDetailsIn> hasBeneficiaryXUoeDetailsIn) {
		this.canBeIndividual = canBeIndividual;
		this.hasBeneficiaryXUoeDetailsIn = hasBeneficiaryXUoeDetailsIn;
	}

	@JsonProperty("canBeIndividual")
	public List<CanBeIndividual> getCanBeIndividual() {
		return canBeIndividual;
	}

	@JsonProperty("canBeIndividual")
	public void setCanBeIndividual(List<CanBeIndividual> canBeIndividual) {
		this.canBeIndividual = canBeIndividual;
	}

	@JsonProperty("hasBeneficiaryXUoeDetailsIn")
	public List<HasBeneficiaryXUoeDetailsIn> getHasBeneficiaryXUoeDetailsIn() {
		return hasBeneficiaryXUoeDetailsIn;
	}

	@JsonProperty("hasBeneficiaryXUoeDetailsIn")
	public void setHasBeneficiaryXUoeDetailsIn(List<HasBeneficiaryXUoeDetailsIn> hasBeneficiaryXUoeDetailsIn) {
		this.hasBeneficiaryXUoeDetailsIn = hasBeneficiaryXUoeDetailsIn;
	}
	
	
}
