/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haspartyaccountdetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "bankName", "cardTokenNumber" })
@Component
public class HasPartyAccountDetailsIn {

	@JsonProperty("accountNo")
	private String accountNo;

	@JsonProperty("bankName")
	private String bankName;

	@JsonProperty("cardTokenNumber")
	private String cardTokenNumber;

	/**
	 * 
	 */
	public HasPartyAccountDetailsIn() {

	}

	/**
	 * @param bankName
	 * @param cardTokenNumber
	 */
	public HasPartyAccountDetailsIn(String bankName, String cardTokenNumber) {
		this.bankName = bankName;
		this.cardTokenNumber = cardTokenNumber;
	}

	@JsonProperty("accountNo")
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	@JsonProperty("bankName")
	public String getBankName() {
		return bankName;
	}

	@JsonProperty("bankName")
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@JsonProperty("cardTokenNumber")
	public String getCardTokenNumber() {
		return cardTokenNumber;
	}

	@JsonProperty("cardTokenNumber")
	public void setCardTokenNumber(String cardTokenNumber) {
		this.cardTokenNumber = cardTokenNumber;
	}

}