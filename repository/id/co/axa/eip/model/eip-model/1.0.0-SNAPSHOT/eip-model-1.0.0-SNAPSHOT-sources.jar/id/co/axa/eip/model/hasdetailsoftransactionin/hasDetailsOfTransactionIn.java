package id.co.axa.eip.model.hasdetailsoftransactionin;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@Component("hasDetailsOfTransactionIn")
public class hasDetailsOfTransactionIn {
    @JsonProperty("claimTransactionStatusCD")
    private String claimTransactionStatusCD;

    @JsonProperty("referenceNo")
    private String referenceNo;

    @JsonProperty("claimTransactionStatusCD")
    public String getClaimTransactionStatusCD() {
        return claimTransactionStatusCD;
    }

    @JsonProperty("claimTransactionStatusCD")
    public void setClaimTransactionStatusCD(String claimTransactionStatusCD) {
        this.claimTransactionStatusCD = claimTransactionStatusCD;
    }

    @JsonProperty("referenceNo")
    public String getReferenceNo() {
        return referenceNo;
    }

    @JsonProperty("referenceNo")
    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }
}
