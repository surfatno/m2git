package id.co.axa.eip.model.isassociatedwithissuer;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@Component
public class isAssociatedWithIssuer {
    @JsonProperty("issuerID")
    private String issuerID;

    @JsonProperty("issuerAppID")
    private String issuerAppID;

    @JsonProperty("issuerRk")
    private String issuerRk;

    @JsonProperty("issuerID")
    public String getIssuerID() {
        return issuerID;
    }

    @JsonProperty("issuerID")
    public void setIssuerID(String issuerID) {
        this.issuerID = issuerID;
    }

    @JsonProperty("issuerAppID")
    public String getIssuerAppID() {
        return issuerAppID;
    }

    @JsonProperty("issuerAppID")
    public void setIssuerAppID(String issuerAppID) {
        this.issuerAppID = issuerAppID;
    }

    @JsonProperty("issuerRk")
    public String getIssuerRk() {
        return issuerRk;
    }

    @JsonProperty("issuerRk")
    public void setIssuerRk(String issuerRk) {
        this.issuerRk = issuerRk;
    }
}
