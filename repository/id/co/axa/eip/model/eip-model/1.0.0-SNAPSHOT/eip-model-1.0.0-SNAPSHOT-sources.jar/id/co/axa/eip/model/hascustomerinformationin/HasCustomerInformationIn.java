package id.co.axa.eip.model.hascustomerinformationin;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author ichwansholihin
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "mailableFlg", "customerID", "customerRK", "customerStatusCD", "customerTypeCD" })
public class HasCustomerInformationIn {

    @JsonProperty("mailableFlg")
    private String mailableFlg;

    @JsonProperty("customerID")
    private String customerId;

    @JsonProperty("customerRK")
    private String customerRK;

    @JsonProperty("customerStatusCD")
    private String customerStatusCD;

    @JsonProperty("customerTypeCD")
    private String customerTypeCD;

    public HasCustomerInformationIn(){}

    /**
     * @param mailableFlg
     * @param customerId
     * @param customerRK
     * @param customerStatusCD
     * @param customerTypeCD
     */
    public HasCustomerInformationIn(String mailableFlg, String customerId, String customerRK, String customerStatusCD, String customerTypeCD) {
        this.mailableFlg = mailableFlg;
        this.customerId = customerId;
        this.customerRK = customerRK;
        this.customerStatusCD = customerStatusCD;
        this.customerTypeCD = customerTypeCD;
    }

    @JsonProperty("mailableFlg")
    public String getMailableFlg() {
        return mailableFlg;
    }

    @JsonProperty("mailableFlg")
    public void setMailableFlg(String mailableFlg) {
        this.mailableFlg = mailableFlg;
    }

    @JsonProperty("customerID")
    public String getCustomerId() {
        return customerId;
    }

    @JsonProperty("customerID")
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @JsonProperty("customerRK")
    public String getCustomerRK() {
        return customerRK;
    }

    @JsonProperty("customerRK")
    public void setCustomerRK(String customerRK) {
        this.customerRK = customerRK;
    }

    @JsonProperty("customerStatusCD")
    public String getCustomerStatusCD() {
        return customerStatusCD;
    }

    @JsonProperty("customerStatusCD")
    public void setCustomerStatusCD(String customerStatusCD) {
        this.customerStatusCD = customerStatusCD;
    }

    @JsonProperty("customerTypeCD")
    public String getCustomerTypeCD() {
        return customerTypeCD;
    }

    @JsonProperty("customerTypeCD")
    public void setCustomerTypeCD(String customerTypeCD) {
        this.customerTypeCD = customerTypeCD;
    }
}
