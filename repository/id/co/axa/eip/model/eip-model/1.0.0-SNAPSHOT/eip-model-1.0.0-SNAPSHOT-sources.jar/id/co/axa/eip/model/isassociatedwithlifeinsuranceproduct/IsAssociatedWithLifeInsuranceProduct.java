/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.isassociatedwithlifeinsuranceproduct;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasplandetailsin.HasPlanDetailsIn;
import id.co.axa.eip.model.haspolicysegmentdetailsin.HasPolicySegmentDetailsIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "planCd", "insuranceProductRk", "hasPolicySegmentDetailsIn", "planNM", "insuranceProductCd",
		"hasPlanDetailsIn", "totalRecordCount", "productCategoryRk", "productTypeCD" })
@Component
public class IsAssociatedWithLifeInsuranceProduct {

	@JsonProperty("planCd")
	private String planCd;

	@JsonProperty("insuranceProductRk")
	private String insuranceProductRk;

	@JsonProperty("productCategoryRk")
	private String productCategoryRk;

	@JsonProperty("hasPolicySegmentDetailsIn")
	private List<HasPolicySegmentDetailsIn> hasPolicySegmentDetailsIn;

	@JsonProperty("hasPlanDetailsIn")
	private List<HasPlanDetailsIn> hasPlanDetailsIn;

	@JsonProperty("productTypeCD")
	private String productTypeCD;

	@JsonProperty("planNM")
	private String planNM;

	@JsonProperty("totalRecordCount")
	private String totalRecordCount;

	@JsonProperty("insuranceProductCd")
	private String insuranceProductCd;

	/** add by ade  2021-08-25
	 * attribute
	 * constructor
	 * getter
	 * setter
	 */
	//-----------------------//
	@JsonProperty("key")
	private String key;

	@JsonProperty("saleEffectiveDt")
	private String saleEffectiveDt;

	@JsonProperty("planTypeCD")
	private String planTypeCD;

	@JsonProperty("planClassCD")
	private String planClassCD;

	@JsonProperty("saleExpirationDt")
	private String saleExpirationDt;
	//-----------------------//

	public IsAssociatedWithLifeInsuranceProduct() {

	}

	/**
	 * @param planCd
	 * @param insuranceProductRk
	 * @param productCategoryRk
	 * @param hasPolicySegmentDetailsIn
	 * @param hasPlanDetailsIn
	 * @param productTypeCD
	 * @param planNM
	 * @param totalRecordCount
	 * @param insuranceProductCd
	 * @param key
	 * @param productTypeCD
	 * @param saleEffectiveDt
	 * @param planTypeCD
	 * @param planClassCD
	 * @param saleExpirationDt
	 */
	public IsAssociatedWithLifeInsuranceProduct(String planCd, String insuranceProductRk, String productCategoryRk,
			List<HasPolicySegmentDetailsIn> hasPolicySegmentDetailsIn, List<HasPlanDetailsIn> hasPlanDetailsIn,
			String planNM, String totalRecordCount, String insuranceProductCd, String key, String productTypeCD,
			String saleEffectiveDt, String planTypeCD, String planClassCD, String saleExpirationDt) {
		super();
		this.planCd = planCd;
		this.insuranceProductRk = insuranceProductRk;
		this.productCategoryRk = productCategoryRk;
		this.productTypeCD = productTypeCD;
		this.hasPolicySegmentDetailsIn = hasPolicySegmentDetailsIn;
		this.hasPlanDetailsIn = hasPlanDetailsIn;
		this.planNM = planNM;
		this.totalRecordCount = totalRecordCount;
		this.insuranceProductCd = insuranceProductCd;
		this.key = key;
		this.productTypeCD = productTypeCD;
		this.saleEffectiveDt = saleEffectiveDt;
		this.planTypeCD = planTypeCD;
		this.planClassCD = planClassCD;
		this.saleExpirationDt = saleExpirationDt;
	}



	@JsonProperty("planCd")
	public String getPlanCd() {
		return planCd;
	}

	@JsonProperty("planCd")
	public void setPlanCd(String planCd) {
		this.planCd = planCd;
	}

	@JsonProperty("insuranceProductRk")
	public String getInsuranceProductRk() {
		return insuranceProductRk;
	}

	@JsonProperty("insuranceProductRk")
	public void setInsuranceProductRk(String insuranceProductRk) {
		this.insuranceProductRk = insuranceProductRk;
	}

	@JsonProperty("productTypeCD")
	public String getProductTypeCD() {
		return productTypeCD;
	}

	@JsonProperty("productTypeCD")
	public void setProductTypeCD(String productTypeCD) {
		this.productTypeCD = productTypeCD;
	}

	@JsonProperty("productCategoryRk")
	public String getProductCategoryRk() {
		return productCategoryRk;
	}

	@JsonProperty("productCategoryRk")
	public void setProductCategoryRk(String productCategoryRk) {
		this.productCategoryRk = productCategoryRk;
	}

	@JsonProperty("hasPolicySegmentDetailsIn")
	public List<HasPolicySegmentDetailsIn> getHasPolicySegmentDetailsIn() {
		return hasPolicySegmentDetailsIn;
	}

	@JsonProperty("hasPolicySegmentDetailsIn")
	public void setHasPolicySegmentDetailsIn(List<HasPolicySegmentDetailsIn> hasPolicySegmentDetailsIn) {
		this.hasPolicySegmentDetailsIn = hasPolicySegmentDetailsIn;
	}

	@JsonProperty("planNM")
	public String getPlanNM() {
		return planNM;
	}

	@JsonProperty("planNM")
	public void setPlanNM(String planNM) {
		this.planNM = planNM;
	}

	@JsonProperty("insuranceProductCd")
	public String getInsuranceProductCd() {
		return insuranceProductCd;
	}

	@JsonProperty("insuranceProductCd")
	public void setInsuranceProductCd(String insuranceProductCd) {
		this.insuranceProductCd = insuranceProductCd;
	}

	@JsonProperty("hasPlanDetailsIn")
	public List<HasPlanDetailsIn> getHasPlanDetailsIn() {
		return hasPlanDetailsIn;
	}

	@JsonProperty("hasPlanDetailsIn")
	public void setHasPlanDetailsIn(List<HasPlanDetailsIn> hasPlanDetailsIn) {
		this.hasPlanDetailsIn = hasPlanDetailsIn;
	}

	@JsonProperty("totalRecordCount")
	public String getTotalRecordCount() {
		return totalRecordCount;
	}

	@JsonProperty("totalRecordCount")
	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	@JsonProperty("saleEffectiveDt")
	public String getSaleEffectiveDt() {
		return saleEffectiveDt;
	}

	@JsonProperty("saleEffectiveDt")
	public void setSaleEffectiveDt(String saleEffectiveDt) {
		this.saleEffectiveDt = saleEffectiveDt;
	}

	@JsonProperty("planTypeCD")
	public String getPlanTypeCD() {
		return planTypeCD;
	}

	@JsonProperty("planTypeCD")
	public void setPlanTypeCD(String planTypeCD) {
		this.planTypeCD = planTypeCD;
	}

	@JsonProperty("planClassCD")
	public String getPlanClassCD() {
		return planClassCD;
	}

	@JsonProperty("planClassCD")
	public void setPlanClassCD(String planClassCD) {
		this.planClassCD = planClassCD;
	}

	@JsonProperty("saleExpirationDt")
	public String getSaleExpirationDt() {
		return saleExpirationDt;
	}

	@JsonProperty("saleExpirationDt")
	public void setSaleExpirationDt(String saleExpirationDt) {
		this.saleExpirationDt = saleExpirationDt;
	}

}
