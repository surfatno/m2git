/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasbilling;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.haspaymenthistorydetail.HasPaymentHistoryDetail;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "transactionReferenceNO", "grossAmount", "enabled_payments", "hasPaymentHistoryDetails",
		"corporateID", "transactionReferenceNO", "save_token_id" })
@Component("hasBilling")
public class HasBilling {

	@JsonProperty("transactionReferenceNO")
	private String transactionReferenceNO;

	@JsonProperty("grossAmount")
	private String grossAmount;

	@JsonProperty("enabled_payments")
	private List<String> enabledPayments;

	private String enabled_payments;

	@JsonProperty("save_token_id")
	private String saveTokenId;

	@JsonProperty("hasPaymentHistoryDetails")
	private List<HasPaymentHistoryDetail> hasPaymentHistoryDetails;

	/**
	 * 
	 */
	public HasBilling() {

	}

	/**
	 * @param transactionReferenceNO
	 * @param grossAmount
	 * @param enabledPayments
	 * @param enabled_payments
	 * @param hasPaymentHistoryDetails
	 */
	public HasBilling(String transactionReferenceNO, String grossAmount, List<String> enabledPayments,
			String enabled_payments, List<HasPaymentHistoryDetail> hasPaymentHistoryDetails) {
		this.transactionReferenceNO = transactionReferenceNO;
		this.grossAmount = grossAmount;
		this.enabledPayments = enabledPayments;
		this.enabled_payments = enabled_payments;
		this.hasPaymentHistoryDetails = hasPaymentHistoryDetails;
	}

	@JsonProperty("transactionReferenceNO")
	public String getTransactionReferenceNO() {
		return transactionReferenceNO;
	}

	@JsonProperty("transactionReferenceNO")
	public void setTransactionReferenceNO(String transactionReferenceNO) {
		this.transactionReferenceNO = transactionReferenceNO;
	}

	@JsonProperty("grossAmount")
	public String getGrossAmount() {
		return grossAmount;
	}

	@JsonProperty("grossAmount")
	public void setGrossAmount(String grossAmount) {
		this.grossAmount = grossAmount;
	}

	@JsonProperty("enabled_payments")
	public List<String> getEnabledPayments() {
		return enabledPayments;
	}

	@JsonProperty("enabled_payments")
	public void setEnabledPayments(List<String> enabledPayments) {
		this.enabledPayments = enabledPayments;
	}

	@JsonProperty("hasPaymentHistoryDetails")
	public List<HasPaymentHistoryDetail> getHasPaymentHistoryDetails() {
		return hasPaymentHistoryDetails;
	}

	@JsonProperty("hasPaymentHistoryDetails")
	public void setHasPaymentHistoryDetails(List<HasPaymentHistoryDetail> hasPaymentHistoryDetails) {
		this.hasPaymentHistoryDetails = hasPaymentHistoryDetails;
	}

	public String getEnabled_payments() {
		return enabled_payments;
	}

	public void setEnabled_payments(String enabled_payments) {
		this.enabled_payments = enabled_payments;
	}

	public String getSaveTokenId() {
		return saveTokenId;
	}

	public void setSaveTokenId(String saveTokenId) {
		this.saveTokenId = saveTokenId;
	}

}
