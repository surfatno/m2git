package id.co.axa.eip.model.forlifeunitofexposure;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasbeneficiaryinformationin.HasBeneficiaryInformationIn;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 26, 2021
 * Time: 12:15:40 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"hasBeneficiaryInformationIn"})
@Component
public class ForLifeUnitofExposure {
	
	@JsonProperty("hasBeneficiaryInformationIn")
	private List<HasBeneficiaryInformationIn> hasBeneficiaryInformationIn;	

	public ForLifeUnitofExposure() {

	}

	/**
	 * @param hasBeneficiaryInformationIn
	 */
	public ForLifeUnitofExposure(List<HasBeneficiaryInformationIn> hasBeneficiaryInformationIn) {
		this.hasBeneficiaryInformationIn = hasBeneficiaryInformationIn;
	}

	@JsonProperty("hasBeneficiaryInformationIn")
	public List<HasBeneficiaryInformationIn> getHasBeneficiaryInformationIn() {
		return hasBeneficiaryInformationIn;
	}

	@JsonProperty("hasBeneficiaryInformationIn")
	public void setHasBeneficiaryInformationIn(List<HasBeneficiaryInformationIn> hasBeneficiaryInformationIn) {
		this.hasBeneficiaryInformationIn = hasBeneficiaryInformationIn;
	}	
	
	

}
