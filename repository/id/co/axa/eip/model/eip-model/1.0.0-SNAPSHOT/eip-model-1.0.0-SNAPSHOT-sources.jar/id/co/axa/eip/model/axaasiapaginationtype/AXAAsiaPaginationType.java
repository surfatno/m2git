package id.co.axa.eip.model.axaasiapaginationtype;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 30, 2021
 * Time: 11:28:04 AM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "rowPerPage", "numberOfRecords","startDateTime", "endDateTime", "startOfRecords"})

@Component
public class AXAAsiaPaginationType {

	@JsonProperty("rowPerPage")
	private String rowPerPage;
	
	@JsonProperty("numberOfRecords")
	private String numberOfRecords;
	
	@JsonProperty("startDateTime")
	private String startDateTime;
	
	@JsonProperty("endDateTime")
	private String endDateTime;

	@JsonProperty("pageNumber")
	private String pageNumber;

	@JsonProperty("startOfRecords")
	private String startOfRecords;

	public AXAAsiaPaginationType() {

	}

	/**
	 * @param rowPerPage
	 * @param numberOfRecords
	 * @param startDateTime
	 * @param endDateTime
	 * @param startOfRecords
	 */
	public AXAAsiaPaginationType(String rowPerPage, String numberOfRecords, String startDateTime, String endDateTime,
			String startOfRecords, String pageNumber) {
		this.rowPerPage = rowPerPage;
		this.numberOfRecords = numberOfRecords;
		this.startDateTime = startDateTime;
		this.endDateTime = endDateTime;
		this.startOfRecords = startOfRecords;
		this.pageNumber = pageNumber;
	}

	@JsonProperty("rowPerPage")
	public String getRowPerPage() {
		return rowPerPage;
	}

	@JsonProperty("rowPerPage")
	public void setRowPerPage(String rowPerPage) {
		this.rowPerPage = rowPerPage;
	}

	@JsonProperty("numberOfRecords")
	public String getNumberOfRecords() {
		return numberOfRecords;
	}

	@JsonProperty("numberOfRecords")
	public void setNumberOfRecords(String numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}

	@JsonProperty("startDateTime")
	public String getStartDateTime() {
		return startDateTime;
	}

	@JsonProperty("startDateTime")
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}

	@JsonProperty("endDateTime")
	public String getEndDateTime() {
		return endDateTime;
	}

	@JsonProperty("endDateTime")
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}

	@JsonProperty("startOfRecords")
	public String getStartOfRecords() {
		return startOfRecords;
	}

	@JsonProperty("startOfRecords")
	public void setStartOfRecords(String startOfRecords) {
		this.startOfRecords = startOfRecords;
	}
	
	
}
