/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasapplicationdetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "applicationDTTM" })
@Component("hasApplicationDetailsIn")
public class HasApplicationDetailsIn {

	@JsonProperty("applicationDTTM")
	private String applicationDTTM;

	public HasApplicationDetailsIn() {

	}

	/**
	 * @param applicationDTTM
	 */
	public HasApplicationDetailsIn(String applicationDTTM) {
		this.applicationDTTM = applicationDTTM;
	}

	@JsonProperty("applicationDTTM")
	public String getApplicationDTTM() {
		return applicationDTTM;
	}

	@JsonProperty("applicationDTTM")
	public void setApplicationDTTM(String applicationDTTM) {
		this.applicationDTTM = applicationDTTM;
	}
}
