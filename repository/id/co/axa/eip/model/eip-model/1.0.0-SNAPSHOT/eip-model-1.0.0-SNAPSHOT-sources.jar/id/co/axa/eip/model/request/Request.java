/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import id.co.axa.eip.model.body.Body;
import id.co.axa.eip.model.header.Header;

import org.springframework.stereotype.Component;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@Component("request")
public class Request {

	@JsonProperty("Header")
	private Header header;
	@JsonProperty("Body")
	private Body body;

	/**
	 * 
	 */
	public Request() {

	}

	/**
	 * @param header
	 * @param body
	 */
	public Request(Header header, Body body) {
		header = header;
		body = body;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header Header) {
		this.header = Header;
	}

	public Request withHeader(Header Header) {
		this.header = Header;
		return this;
	}

	public Body getBody() {
		return body;
	}

	public void setBody(Body Body) {
		this.body = Body;
	}

	public Request withBody(Body Body) {
		this.body = Body;
		return this;
	}

}
