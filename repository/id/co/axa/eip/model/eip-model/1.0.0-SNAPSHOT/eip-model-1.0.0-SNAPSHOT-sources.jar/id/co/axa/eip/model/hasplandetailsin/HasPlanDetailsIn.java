/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasplandetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "premium" })
@Component
public class HasPlanDetailsIn {

	@JsonProperty("premium")
	private String premium;
	
	@JsonProperty("planSI")
	private String planSI;
	
	@JsonProperty("planStatus")
	private String planStatus;

	@JsonProperty("id")
	private String id;

	@JsonProperty("ageMin")
	private String ageMin;

	@JsonProperty("ageMax")
	private String ageMax;

	@JsonProperty("key")
	private String key;

	/**
	 * 
	 */
	public HasPlanDetailsIn() {

	}

	/**
	 * @param premium
	 * @param planSI
	 * @param planStatus
	 */
	public HasPlanDetailsIn(String premium, String planSI, String planStatus) {
		super();
		this.premium = premium;
		this.planSI = planSI;
		this.planStatus = planStatus;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("ageMin")
	public String getAgeMin() {
		return ageMin;
	}

	@JsonProperty("ageMin")
	public void setAgeMin(String ageMin) {
		this.ageMin = ageMin;
	}

	@JsonProperty("ageMax")
	public String getAgeMax() {
		return ageMax;
	}

	@JsonProperty("ageMax")
	public void setAgeMax(String ageMax) {
		this.ageMax = ageMax;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	@JsonProperty("premium")
	public String getPremium() {
		return premium;
	}

	@JsonProperty("premium")
	public void setPremium(String premium) {
		this.premium = premium;
	}

	@JsonProperty("planSI")
	public String getPlanSI() {
		return planSI;
	}

	@JsonProperty("planSI")
	public void setPlanSI(String planSI) {
		this.planSI = planSI;
	}

	@JsonProperty("planStatus")
	public String getPlanStatus() {
		return planStatus;
	}

	@JsonProperty("planStatus")
	public void setPlanStatus(String planStatus) {
		this.planStatus = planStatus;
	}
	
	
	
	

}
