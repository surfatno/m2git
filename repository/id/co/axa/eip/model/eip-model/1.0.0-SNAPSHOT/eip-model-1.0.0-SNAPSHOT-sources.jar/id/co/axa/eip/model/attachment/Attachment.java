package id.co.axa.eip.model.attachment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class Attachment {
  @JsonProperty("content")
  private String content;
  
  @JsonProperty("name")
  private String name;
  
  public Attachment(String content, String name) {
    this.content = content;
    this.name = name;
  }
  
  public Attachment() {}
  
  public String getContent() {
    return this.content;
  }
  
  public void setContent(String content) {
    this.content = content;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
}
