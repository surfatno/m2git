package id.co.axa.eip.model.hasdetailsofclaimin;

import id.co.axa.eip.model.hasdetailsoftransactionin.hasDetailsOfTransactionIn;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

/**
 * Created by Spring Tool Suite.
 * 
 * @author Ade Hidayat 
 * Date: Aug 25, 2021 
 * Time: 10:31:08 AM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "claimOpenDTTM", "claimStatusRk", "claimStatusDesc", "claimReferenceID", "admissionDTTM",
		"claimTypeCd","claimEndAMT","claimApprovalDTTM","dischargeDTTM","letterCD","claimCurrencyCD","key","claimStatusCD", "claimStatusChangeDTTM" })
@Component
public class HasDetailsOfClaimIn {
	@JsonProperty("approverRemark1")
	private String approverRemark1;

	@JsonProperty("claimOpenDTTM")
	private String claimOpenDTTM;

	@JsonProperty("processedDttm")
	private String processedDttm;

	@JsonProperty("claimStatusRk")
	private String claimStatusRk;
	
	@JsonProperty("claimStatusDesc")
	private String claimStatusDesc;
	
	@JsonProperty("claimReferenceID")
	private String claimReferenceID;
	
	@JsonProperty("admissionDTTM")
	private String admissionDTTM;
	
	@JsonProperty("claimTypeCd")
	private String claimTypeCd;
	
	@JsonProperty("claimEndAMT")
	private String claimEndAMT;
	
	@JsonProperty("claimApprovalDTTM")
	private String claimApprovalDTTM;
	
	@JsonProperty("dischargeDTTM")
	private String dischargeDTTM;
	
	@JsonProperty("letterCD")
	private String letterCD;
	
	@JsonProperty("claimCurrencyCD")
	private String claimCurrencyCD;
	
	@JsonProperty("key")
	private String key;
	
	@JsonProperty("claimStatusCD")
	private String claimStatusCD;

	@JsonProperty("claimStatusChangeDTTM")
	private String claimStatusChangeDTTM;

	@JsonProperty("hasDetailsOfTransactionIn")
	private List<hasDetailsOfTransactionIn> hasDetailsOfTransactionIn;
	
	public HasDetailsOfClaimIn() {
	
	}

	/**
	 * @param claimOpenDTTM
	 * @param claimStatusRk
	 * @param claimStatusDesc
	 * @param claimReferenceID
	 * @param admissionDTTM
	 * @param claimTypeCd
	 * @param claimEndAMT
	 * @param claimApprovalDTTM
	 * @param dischargeDTTM
	 * @param letterCD
	 * @param claimCurrencyCD
	 * @param key
	 * @param claimStatusCD
	 * @param approverRemark1
	 * @param processedDttm
	 * @param claimStatusChangeDTTM
	 */
	public HasDetailsOfClaimIn(String claimOpenDTTM, String claimStatusRk, String claimStatusDesc,
			String claimReferenceID, String admissionDTTM, String claimTypeCd, String claimEndAMT,
			String claimApprovalDTTM, String dischargeDTTM, String letterCD, String claimCurrencyCD, String key,
			String claimStatusCD, String approverRemark1, String processedDttm, String claimStatusChangeDTTM) {
		this.claimOpenDTTM = claimOpenDTTM;
		this.claimStatusRk = claimStatusRk;
		this.claimStatusDesc = claimStatusDesc;
		this.claimReferenceID = claimReferenceID;
		this.admissionDTTM = admissionDTTM;
		this.claimTypeCd = claimTypeCd;
		this.claimEndAMT = claimEndAMT;
		this.claimApprovalDTTM = claimApprovalDTTM;
		this.dischargeDTTM = dischargeDTTM;
		this.letterCD = letterCD;
		this.claimCurrencyCD = claimCurrencyCD;
		this.key = key;
		this.claimStatusCD = claimStatusCD;
		this.approverRemark1 = approverRemark1;
		this.processedDttm = processedDttm;
		this.claimStatusChangeDTTM = claimStatusChangeDTTM;
	}

	@JsonProperty("hasDetailsOfTransactionIn")
	public List<hasDetailsOfTransactionIn> getHasDetailsOfTransactionIn() {
		return hasDetailsOfTransactionIn;
	}

	@JsonProperty("hasDetailsOfTransactionIn")
	public void setHasDetailsOfTransactionIn(List<hasDetailsOfTransactionIn> hasDetailsOfTransactionIn) {
		this.hasDetailsOfTransactionIn = hasDetailsOfTransactionIn;
	}

	@JsonProperty("claimOpenDTTM")
	public String getClaimOpenDTTM() {
		return claimOpenDTTM;
	}

	@JsonProperty("claimOpenDTTM")
	public void setClaimOpenDTTM(String claimOpenDTTM) {
		this.claimOpenDTTM = claimOpenDTTM;
	}

	@JsonProperty("claimStatusRk")
	public String getClaimStatusRk() {
		return claimStatusRk;
	}

	@JsonProperty("claimStatusRk")
	public void setClaimStatusRk(String claimStatusRk) {
		this.claimStatusRk = claimStatusRk;
	}

	@JsonProperty("claimStatusDesc")
	public String getClaimStatusDesc() {
		return claimStatusDesc;
	}

	@JsonProperty("claimStatusDesc")
	public void setClaimStatusDesc(String claimStatusDesc) {
		this.claimStatusDesc = claimStatusDesc;
	}

	@JsonProperty("claimReferenceID")
	public String getClaimReferenceID() {
		return claimReferenceID;
	}

	@JsonProperty("claimReferenceID")
	public void setClaimReferenceID(String claimReferenceID) {
		this.claimReferenceID = claimReferenceID;
	}

	@JsonProperty("approverRemark1")
	public void setApproverRemark1(String approverRemark1) {
		this.approverRemark1 = approverRemark1;
	}

	@JsonProperty("processedDttm")
	public void setProcessedDttm(String processedDttm) {
		this.processedDttm = processedDttm;
	}

	@JsonProperty("admissionDTTM")
	public String getAdmissionDTTM() {
		return admissionDTTM;
	}

	@JsonProperty("admissionDTTM")
	public void setAdmissionDTTM(String admissionDTTM) {
		this.admissionDTTM = admissionDTTM;
	}

	@JsonProperty("claimTypeCd")
	public String getClaimTypeCd() {
		return claimTypeCd;
	}

	@JsonProperty("claimTypeCd")
	public void setClaimTypeCd(String claimTypeCd) {
		this.claimTypeCd = claimTypeCd;
	}

	@JsonProperty("claimEndAMT")
	public String getClaimEndAMT() {
		return claimEndAMT;
	}

	@JsonProperty("claimEndAMT")
	public void setClaimEndAMT(String claimEndAMT) {
		this.claimEndAMT = claimEndAMT;
	}

	@JsonProperty("claimApprovalDTTM")
	public String getClaimApprovalDTTM() {
		return claimApprovalDTTM;
	}

	@JsonProperty("claimApprovalDTTM")
	public void setClaimApprovalDTTM(String claimApprovalDTTM) {
		this.claimApprovalDTTM = claimApprovalDTTM;
	}

	@JsonProperty("dischargeDTTM")
	public String getDischargeDTTM() {
		return dischargeDTTM;
	}

	@JsonProperty("dischargeDTTM")
	public void setDischargeDTTM(String dischargeDTTM) {
		this.dischargeDTTM = dischargeDTTM;
	}

	@JsonProperty("letterCD")
	public String getLetterCD() {
		return letterCD;
	}

	@JsonProperty("letterCD")
	public void setLetterCD(String letterCD) {
		this.letterCD = letterCD;
	}

	@JsonProperty("claimCurrencyCD")
	public String getClaimCurrencyCD() {
		return claimCurrencyCD;
	}

	@JsonProperty("claimCurrencyCD")
	public void setClaimCurrencyCD(String claimCurrencyCD) {
		this.claimCurrencyCD = claimCurrencyCD;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	@JsonProperty("claimStatusCD")
	public String getClaimStatusCD() {
		return claimStatusCD;
	}

	@JsonProperty("claimStatusCD")
	public void setClaimStatusCD(String claimStatusCD) {
		this.claimStatusCD = claimStatusCD;
	}

	@JsonProperty("approverRemark1")
	public String getApproverRemark1() {return approverRemark1;}

	@JsonProperty("processedDttm")
	public String getProcessedDttm() {
		return processedDttm;
	}

	@JsonProperty("claimStatusChangeDTTM")
	public void setClaimStatusChangeDTTM(String claimStatusChangeDTTM) {
		this.claimStatusChangeDTTM = claimStatusChangeDTTM;
	}

	@JsonProperty("claimStatusChangeDTTM")
	public String getClaimStatusChangeDTTM() {return claimStatusChangeDTTM;}

}
