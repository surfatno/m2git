/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasaddressesin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "emailAddress", "mobilePhoneNO", "addressLine1", "addressLine2", "addressLine3", "addressLine4" })
@Component
public class HasAddressesIn {

	@JsonProperty("emailAddress")
	private String emailAddress;

	@JsonProperty("mobilePhoneNO")
	private String mobilePhoneNO;

	@JsonProperty("addressLine1")
	private String addressLine1;

	@JsonProperty("addressLine2")
	private String addressLine2;

	@JsonProperty("addressLine3")
	private String addressLine3;

	@JsonProperty("addressLine4")
	private String addressLine4;

	@JsonProperty("postalCD")
	private String postalCD;

	@JsonProperty("cityNM")
	private String cityNM;

	@JsonProperty("key")
	private String key;

	@JsonProperty("officeTelNo")
	private String officeTelNo;

	public HasAddressesIn() {

	}

	/**
	 * @param emailAddress
	 * @param mobilePhoneNO
	 * @param addressLine1
	 * @param addressLine2
	 * @param addressLine3
	 * @param addressLine4
	 */
	public HasAddressesIn(String emailAddress, String mobilePhoneNO, String addressLine1, String addressLine2,
			String addressLine3, String addressLine4) {
		super();
		this.emailAddress = emailAddress;
		this.mobilePhoneNO = mobilePhoneNO;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.addressLine3 = addressLine3;
		this.addressLine4 = addressLine4;
	}

	@JsonProperty("officeTelNo")
	public String getOfficeTelNo() {
		return officeTelNo;
	}

	@JsonProperty("officeTelNo")
	public void setOfficeTelNo(String officeTelNo) {
		this.officeTelNo = officeTelNo;
	}

	@JsonProperty("cityNM")
	public String getCityNM() {
		return cityNM;
	}

	@JsonProperty("cityNM")
	public void setCityNM(String cityNM) {
		this.cityNM = cityNM;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	@JsonProperty("postalCD")
	public String getPostalCD() {
		return postalCD;
	}

	@JsonProperty("postalCD")
	public void setPostalCD(String postalCD) {
		this.postalCD = postalCD;
	}

	@JsonProperty("emailAddress")
	public String getEmailAddress() {
		return emailAddress;
	}

	@JsonProperty("emailAddress")
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@JsonProperty("mobilePhoneNO")
	public String getMobilePhoneNO() {
		return mobilePhoneNO;
	}

	@JsonProperty("mobilePhoneNO")
	public void setMobilePhoneNO(String mobilePhoneNO) {
		this.mobilePhoneNO = mobilePhoneNO;
	}

	@JsonProperty("addressLine1")
	public String getAddressLine1() {
		return addressLine1;
	}

	@JsonProperty("addressLine1")
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	@JsonProperty("addressLine2")
	public String getAddressLine2() {
		return addressLine2;
	}

	@JsonProperty("addressLine2")
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	@JsonProperty("addressLine3")
	public String getAddressLine3() {
		return addressLine3;
	}

	@JsonProperty("addressLine3")
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	@JsonProperty("addressLine4")
	public String getAddressLine4() {
		return addressLine4;
	}

	@JsonProperty("addressLine4")
	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

}
