/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasdetailsofriskin;

import java.util.List;

import id.co.axa.eip.model.forlifeunitofexposure.ForLifeUnitofExposure;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.haspersonaldetailsin.HasPersonalDetailsIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "insuredID", "dependNo" , "hasPersonalDetailsIn", "agrRk" })
@Component
public class HasDetailsOfRisksIn {

	@JsonProperty("insuredID")
	private String insuredID;
	
	@JsonProperty("dependNo")
	private String dependNo;

	@JsonProperty("hasPersonalDetailsIn")
	private List<HasPersonalDetailsIn> hasPersonalDetailsIn = null;
	
	@JsonProperty("agrRk")
	private String agrRk;

	//GENSUB
	@JsonProperty("applicationRk")
	private String applicationRk;

	@JsonProperty("partyRk")
	private String partyRk;

	//DMTM
	@JsonProperty("relationshipToOwnerCD")
	private String relationshipToOwnerCD;

	@JsonProperty("rejectionInd")
	private String rejectionInd;

	@JsonProperty("forLifeUnitOfExposure")
	private List<ForLifeUnitofExposure> forLifeUnitofExposure;

	public HasDetailsOfRisksIn() {

	}

	/**
	 * @param insuredID
	 * @param dependNo
	 * @param hasPersonalDetailsIn
	 * @param agrRk
	 */
	public HasDetailsOfRisksIn(String insuredID, String dependNo, List<HasPersonalDetailsIn> hasPersonalDetailsIn,
			String agrRk) {
		super();
		this.insuredID = insuredID;
		this.dependNo = dependNo;
		this.hasPersonalDetailsIn = hasPersonalDetailsIn;
		this.agrRk = agrRk;
	}

	@JsonProperty("applicationRk")
	public String getApplicationRk() {
		return applicationRk;
	}

	@JsonProperty("applicationRk")
	public void setApplicationRk(String applicationRk) {
		this.applicationRk = applicationRk;
	}

	@JsonProperty("partyRk")
	public String getPartyRk() {
		return partyRk;
	}

	@JsonProperty("partyRk")
	public void setPartyRk(String partyRk) {
		this.partyRk = partyRk;
	}

	@JsonProperty("relationshipToOwnerCD")
	public String getRelationshipToOwnerCD() {
		return relationshipToOwnerCD;
	}

	@JsonProperty("relationshipToOwnerCD")
	public void setRelationshipToOwnerCD(String relationshipToOwnerCD) {
		this.relationshipToOwnerCD = relationshipToOwnerCD;
	}

	@JsonProperty("rejectionInd")
	public String getRejectionInd() {
		return rejectionInd;
	}

	@JsonProperty("rejectionInd")
	public void setRejectionInd(String rejectionInd) {
		this.rejectionInd = rejectionInd;
	}

	@JsonProperty("forLifeUnitOfExposure")
	public List<ForLifeUnitofExposure> getForLifeUnitofExposure() {
		return forLifeUnitofExposure;
	}

	@JsonProperty("forLifeUnitOfExposure")
	public void setForLifeUnitofExposure(List<ForLifeUnitofExposure> forLifeUnitofExposure) {
		this.forLifeUnitofExposure = forLifeUnitofExposure;
	}

	@JsonProperty("insuredID")
	public String getInsuredID() {
		return insuredID;
	}

	@JsonProperty("insuredID")
	public void setInsuredID(String insuredID) {
		this.insuredID = insuredID;
	}

	@JsonProperty("hasPersonalDetailsIn")
	public List<HasPersonalDetailsIn> getHasPersonalDetailsIn() {
		return hasPersonalDetailsIn;
	}

	@JsonProperty("hasPersonalDetailsIn")
	public void setHasPersonalDetailsIn(List<HasPersonalDetailsIn> hasPersonalDetailsIn) {
		this.hasPersonalDetailsIn = hasPersonalDetailsIn;
	}

	@JsonProperty("dependNo")
	public String getDependNo() {
		return dependNo;
	}

	@JsonProperty("dependNo")
	public void setDependNo(String dependNo) {
		this.dependNo = dependNo;
	}

	@JsonProperty("agrRk")
	public String getAgrRk() {
		return agrRk;
	}

	@JsonProperty("agrRk")
	public void setAgrRk(String agrRk) {
		this.agrRk = agrRk;
	}
	
	
}
