package id.co.axa.eip.model.hasPnCClaimIn;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@Component
public class hasPnCClaimIn {
    @JsonProperty("claimOpenDate")
    private String claimOpenDate;

    @JsonProperty("claimSubmissionDate")
    private String claimSubmissionDate;

    @JsonProperty("claimStatusCode")
    private String claimStatusCode;


}
