/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haslifepolicytransactiondetailsin;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.haspaymentdetailsin.HasPaymentDetailsIn;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "transDT", "transModeCD", "transDesc", "unitValue", "annuityContributionAmt", "totalUnits",
		"transactionStatusCD", "processedDttm", "unitValuationDT", "settledAMT", "unitPriceAsOfDt", "transCurrencyCD",
		"settledDT", "transTypeCD", "key","hasPaymentDetailsIn","userCd","sourceSystemCd" })
@Component
public class HasLifePolicyTransactionDetailsIn {

	@JsonProperty("transDT")
	private String transDT;

	@JsonProperty("transModeCD")
	private String transModeCD;

	@JsonProperty("transDesc")
	private String transDesc;

	@JsonProperty("unitValue")
	private String unitValue;

	@JsonProperty("annuityContributionAmt")
	private String annuityContributionAmt;

	@JsonProperty("totalUnits")
	private String totalUnits;

	@JsonProperty("transactionStatusCD")
	private String transactionStatusCD;

	@JsonProperty("processedDttm")
	private String processedDttm;

	@JsonProperty("unitValuationDT")
	private String unitValuationDT;

	@JsonProperty("settledAMT")
	private String settledAMT;

	@JsonProperty("unitPriceAsOfDt")
	private String unitPriceAsOfDt;

	@JsonProperty("transCurrencyCD")
	private String transCurrencyCD;

	@JsonProperty("settledDT")
	private String settledDT;

	@JsonProperty("transTypeCD")
	private String transTypeCD;

	@JsonProperty("key")
	private String key;
	
	@JsonProperty("paymentDueDT")
	private String paymentDueDT;
	
	@JsonProperty("paymentMethodCd")
	private String paymentMethodCd;

	@JsonProperty("payeeRk")
	private String payeeRk;

	@JsonProperty("hasPaymentDetailsIn")
	private List<HasPaymentDetailsIn> hasPaymentDetailsIn;

	@JsonProperty("userCd")
	private String userCd;

	@JsonProperty("sourceSystemCd")
	private String sourceSystemCd;

	@JsonProperty("remark")
	private String remark;

	public HasLifePolicyTransactionDetailsIn() {

	}

	/**
	 * @param transDT
	 * @param transModeCD
	 * @param transDesc
	 * @param unitValue
	 * @param annuityContributionAmt
	 * @param totalUnits
	 * @param transactionStatusCD
	 * @param processedDttm
	 * @param unitValuationDT
	 * @param settledAMT
	 * @param unitPriceAsOfDt
	 * @param transCurrencyCD
	 * @param settledDT
	 * @param transTypeCD
	 * @param key
	 * @param paymentDueDT
	 * @param paymentMethodCd
	 * @param payeeRk
	 * @param hasPaymentDetailsIn
	 */
	public HasLifePolicyTransactionDetailsIn(String transDT, String transModeCD, String transDesc, String unitValue,
			String annuityContributionAmt, String totalUnits, String transactionStatusCD, String processedDttm,
			String unitValuationDT, String settledAMT, String unitPriceAsOfDt, String transCurrencyCD, String settledDT,
			String transTypeCD, String key, String paymentDueDT, String paymentMethodCd, String payeeRk,
			List<HasPaymentDetailsIn> hasPaymentDetailsIn, String userCd , String sourceSystemCd, String remark) {
		super();
		this.transDT = transDT;
		this.transModeCD = transModeCD;
		this.transDesc = transDesc;
		this.unitValue = unitValue;
		this.annuityContributionAmt = annuityContributionAmt;
		this.totalUnits = totalUnits;
		this.transactionStatusCD = transactionStatusCD;
		this.processedDttm = processedDttm;
		this.unitValuationDT = unitValuationDT;
		this.settledAMT = settledAMT;
		this.unitPriceAsOfDt = unitPriceAsOfDt;
		this.transCurrencyCD = transCurrencyCD;
		this.settledDT = settledDT;
		this.transTypeCD = transTypeCD;
		this.key = key;
		this.paymentDueDT = paymentDueDT;
		this.paymentMethodCd = paymentMethodCd;
		this.payeeRk = payeeRk;
		this.hasPaymentDetailsIn = hasPaymentDetailsIn;
		this.userCd = userCd;
		this.sourceSystemCd = sourceSystemCd;
		this.remark = remark;
	}




	@JsonProperty("hasPaymentDetailsIn")
	public List<HasPaymentDetailsIn> getHasPaymentDetailsIn() {
		return hasPaymentDetailsIn;
	}

	@JsonProperty("hasPaymentDetailsIn")
	public void setHasPaymentDetailsIn(List<HasPaymentDetailsIn> hasPaymentDetailsIn) {
		this.hasPaymentDetailsIn = hasPaymentDetailsIn;
	}

	@JsonProperty("transDT")
	public String getTransDT() {
		return transDT;
	}

	@JsonProperty("transDT")
	public void setTransDT(String transDT) {
		this.transDT = transDT;
	}

	@JsonProperty("remark")
	public String getRemark() {
		return remark;
	}

	@JsonProperty("remark")
	public void setRemark(String remark) {
		this.remark = remark;
	}

	@JsonProperty("transModeCD")
	public String getTransModeCD() {
		return transModeCD;
	}

	@JsonProperty("transModeCD")
	public void setTransModeCD(String transModeCD) {
		this.transModeCD = transModeCD;
	}

	@JsonProperty("transDesc")
	public String getTransDesc() {
		return transDesc;
	}

	@JsonProperty("transDesc")
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	@JsonProperty("unitValue")
	public String getUnitValue() {
		return unitValue;
	}

	@JsonProperty("unitValue")
	public void setUnitValue(String unitValue) {
		this.unitValue = unitValue;
	}

	@JsonProperty("annuityContributionAmt")
	public String getAnnuityContributionAmt() {
		return annuityContributionAmt;
	}

	@JsonProperty("annuityContributionAmt")
	public void setAnnuityContributionAmt(String annuityContributionAmt) {
		this.annuityContributionAmt = annuityContributionAmt;
	}

	@JsonProperty("totalUnits")
	public String getTotalUnits() {
		return totalUnits;
	}

	@JsonProperty("totalUnits")
	public void setTotalUnits(String totalUnits) {
		this.totalUnits = totalUnits;
	}

	@JsonProperty("transactionStatusCD")
	public String getTransactionStatusCD() {
		return transactionStatusCD;
	}

	@JsonProperty("userCd")
	public String getUserCd() {
		return userCd;
	}

	@JsonProperty("userCd")
	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}

	@JsonProperty("sourceSystemCd")
	public String getSourceSystemCd() {
		return sourceSystemCd;
	}

	@JsonProperty("sourceSystemCd")
	public void setSourceSystemCd(String sourceSystemCd) {
		this.sourceSystemCd = sourceSystemCd;
	}

	@JsonProperty("transactionStatusCD")
	public void setTransactionStatusCD(String transactionStatusCD) {
		this.transactionStatusCD = transactionStatusCD;
	}

	@JsonProperty("processedDttm")
	public String getProcessedDttm() {
		return processedDttm;
	}


	@JsonProperty("processedDttm")
	public void setProcessedDttm(String processedDttm) {
		this.processedDttm = processedDttm;
	}

	@JsonProperty("unitValuationDT")
	public String getUnitValuationDT() {
		return unitValuationDT;
	}

	@JsonProperty("unitValuationDT")
	public void setUnitValuationDT(String unitValuationDT) {
		this.unitValuationDT = unitValuationDT;
	}

	@JsonProperty("settledAMT")
	public String getSettledAMT() {
		return settledAMT;
	}

	@JsonProperty("settledAMT")
	public void setSettledAMT(String settledAMT) {
		this.settledAMT = settledAMT;
	}

	@JsonProperty("unitPriceAsOfDt")
	public String getUnitPriceAsOfDt() {
		return unitPriceAsOfDt;
	}

	@JsonProperty("unitPriceAsOfDt")
	public void setUnitPriceAsOfDt(String unitPriceAsOfDt) {
		this.unitPriceAsOfDt = unitPriceAsOfDt;
	}

	@JsonProperty("transCurrencyCD")
	public String getTransCurrencyCD() {
		return transCurrencyCD;
	}

	@JsonProperty("transCurrencyCD")
	public void setTransCurrencyCD(String transCurrencyCD) {
		this.transCurrencyCD = transCurrencyCD;
	}

	@JsonProperty("settledDT")
	public String getSettledDT() {
		return settledDT;
	}

	@JsonProperty("settledDT")
	public void setSettledDT(String settledDT) {
		this.settledDT = settledDT;
	}

	@JsonProperty("transTypeCD")
	public String getTransTypeCD() {
		return transTypeCD;
	}

	@JsonProperty("transTypeCD")
	public void setTransTypeCD(String transTypeCD) {
		this.transTypeCD = transTypeCD;
	}

	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}
	
	@JsonProperty("paymentDueDT")
	public String getPaymentDueDT() {
		return paymentDueDT;
	}

	@JsonProperty("paymentDueDT")
	public void setPaymentDueDT(String paymentDueDT) {
		this.paymentDueDT = paymentDueDT;
	}

	@JsonProperty("paymentMethodCd")
	public String getPaymentMethodCd() {
		return paymentMethodCd;
	}

	@JsonProperty("paymentMethodCd")
	public void setPaymentMethodCd(String paymentMethodCd) {
		this.paymentMethodCd = paymentMethodCd;
	}
	
	@JsonProperty("payeeRk")
	public String getPayeeRk() {
		return payeeRk;
	}

	@JsonProperty("payeeRk")
	public void setPayeeRk(String payeeRk) {
		this.payeeRk = payeeRk;
	}


}
