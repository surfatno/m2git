/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.hasUnderwritingDetailsIn;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.springframework.stereotype.Component;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@Component
public class hasUnderwritingDetailsIn {

	@JsonProperty("underwritingStatusDT")
	private String underwritingStatusDT;

	@JsonProperty("underwritingStatusCD")
	private String underwritingStatusCD;

	@JsonProperty("underwritingStatusDT")
	public String getUnderwritingStatusDT() {
		return underwritingStatusDT;
	}

	@JsonProperty("underwritingStatusDT")
	public void setUnderwritingStatusDT(String underwritingStatusDT) {
		this.underwritingStatusDT = underwritingStatusDT;
	}

	@JsonProperty("underwritingStatusCD")
	public String getUnderwritingStatusCD() {
		return underwritingStatusCD;
	}

	@JsonProperty("underwritingStatusCD")
	public void setUnderwritingStatusCD(String underwritingStatusCD) {
		this.underwritingStatusCD = underwritingStatusCD;
	}
}
