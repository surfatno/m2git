package id.co.axa.eip.model.hasaccountdetailsin;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasinvestmentfunddetailsin.HasInvestmentFundDetailsIn;

/**
 * Created by Spring Tool Suite.
 * 
 * @author Ade Hidayat 
 * Date: Aug 26, 2021 
 * Time: 12:29:20 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "hasInvestmentFundDetailsIn" })
@Component
public class HasAccountDetailsIn {
	
	@JsonProperty("hasInvestmentFundDetailsIn")
	private List<HasInvestmentFundDetailsIn> hasInvestmentFundDetailsIn;

	public HasAccountDetailsIn() {

	}

	/**
	 * @param hasInvestmentFundDetailsIn
	 */
	public HasAccountDetailsIn(List<HasInvestmentFundDetailsIn> hasInvestmentFundDetailsIn) {
		this.hasInvestmentFundDetailsIn = hasInvestmentFundDetailsIn;
	}
	
	@JsonProperty("hasInvestmentFundDetailsIn")
	public List<HasInvestmentFundDetailsIn> getHasInvestmentFundDetailsIn() {
		return hasInvestmentFundDetailsIn;
	}
	
	@JsonProperty("hasInvestmentFundDetailsIn")
	public void setHasInvestmentFundDetailsIn(List<HasInvestmentFundDetailsIn> hasInvestmentFundDetailsIn) {
		this.hasInvestmentFundDetailsIn = hasInvestmentFundDetailsIn;
	}
	
	
	
}
