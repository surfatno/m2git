/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.canbeexternalorg;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import id.co.axa.eip.model.hasaddressesin.HasAddressesIn;
import id.co.axa.eip.model.haspartyaccountdetailsin.HasPartyAccountDetailsIn;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)


@Component
public class CanBeExternalOrg {

	@JsonProperty("currencyCd")
	private String currencyCd;

	@JsonProperty("currencyCd")
	public String getCurrencyCd() {
		return currencyCd;
	}

	@JsonProperty("currencyCd")
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	
}
