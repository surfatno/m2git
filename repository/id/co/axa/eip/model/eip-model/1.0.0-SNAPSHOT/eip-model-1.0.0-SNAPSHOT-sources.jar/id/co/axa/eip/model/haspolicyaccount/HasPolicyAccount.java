/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.haspolicyaccount;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.hasPnCClaimIn.hasPnCClaimIn;
import id.co.axa.eip.model.hasUnderwritingDetailsIn.hasUnderwritingDetailsIn;
import id.co.axa.eip.model.hasapplicationdetailsin.HasApplicationDetailsIn;
import id.co.axa.eip.model.hasbilling.HasBilling;
import id.co.axa.eip.model.hascustomerinformationin.HasCustomerInformationIn;
import id.co.axa.eip.model.hasdetailsofclaimin.HasDetailsOfClaimIn;
import id.co.axa.eip.model.hasdetailsofpolicyin.HasDetailsOfPolicyIn;
import id.co.axa.eip.model.hasdetailsofpolicytransactionIn.hasDetailsOfPolicyTransactionIn;
import id.co.axa.eip.model.hasdetailsofriskin.HasDetailsOfRisksIn;
import id.co.axa.eip.model.hasdetailsoftransactionin.hasDetailsOfTransactionIn;
import id.co.axa.eip.model.haslifepolicychangetransdetailsin.HasLifePolicyChangeTransDetailsIn;
import id.co.axa.eip.model.haslifepolicytransactiondetailsin.HasLifePolicyTransactionDetailsIn;
import id.co.axa.eip.model.hasnamevalue.HasNameValue;
import id.co.axa.eip.model.haspartydetailsin.HasPartyDetailsIn;
import id.co.axa.eip.model.isassociatedwithissuer.isAssociatedWithIssuer;
import id.co.axa.eip.model.isassociatedwithlifeinsuranceproduct.IsAssociatedWithLifeInsuranceProduct;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "policyEffectiveDTTM", "paymentMethodCD", "policyExpirationDTTM", "initialLumpsumPremiumAMT",
		"hasLifePolicyChangeTransDetailsIn", "policyReserveAmt", "hasNameValue", "hasApplicationDetailsIn", "paidToDT",
		"hasDetailsOfPolicyIn", "ePolicy", "issueDt", "sourceChannelCD", "hasLifePolicyTransactionDetailsIn",
		"policyRK", "hasPartyDetailsIn", "currencyCD", "isAssociatedWithLifeInsuranceProduct", "policyStatusCD",
		"topupRegularModalPremium", "statusChangeDT", "terminationDt", "policyNO", "policyDueDt", "premiumAMT",
		"paymentModeCD", "hasDetailsOfRisksIn", "hasBilling" })
@Component
public class HasPolicyAccount {

	@JsonProperty("policyEffectiveDTTM")
	private String policyEffectiveDTTM;

	@JsonProperty("paymentMethodCD")
	private String paymentMethodCD;

	@JsonProperty("policyExpirationDTTM")
	private String policyExpirationDTTM;

	@JsonProperty("initialLumpsumPremiumAMT")
	private String initialLumpsumPremiumAMT;

	@JsonProperty("issueBranchNM")
	private String issueBranchNM;

	@JsonProperty("issueBranchCD")
	private String issueBranchCD;

	@JsonProperty("hasLifePolicyChangeTransDetailsIn")
	private List<HasLifePolicyChangeTransDetailsIn> hasLifePolicyChangeTransDetailsIn;

	@JsonProperty("hasCustomerInformationIn")
	private List<HasCustomerInformationIn> hasCustomerInformationIn;

	@JsonProperty("hasBilling")
	private HasBilling hasBilling;

	@JsonProperty("applicationRk")
	private String applicationRk;

	@JsonProperty("producerRk")
	private String producerRk;

	@JsonProperty("policyReserveAmt")
	private String policyReserveAmt;

	@JsonProperty("hasApplicationDetailsIn")
	private List<HasApplicationDetailsIn> hasApplicationDetailsIn;

	@JsonProperty("paidToDT")
	private String paidToDT;

	@JsonProperty("hasDetailsOfPolicyIn")
	private List<HasDetailsOfPolicyIn> hasDetailsOfPolicyIn;

	@JsonProperty("ePolicy")
	private String ePolicy;

	@JsonProperty("issueDt")
	private String issueDt;

	@JsonProperty("sourceChannelCD")
	private String sourceChannelCD;

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	private List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn;

	@JsonProperty("hasNameValue")
	private List<HasNameValue> hasNameValue;

	@JsonProperty("policyRK")
	private String policyRK;

	@JsonProperty("policyStatusRk")
	private String policyStatusRk;

	@JsonProperty("hasPartyDetailsIn")
	private List<HasPartyDetailsIn> hasPartyDetailsIn;

	@JsonProperty("currencyCD")
	private String currencyCD;

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	private List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct;

	@JsonProperty("policyStatusCD")
	private String policyStatusCD;

	@JsonProperty("topupRegularModalPremium")
	private String topupRegularModalPremium;

	@JsonProperty("statusChangeDT")
	private String statusChangeDT;

	@JsonProperty("hasDetailsOfTransactionIn")
	private List<hasDetailsOfTransactionIn> hasDetailsOfTransactionIn;

	@JsonProperty("terminationDt")
	private String terminationDt;

	@JsonProperty("hasPnCClaimIn")
	private List<hasPnCClaimIn> hasPnCClaimIn;

	@JsonProperty("maturityDt")
	private String maturityDt;

	@JsonProperty("policyNO")
	private String policyNO;

	@JsonProperty("accountNo")
	private String accountNo;

	@JsonProperty("registeredBy")
	private String registeredBy;

	@JsonProperty("hasDetailsOfPolicyTransactionIn")
	private List<hasDetailsOfPolicyTransactionIn> hasDetailsOfPolicyTransactionIn;

	@JsonProperty("policyDueDt")
	private String policyDueDt;

	@JsonProperty("premiumAMT")
	private String premiumAMT;

	@JsonProperty("paymentModeCD")
	private String paymentModeCD;

	@JsonProperty("reinstatementDt")
	private String reinstatementDt;

	@JsonProperty("reinstatementIND")
	private String reinstatementIND;

	@JsonProperty("validToDttm")
	private String validToDttm;

	@JsonProperty("hasDetailsOfRisksIn")
	private List<HasDetailsOfRisksIn> hasDetailsOfRisksIn;

	@JsonProperty("paymentStatusCd")
	private String paymentStatusCd;

	@JsonProperty("generalRK")
	private String generalRK;

	@JsonProperty("hasDetailsOfClaimIn")
	private List<HasDetailsOfClaimIn> hasDetailsOfClaimIn;

	@JsonProperty("isAssociatedWithIssuer")
	private isAssociatedWithIssuer isAssociatedWithIssuer;

	@JsonProperty("modalPaymentAMT")
	private String modalPaymentAMT;

	@JsonProperty("duration")
	private String duration;

	@JsonProperty("downPaymentPct")
	private String downPaymentPct;

	@JsonProperty("finalPaymentDt")
	private String finalPaymentDt;

	@JsonProperty("underwriterId")
	private String underwriterId;

	@JsonProperty("hasUnderwritingDetailsIn")
	private List<hasUnderwritingDetailsIn> hasUnderwritingDetailsIn;

	/**
	 * @param policyNO
	 */
	public HasPolicyAccount(String policyNO) {
		this.policyNO = policyNO;
	}

	public HasPolicyAccount() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param policyEffectiveDTTM
	 * @param paymentMethodCD
	 * @param policyExpirationDTTM
	 * @param initialLumpsumPremiumAMT
	 * @param hasLifePolicyChangeTransDetailsIn
	 * @param hasCustomerInformationIn
	 * @param hasBilling
	 * @param policyReserveAmt
	 * @param hasApplicationDetailsIn
	 * @param paidToDT
	 * @param hasDetailsOfPolicyIn
	 * @param ePolicy
	 * @param issueDt
	 * @param sourceChannelCD
	 * @param hasLifePolicyTransactionDetailsIn
	 * @param hasNameValue
	 * @param policyRK
	 * @param policyStatusRk
	 * @param hasPartyDetailsIn
	 * @param currencyCD
	 * @param isAssociatedWithLifeInsuranceProduct
	 * @param policyStatusCD
	 * @param topupRegularModalPremium
	 * @param statusChangeDT
	 * @param terminationDt
	 * @param policyNO
	 * @param accountNo
	 * @param registeredBy
	 * @param policyDueDt
	 * @param premiumAMT
	 * @param applicationRk
	 * @param producerRk
	 * @param paymentModeCD
	 * @param hasDetailsOfRisksIn
	 * @param hasDetailsOfClaimIn
	 * @param paymentStatusCd
	 * @param generalRK
	 * @param issueBranchNM
	 * @param issueBranchCD
	 */
	public HasPolicyAccount(String policyEffectiveDTTM, String paymentMethodCD, String policyExpirationDTTM,
			String initialLumpsumPremiumAMT, List<HasLifePolicyChangeTransDetailsIn> hasLifePolicyChangeTransDetailsIn,
			List<HasCustomerInformationIn> hasCustomerInformationIn, HasBilling hasBilling, String policyReserveAmt, List<HasApplicationDetailsIn> hasApplicationDetailsIn,
			String paidToDT, List<HasDetailsOfPolicyIn> hasDetailsOfPolicyIn, String ePolicy, String issueDt,
			String sourceChannelCD, List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn,
			List<HasNameValue> hasNameValue, String policyRK, String policyStatusRk,
			List<HasPartyDetailsIn> hasPartyDetailsIn, String currencyCD, String applicationRk, String producerRk,
			List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct, String policyStatusCD,
			String topupRegularModalPremium, String statusChangeDT, String terminationDt, String policyNO,
			String policyDueDt, String premiumAMT, String paymentModeCD,
			List<HasDetailsOfRisksIn> hasDetailsOfRisksIn,List<HasDetailsOfClaimIn> hasDetailsOfClaimIn,
							String downPaymentPct) {
		this.downPaymentPct=downPaymentPct;
		this.policyEffectiveDTTM = policyEffectiveDTTM;
		this.paymentMethodCD = paymentMethodCD;
		this.policyExpirationDTTM = policyExpirationDTTM;
		this.initialLumpsumPremiumAMT = initialLumpsumPremiumAMT;
		this.hasLifePolicyChangeTransDetailsIn = hasLifePolicyChangeTransDetailsIn;
		this.hasCustomerInformationIn = hasCustomerInformationIn;
		this.hasBilling = hasBilling;
		this.policyReserveAmt = policyReserveAmt;
		this.hasApplicationDetailsIn = hasApplicationDetailsIn;
		this.paidToDT = paidToDT;
		this.hasDetailsOfPolicyIn = hasDetailsOfPolicyIn;
		this.ePolicy = ePolicy;
		this.issueDt = issueDt;
		this.sourceChannelCD = sourceChannelCD;
		this.applicationRk = applicationRk;
		this.producerRk = producerRk;
		this.hasLifePolicyTransactionDetailsIn = hasLifePolicyTransactionDetailsIn;
		this.hasNameValue = hasNameValue;
		this.policyRK = policyRK;
		this.policyStatusRk = policyStatusRk;
		this.hasPartyDetailsIn = hasPartyDetailsIn;
		this.currencyCD = currencyCD;
		this.isAssociatedWithLifeInsuranceProduct = isAssociatedWithLifeInsuranceProduct;
		this.policyStatusCD = policyStatusCD;
		this.topupRegularModalPremium = topupRegularModalPremium;
		this.statusChangeDT = statusChangeDT;
		this.terminationDt = terminationDt;
		this.policyNO = policyNO;
		this.accountNo = accountNo;
		this.registeredBy = registeredBy;
		this.policyDueDt = policyDueDt;
		this.premiumAMT = premiumAMT;
		this.paymentModeCD = paymentModeCD;
		this.hasDetailsOfRisksIn = hasDetailsOfRisksIn;
		this.paymentStatusCd = paymentStatusCd;
	    this.generalRK = generalRK;
		this.issueBranchNM = issueBranchNM;
		this.issueBranchCD = issueBranchCD;
		this.hasDetailsOfClaimIn=hasDetailsOfClaimIn;
	}

	@JsonProperty("downPaymentPct")
	public String getDownPaymentPct() {
		return downPaymentPct;
	}

	@JsonProperty("downPaymentPct")
	public void setDownPaymentPct(String downPaymentPct) {
		this.downPaymentPct = downPaymentPct;
	}

	@JsonProperty("duration")
	public String getDuration() {
		return duration;
	}

	@JsonProperty("duration")
	public void setDuration(String duration) {
		this.duration = duration;
	}

	@JsonProperty("modalPaymentAMT")
	public String getModalPaymentAMT() {
		return modalPaymentAMT;
	}

	@JsonProperty("modalPaymentAMT")
	public void setModalPaymentAMT(String modalPaymentAMT) {
		this.modalPaymentAMT = modalPaymentAMT;
	}

	@JsonProperty("isAssociatedWithIssuer")
	public isAssociatedWithIssuer getIsAssociatedWithIssuer() {
		return isAssociatedWithIssuer;
	}

	@JsonProperty("isAssociatedWithIssuer")
	public void setIsAssociatedWithIssuer(isAssociatedWithIssuer isAssociatedWithIssuer) {
		this.isAssociatedWithIssuer = isAssociatedWithIssuer;
	}

	@JsonProperty("maturityDt")
	public String getMaturityDt() {
		return maturityDt;
	}

	@JsonProperty("maturityDt")
	public void setMaturityDt(String maturityDt) {
		this.maturityDt = maturityDt;
	}

	@JsonProperty("reinstatementDt")
	public String getReinstatementDt() {
		return reinstatementDt;
	}

	@JsonProperty("reinstatementDt")
	public void setReinstatementDt(String reinstatementDt) {
		this.reinstatementDt = reinstatementDt;
	}

	@JsonProperty("reinstatementIND")
	public String getReinstatementIND() {
		return reinstatementIND;
	}

	@JsonProperty("reinstatementIND")
	public void setReinstatementIND(String reinstatementIND) {
		this.reinstatementIND = reinstatementIND;
	}

	@JsonProperty("validToDttm")
	public String getValidToDttm() {
		return validToDttm;
	}

	@JsonProperty("validToDttm")
	public void setValidToDttm(String validToDttm) {
		this.validToDttm = validToDttm;
	}

	@JsonProperty("policyEffectiveDTTM")
	public String getPolicyEffectiveDTTM() {
		return policyEffectiveDTTM;
	}

	@JsonProperty("policyEffectiveDTTM")
	public void setPolicyEffectiveDTTM(String policyEffectiveDTTM) {
		this.policyEffectiveDTTM = policyEffectiveDTTM;
	}

	@JsonProperty("paymentMethodCD")
	public String getPaymentMethodCD() {
		return paymentMethodCD;
	}

	@JsonProperty("paymentMethodCD")
	public void setPaymentMethodCD(String paymentMethodCD) {
		this.paymentMethodCD = paymentMethodCD;
	}

	@JsonProperty("policyExpirationDTTM")
	public String getPolicyExpirationDTTM() {
		return policyExpirationDTTM;
	}

	@JsonProperty("policyExpirationDTTM")
	public void setPolicyExpirationDTTM(String policyExpirationDTTM) {
		this.policyExpirationDTTM = policyExpirationDTTM;
	}

	@JsonProperty("initialLumpsumPremiumAMT")
	public String getInitialLumpsumPremiumAMT() {
		return initialLumpsumPremiumAMT;
	}

	@JsonProperty("initialLumpsumPremiumAMT")
	public void setInitialLumpsumPremiumAMT(String initialLumpsumPremiumAMT) {
		this.initialLumpsumPremiumAMT = initialLumpsumPremiumAMT;
	}

	@JsonProperty("hasLifePolicyChangeTransDetailsIn")
	public List<HasLifePolicyChangeTransDetailsIn> getHasLifePolicyChangeTransDetailsIn() {
		return hasLifePolicyChangeTransDetailsIn;
	}

	@JsonProperty("hasLifePolicyChangeTransDetailsIn")
	public void setHasLifePolicyChangeTransDetailsIn(
			List<HasLifePolicyChangeTransDetailsIn> hasLifePolicyChangeTransDetailsIn) {
		this.hasLifePolicyChangeTransDetailsIn = hasLifePolicyChangeTransDetailsIn;
	}

	@JsonProperty("hasCustomerInformationIn")
	public List<HasCustomerInformationIn> getHasCustomerInformationIn() {
		return hasCustomerInformationIn;
	}

	@JsonProperty("hasCustomerInformationIn")
	public void setHasCustomerInformationIn(List<HasCustomerInformationIn> hasCustomerInformationIn) {
		this.hasCustomerInformationIn = hasCustomerInformationIn;
	}

	@JsonProperty("applicationRk")
	public String getApplicationRk() {
		return applicationRk;
	}

	@JsonProperty("applicationRk")
	public void setApplicationRk(String applicationRk) {
		this.applicationRk = applicationRk;
	}

	@JsonProperty("producerRk")
	public String getProducerRk() {
		return producerRk;
	}

	@JsonProperty("producerRk")
	public void setProducerRk(String producerRk) {
		this.producerRk = producerRk;
	}

	@JsonProperty("issueBranchNM")
	public String getIssueBranchNM() {
		return issueBranchNM;
	}

	@JsonProperty("issueBranchNM")
	public void setIssueBranchNM(String issueBranchNM) {
		this.issueBranchNM = issueBranchNM;
	}

	@JsonProperty("issueBranchCD")
	public String getIssueBranchCD() {
		return issueBranchCD;
	}

	@JsonProperty("issueBranchCD")
	public void setIssueBranchCD(String issueBranchCD) {
		this.issueBranchCD = issueBranchCD;
	}

	@JsonProperty("policyReserveAmt")
	public String getPolicyReserveAmt() {
		return policyReserveAmt;
	}

	@JsonProperty("policyReserveAmt")
	public void setPolicyReserveAmt(String policyReserveAmt) {
		this.policyReserveAmt = policyReserveAmt;
	}

	@JsonProperty("hasApplicationDetailsIn")
	public List<HasApplicationDetailsIn> getHasApplicationDetailsIn() {
		return hasApplicationDetailsIn;
	}

	@JsonProperty("hasApplicationDetailsIn")
	public void setHasApplicationDetailsIn(List<HasApplicationDetailsIn> hasApplicationDetailsIn) {
		this.hasApplicationDetailsIn = hasApplicationDetailsIn;
	}

	@JsonProperty("paidToDT")
	public String getPaidToDT() {
		return paidToDT;
	}

	@JsonProperty("paidToDT")
	public void setPaidToDT(String paidToDT) {
		this.paidToDT = paidToDT;
	}

	@JsonProperty("hasDetailsOfPolicyIn")
	public List<HasDetailsOfPolicyIn> getHasDetailsOfPolicyIn() {
		return hasDetailsOfPolicyIn;
	}

	@JsonProperty("hasDetailsOfPolicyIn")
	public void setHasDetailsOfPolicyIn(List<HasDetailsOfPolicyIn> hasDetailsOfPolicyIn) {
		this.hasDetailsOfPolicyIn = hasDetailsOfPolicyIn;
	}

	@JsonProperty("ePolicy")
	public String getEPolicy() {
		return ePolicy;
	}

	@JsonProperty("ePolicy")
	public void setEPolicy(String ePolicy) {
		this.ePolicy = ePolicy;
	}

	@JsonProperty("issueDt")
	public String getIssueDt() {
		return issueDt;
	}

	@JsonProperty("issueDt")
	public void setIssueDt(String issueDt) {
		this.issueDt = issueDt;
	}

	@JsonProperty("sourceChannelCD")
	public String getSourceChannelCD() {
		return sourceChannelCD;
	}

	@JsonProperty("sourceChannelCD")
	public void setSourceChannelCD(String sourceChannelCD) {
		this.sourceChannelCD = sourceChannelCD;
	}

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	public List<HasLifePolicyTransactionDetailsIn> getHasLifePolicyTransactionDetailsIn() {
		return hasLifePolicyTransactionDetailsIn;
	}

	@JsonProperty("hasLifePolicyTransactionDetailsIn")
	public void setHasLifePolicyTransactionDetailsIn(
			List<HasLifePolicyTransactionDetailsIn> hasLifePolicyTransactionDetailsIn) {
		this.hasLifePolicyTransactionDetailsIn = hasLifePolicyTransactionDetailsIn;
	}

	@JsonProperty("policyRK")
	public String getPolicyRK() {
		return policyRK;
	}

	@JsonProperty("policyRK")
	public void setPolicyRK(String policyRK) {
		this.policyRK = policyRK;
	}

	@JsonProperty("hasPartyDetailsIn")
	public List<HasPartyDetailsIn> getHasPartyDetailsIn() {
		return hasPartyDetailsIn;
	}

	@JsonProperty("hasPartyDetailsIn")
	public void setHasPartyDetailsIn(List<HasPartyDetailsIn> hasPartyDetailsIn) {
		this.hasPartyDetailsIn = hasPartyDetailsIn;
	}

	@JsonProperty("currencyCD")
	public String getCurrencyCD() {
		return currencyCD;
	}

	@JsonProperty("currencyCD")
	public void setCurrencyCD(String currencyCD) {
		this.currencyCD = currencyCD;
	}

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	public List<IsAssociatedWithLifeInsuranceProduct> getIsAssociatedWithLifeInsuranceProduct() {
		return isAssociatedWithLifeInsuranceProduct;
	}

	@JsonProperty("isAssociatedWithLifeInsuranceProduct")
	public void setIsAssociatedWithLifeInsuranceProduct(
			List<IsAssociatedWithLifeInsuranceProduct> isAssociatedWithLifeInsuranceProduct) {
		this.isAssociatedWithLifeInsuranceProduct = isAssociatedWithLifeInsuranceProduct;
	}

	@JsonProperty("policyStatusCD")
	public String getPolicyStatusCD() {
		return policyStatusCD;
	}

	@JsonProperty("policyStatusCD")
	public void setPolicyStatusCD(String policyStatusCD) {
		this.policyStatusCD = policyStatusCD;
	}

	@JsonProperty("topupRegularModalPremium")
	public String getTopupRegularModalPremium() {
		return topupRegularModalPremium;
	}

	@JsonProperty("topupRegularModalPremium")
	public void setTopupRegularModalPremium(String topupRegularModalPremium) {
		this.topupRegularModalPremium = topupRegularModalPremium;
	}

	@JsonProperty("statusChangeDT")
	public String getStatusChangeDT() {
		return statusChangeDT;
	}

	@JsonProperty("statusChangeDT")
	public void setStatusChangeDT(String statusChangeDT) {
		this.statusChangeDT = statusChangeDT;
	}

	@JsonProperty("terminationDt")
	public String getTerminationDt() {
		return terminationDt;
	}

	@JsonProperty("terminationDt")
	public void setTerminationDt(String terminationDt) {
		this.terminationDt = terminationDt;
	}

	@JsonProperty("policyNO")
	public String getPolicyNO() {
		return policyNO;
	}

	@JsonProperty("policyNO")
	public void setPolicyNO(String policyNO) {
		this.policyNO = policyNO;
	}

	@JsonProperty("accountNo")
	public String getAccountNo(){return accountNo;}

	@JsonProperty("accountNo")
	public void setAccountNo(String accountNo){
		this.accountNo = accountNo;
	}

	@JsonProperty("registeredBy")
	public String getRegisteredBy() {
		return registeredBy;
	}

	@JsonProperty("registeredBy")
	public void setRegisteredBy(String registeredBy) {
		this.registeredBy = registeredBy;
	}

	@JsonProperty("policyDueDt")
	public String getPolicyDueDt() {
		return policyDueDt;
	}

	@JsonProperty("policyDueDt")
	public void setPolicyDueDt(String policyDueDt) {
		this.policyDueDt = policyDueDt;
	}

	@JsonProperty("premiumAMT")
	public String getPremiumAMT() {
		return premiumAMT;
	}

	@JsonProperty("premiumAMT")
	public void setPremiumAMT(String premiumAMT) {
		this.premiumAMT = premiumAMT;
	}

	@JsonProperty("paymentModeCD")
	public String getPaymentModeCD() {
		return paymentModeCD;
	}

	@JsonProperty("paymentModeCD")
	public void setPaymentModeCD(String paymentModeCD) {
		this.paymentModeCD = paymentModeCD;
	}

	@JsonProperty("hasDetailsOfRisksIn")
	public List<HasDetailsOfRisksIn> getHasDetailsOfRisksIn() {
		return hasDetailsOfRisksIn;
	}

	@JsonProperty("hasDetailsOfRisksIn")
	public void setHasDetailsOfRisksIn(List<HasDetailsOfRisksIn> hasDetailsOfRisksIn) {
		this.hasDetailsOfRisksIn = hasDetailsOfRisksIn;
	}

	@JsonProperty("hasBilling")
	public HasBilling getHasBilling() {
		return hasBilling;
	}

	@JsonProperty("hasBilling")
	public void setHasBilling(HasBilling hasBilling) {
		this.hasBilling = hasBilling;
	}

	@JsonProperty("hasNameValue")
	public List<HasNameValue> getHasNameValue() {
		return hasNameValue;
	}

	@JsonProperty("hasNameValue")
	public void setHasNameValue(List<HasNameValue> hasNameValue) {
		this.hasNameValue = hasNameValue;
	}

	public String getPolicyStatusRk() {
		return policyStatusRk;
	}

	public void setPolicyStatusRk(String policyStatusRk) {
		this.policyStatusRk = policyStatusRk;
	}

	@JsonProperty("hasDetailsOfClaimIn")
	public List<HasDetailsOfClaimIn> getHasDetailsOfClaimIn() {
		return hasDetailsOfClaimIn;
	}

	@JsonProperty("hasDetailsOfClaimIn")
	public void setHasDetailsOfClaimIn(List<HasDetailsOfClaimIn> hasDetailsOfClaimIn) {
		this.hasDetailsOfClaimIn = hasDetailsOfClaimIn;
	}

	public String getPaymentStatusCd() {
		return this.paymentStatusCd;
	}

	public void setPaymentStatusCd(String paymentStatusCd) {
		this.paymentStatusCd = paymentStatusCd;
	}

	public String getGeneralRK() {
		return this.generalRK;
	}

	public void setGeneralRK(String generalRK) {
		this.generalRK = generalRK;
	}
}
