package id.co.axa.eip.model.hasdetailsofpolicytransactionIn;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@Component("hasDetailsOfTransactionIn")
public class hasDetailsOfPolicyTransactionIn {
    @JsonProperty("totalTransAMT")
    private String totalTransAMT;

    @JsonProperty("totalTransAMT")
    public String getTotalTransAMT() {
        return totalTransAMT;
    }

    @JsonProperty("totalTransAMT")
    public void setTotalTransAMT(String totalTransAMT) {
        this.totalTransAMT = totalTransAMT;
    }
}
