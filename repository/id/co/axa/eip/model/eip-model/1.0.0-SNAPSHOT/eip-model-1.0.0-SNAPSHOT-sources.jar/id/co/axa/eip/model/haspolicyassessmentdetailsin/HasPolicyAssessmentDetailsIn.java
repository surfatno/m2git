package id.co.axa.eip.model.haspolicyassessmentdetailsin;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Created by Spring Tool Suite.
 * @author Ade Hidayat
 * Date: Aug 26, 2021
 * Time: 3:58:01 PM
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "assmtSection", "assmtStatus", "lastUpdBy", "assessmentClassType", "assmtDesc", "assmtRemark",
		"assmtRefNo", "assmtNo", "assmtTypeCd", "lastUpdDTTM"})
@Component
public class HasPolicyAssessmentDetailsIn {

	@JsonProperty("assmtSection")
	private String assmtSection;

	@JsonProperty("assmtStatus")
	private String assmtStatus;
	
	@JsonProperty("lastUpdBy")
	private String lastUpdBy;

	@JsonProperty("assessmentClassType")
	private String assessmentClassType;
	
	@JsonProperty("assmtDesc")
	private String assmtDesc;

	@JsonProperty("assmtRemark")
	private String assmtRemark;
	
	@JsonProperty("assmtRefNo")
	private String assmtRefNo;
	
	@JsonProperty("assmtNo")
	private String assmtNo;
	
	@JsonProperty("assmtTypeCd")
	private String assmtTypeCd;
	
	@JsonProperty("lastUpdDTTM")
	private String lastUpdDTTM;
	
	public HasPolicyAssessmentDetailsIn() {

	}
	
	/**
	 * @param assmtSection
	 * @param assmtStatus
	 * @param lastUpdBy
	 * @param assessmentClassType
	 * @param assmtDesc
	 * @param assmtRemark
	 * @param assmtRefNo
	 * @param assmtNo
	 * @param assmtTypeCd
	 * @param lastUpdDTTM
	 */
	public HasPolicyAssessmentDetailsIn(String assmtSection, String assmtStatus, String lastUpdBy,
			String assessmentClassType, String assmtDesc, String assmtRemark, String assmtRefNo, String assmtNo,
			String assmtTypeCd, String lastUpdDTTM) {
		this.assmtSection = assmtSection;
		this.assmtStatus = assmtStatus;
		this.lastUpdBy = lastUpdBy;
		this.assessmentClassType = assessmentClassType;
		this.assmtDesc = assmtDesc;
		this.assmtRemark = assmtRemark;
		this.assmtRefNo = assmtRefNo;
		this.assmtNo = assmtNo;
		this.assmtTypeCd = assmtTypeCd;
		this.lastUpdDTTM = lastUpdDTTM;
	}


	@JsonProperty("assmtSection")
	public String getAssmtSection() {
		return assmtSection;
	}

	@JsonProperty("assmtSection")
	public void setAssmtSection(String assmtSection) {
		this.assmtSection = assmtSection;
	}

	@JsonProperty("assmtStatus")
	public String getAssmtStatus() {
		return assmtStatus;
	}

	@JsonProperty("assmtStatus")
	public void setAssmtStatus(String assmtStatus) {
		this.assmtStatus = assmtStatus;
	}

	@JsonProperty("assessmentClassType")
	public String getAssessmentClassType() {
		return assessmentClassType;
	}

	@JsonProperty("assessmentClassType")
	public void setAssessmentClassType(String assessmentClassType) {
		this.assessmentClassType = assessmentClassType;
	}

	@JsonProperty("assmtRemark")
	public String getAssmtRemark() {
		return assmtRemark;
	}

	@JsonProperty("assmtRemark")
	public void setAssmtRemark(String assmtRemark) {
		this.assmtRemark = assmtRemark;
	}

	@JsonProperty("assmtRefNo")
	public String getAssmtRefNo() {
		return assmtRefNo;
	}

	@JsonProperty("assmtRefNo")
	public void setAssmtRefNo(String assmtRefNo) {
		this.assmtRefNo = assmtRefNo;
	}

	@JsonProperty("assmtTypeCd")
	public String getAssmtTypeCd() {
		return assmtTypeCd;
	}

	@JsonProperty("assmtTypeCd")
	public void setAssmtTypeCd(String assmtTypeCd) {
		this.assmtTypeCd = assmtTypeCd;
	}

	@JsonProperty("lastUpdDTTM")
	public String getLastUpdDTTM() {
		return lastUpdDTTM;
	}

	@JsonProperty("lastUpdDTTM")
	public void setLastUpdDTTM(String lastUpdDTTM) {
		this.lastUpdDTTM = lastUpdDTTM;
	}

	@JsonProperty("lastUpdBy")
	public String getLastUpdBy() {
		return lastUpdBy;
	}

	@JsonProperty("lastUpdBy")
	public void setLastUpdBy(String lastUpdBy) {
		this.lastUpdBy = lastUpdBy;
	}

	@JsonProperty("assmtDesc")
	public String getAssmtDesc() {
		return assmtDesc;
	}

	@JsonProperty("assmtDesc")
	public void setAssmtDesc(String assmtDesc) {
		this.assmtDesc = assmtDesc;
	}

	@JsonProperty("assmtNo")
	public String getAssmtNo() {
		return assmtNo;
	}

	@JsonProperty("assmtNo")
	public void setAssmtNo(String assmtNo) {
		this.assmtNo = assmtNo;
	}
	
	
}
