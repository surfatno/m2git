/*
 * Copyright (c) 2020 PT AXA SERVICES INDONESIA and/or its affiliates. All rights reserved
 * 
 * Technology Management
 * System Development
 * 
 * This code is distributed in the hope that it will be useful
 * 
 * This is class represents POJO class for request and response to EIP Services.
 * It is an ordinary Java object. POJOs are used for increasing the readability and re-usability of a program
 * 
 */

package id.co.axa.eip.model.response;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import id.co.axa.eip.model.body.Body;

/**
 * @author muhammadmufqi
 * @since 1.0
 * @version 1.0
 */

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "Body" })
@Component("response")
public class Response {

	@JsonProperty("Body")
	private Body body;

	/**
	 * 
	 */
	public Response() {

	}

	/**
	 * @param body
	 */
	public Response(Body body) {
		this.body = body;
	}

	@JsonProperty("Body")
	public Body getBody() {
		return body;
	}

	@JsonProperty("Body")
	public void setBody(Body body) {
		this.body = body;
	}
}
