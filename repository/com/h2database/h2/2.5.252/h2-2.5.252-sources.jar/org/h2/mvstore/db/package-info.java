/*
 * Copyright 2004-2026 H2 Group. Multiple-Licensed under the MPL 2.0,
 * and the EPL 1.0 (https://h2database.com/html/license.html).
 * Initial Developer: H2 Group
 */

/**
 * Helper classes to use the MVStore in the H2 database.
 */
package org.h2.mvstore.db;
