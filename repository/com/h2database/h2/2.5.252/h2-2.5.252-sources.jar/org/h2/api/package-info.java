/*
 * Copyright 2004-2026 H2 Group. Multiple-Licensed under the MPL 2.0,
 * and the EPL 1.0 (https://h2database.com/html/license.html).
 * Initial Developer: H2 Group
 */

/**
 * Contains interfaces for user-defined extensions, such as triggers and
 * user-defined aggregate functions.
 */
package org.h2.api;
