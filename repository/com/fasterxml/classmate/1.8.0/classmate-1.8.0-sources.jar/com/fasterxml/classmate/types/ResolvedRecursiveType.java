package com.fasterxml.classmate.types;

import java.lang.reflect.Modifier;
import java.util.*;
import java.util.function.Supplier;

import com.fasterxml.classmate.ResolvedType;
import com.fasterxml.classmate.TypeBindings;
import com.fasterxml.classmate.members.RawConstructor;
import com.fasterxml.classmate.members.RawField;
import com.fasterxml.classmate.members.RawMethod;

/**
 * Specialized type placeholder used in cases where type definition is
 * recursive; to avoid infinite loop, reference that would be "back" in
 * hierarchy is represented by an instance of this class.
 * Underlying information is achievable (for full resolution), but
 * not exposed using super type (parent) accessors; and has special
 * handling when used for constructing descriptions.
 */
public class ResolvedRecursiveType extends ResolvedType
{
    /**
     * Actual fully resolved type; assigned once resolution is complete
     */
    protected ResolvedType _referencedType;

    /**
     * For self-references with type bindings different from those of the referenced
     * type (like raw {@code Mid} within {@code Mid<String>}, or {@code N<N<T>>} within
     * {@code N<T>}), or to a referenced type only valid within its resolution context:
     * supplier of the actual type this self-reference represents.
     * Resolved lazily since doing so eagerly could lead to infinite recursion.
     *
     * @since 1.8
     */
    protected Supplier<ResolvedType> _actualTypeSupplier;

    /**
     * Actual type this self-reference represents, if (possibly) differs from referenced
     * type; resolved lazily using {@link #_actualTypeSupplier}.
     *
     * @since 1.8
     */
    protected volatile ResolvedType _actualType;

    /*
    /**********************************************************************
    /* Life cycle
    /**********************************************************************
     */
    
    public ResolvedRecursiveType(Class<?> erased, TypeBindings bindings)
    {
        super(erased, bindings);
    }
    
    @Override
    public boolean canCreateSubtypes() {
        // only depends on erased type, so no need to resolve actual type
        return _referencedType.canCreateSubtypes();
    }
    
    public void setReference(ResolvedType ref)
    {
        setReference(ref, null);
    }

    /**
     * Alternative to {@link #setReference(ResolvedType)} used when type bindings of
     * this self-reference differ from those of the referenced type, or if referenced
     * type is only valid within its resolution context: in that case,
     * {@link #getActualType()} returns type obtained (lazily) from given supplier.
     *
     * @since 1.8
     */
    public synchronized void setReference(ResolvedType ref, Supplier<ResolvedType> actualType)
    {
        // sanity check; should not be called multiple times
        if (_referencedType != null) {
            throw new IllegalStateException("Trying to re-set self reference; old value = "+_referencedType+", new = "+ref);
        }
        _referencedType = ref;
        _actualTypeSupplier = actualType;
    }

    /*
    /**********************************************************************
    /* Accessors for related types
    /**********************************************************************
     */
    
    /**
     * To avoid infinite loops (when traversing supertypes and their type parameters),
     * will return null; supertypes are accessible using {@link #findSupertype}, or
     * via type this self-reference represents (see {@link #getActualType()}).
     */
    @Override
    public ResolvedType getParentClass() {
        return null;
    }

    /**
     * Accessor for the type being resolved that this self-reference points to.
     * Note that type bindings of this self-reference may differ from those of the
     * referenced type (like for raw {@code Mid} within {@code Mid<String>}), or
     * referenced type may only be valid within its resolution context: if so,
     * {@link #getActualType()} returns the type self-reference actually represents.
     */
    @Override
    public ResolvedType getSelfReferencedType() { return _referencedType; }

    /**
     * Accessor for the type this self-reference represents: same as
     * {@link #getSelfReferencedType()}, unless type bindings of this self-reference
     * differ from those of the referenced type (like raw {@code Mid} within
     * {@code Mid<String>}, or {@code N<N<T>>} within {@code N<T>}), or referenced
     * type is only valid within its resolution context (like {@code B} in
     * {@code B extends Base<A>}, when resolving {@code A extends Base<B>}), in which
     * case it is the stand-alone type with bindings of this self-reference (resolved lazily).
     *<p>
     * NOTE: for expanding types (like {@code N<T>} above), following actual types
     * repeatedly yields ever deeper types.
     *
     * @return Type this self-reference represents; {@code null} if not yet resolved
     *
     * @since 1.8
     */
    public ResolvedType getActualType()
    {
        ResolvedType actual = _actualType;
        if (actual != null) {
            return actual;
        }
        final Supplier<ResolvedType> supplier;
        synchronized (this) {
            if (_actualType != null) {
                return _actualType;
            }
            supplier = _actualTypeSupplier;
            if (supplier == null) {
                return _referencedType;
            }
        }
        // resolved outside of lock, since resolution may access other self-references;
        // concurrent calls may resolve more than once, but only first one is retained
        actual = supplier.get();
        synchronized (this) {
            if (_actualType == null) {
                _actualType = actual;
                // no longer needed (and may hold on to `TypeResolver`)
                _actualTypeSupplier = null;
            }
            return _actualType;
        }
    }
    
    /**
     * Helper method for replacing given type, if it is a self-reference, with the type
     * it represents (see {@link #getActualType()}), since self-references themselves
     * expose no supertypes. Self-references not yet resolved (if called during
     * resolution), and other types, are returned as-is.
     *
     * @since 1.8
     */
    static ResolvedType actualType(ResolvedType type)
    {
        if (type instanceof ResolvedRecursiveType) {
            ResolvedType actual = ((ResolvedRecursiveType) type).getActualType();
            if (actual != null) {
                return actual;
            }
        }
        return type;
    }

    /**
     * Helper method for replacing self-references in given supertypes (like
     * implemented interfaces) with types they represent: see {@link #actualType}.
     *
     * @since 1.8
     */
    static List<ResolvedType> actualTypes(ResolvedType[] types)
    {
        if (types.length == 0) {
            return Collections.<ResolvedType>emptyList();
        }
        ResolvedType[] result = types;
        for (int i = 0; i < types.length; ++i) {
            ResolvedType actual = actualType(types[i]);
            if (actual != types[i]) {
                if (result == types) {
                    result = types.clone();
                }
                result[i] = actual;
            }
        }
        return Arrays.asList(result);
    }

    /**
     * To avoid infinite loops (when traversing supertypes and their type parameters),
     * will return empty list; supertypes are accessible using {@link #findSupertype}, or
     * via type this self-reference represents (see {@link #getActualType()}).
     */
    @Override
    public List<ResolvedType> getImplementedInterfaces() {
        return Collections.<ResolvedType>emptyList();
    }
    
    /**
     * Although self-reference itself exposes no supertypes (see {@link #getParentClass()}
     * and {@link #getImplementedInterfaces()}), supertypes are looked up from
     * the type it represents (see {@link #getActualType()}), including the type itself
     * (if given its erased type): this terminates since lookup is by erased type.
     *
     * @since 1.8
     */
    @Override
    public ResolvedType findSupertype(Class<?> erasedSupertype)
    {
        ResolvedType actual = actualType(this);
        // may still be unresolved, if called during resolution
        if (actual == this) {
            return super.findSupertype(erasedSupertype);
        }
        return actual.findSupertype(erasedSupertype);
    }

    /**
     * To avoid infinite loops, will return null type
     */
    @Override
    public ResolvedType getArrayElementType() { // interfaces are never arrays, so:
        return null;
    }

    /*
    /**********************************************************************
    /* Simple property accessors
    /**********************************************************************
     */

    @Override
    public boolean isInterface() { return _erasedType.isInterface(); }

    @Override
    public boolean isAbstract() { return Modifier.isAbstract(_erasedType.getModifiers()); }

    @Override
    public boolean isArray() { return _erasedType.isArray(); }

    @Override
    public boolean isPrimitive() { return false; }

    /*
    /**********************************************************************
    /* Accessors for raw (minimally procesed) members
    /**********************************************************************
     */

    @Override
    public List<RawField> getMemberFields() { return getActualType().getMemberFields(); }
    @Override
    public List<RawField> getStaticFields() { return getActualType().getStaticFields(); }
    @Override
    public List<RawMethod> getStaticMethods() { return getActualType().getStaticMethods(); }
    @Override
    public List<RawMethod> getMemberMethods() { return getActualType().getMemberMethods(); }
    @Override
    public List<RawConstructor> getConstructors() { return getActualType().getConstructors(); }
    
    /*
    /**********************************************************************
    /* String representations
    /**********************************************************************
     */

    @Override
    public StringBuilder appendSignature(StringBuilder sb) {
        // to avoid infinite recursion, only print type erased version
        return appendErasedSignature(sb);
    }

    @Override
    public StringBuilder appendErasedSignature(StringBuilder sb) {
        return _appendErasedClassSignature(sb);
    }

    @Override
    public StringBuilder appendBriefDescription(StringBuilder sb) {
        return _appendClassDescription(sb);
    }

    @Override
    public StringBuilder appendFullDescription(StringBuilder sb)
    {
        // should never get called, but just in case, only print brief description
        return appendBriefDescription(sb);
    }

    /*
    /**********************************************************************
    /* Other overrides
    /**********************************************************************
     */

    // 02-Jan-2026: [classmate#117]: Do NOT compare _referencedType to avoid infinite
    // recursion: super.equals() already compares class type, erased type, and type
    // bindings,  which is sufficient for determining equality of recursive types.
    // Comparing _referencedType causes StackOverflowError when comparing types
    // from different TypeResolver instances.
    /*
    @Override
    public boolean equals(Object o)
    {
        return super.equals(o);
    }
    */

    // Only for compliance purposes: lgtm.com complains if only equals overridden
    // 02-Jan-2026, tatu: No longer, base impl is fine
    // @Override public int hashCode() { return super.hashCode(); }
}
