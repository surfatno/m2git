/*
 * Copyright 2026 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention;

import io.micrometer.core.instrument.Tags;

import java.lang.management.MemoryPoolMXBean;
import java.util.function.Function;

/**
 * Convention for JVM memory used metrics.
 *
 * @see io.micrometer.core.instrument.binder.jvm.JvmMemoryMetrics
 * @since 1.18.0
 */
public interface JvmMemoryUsedMeterConvention {

    /**
     * Canonical name of the meter.
     * @return meter name
     */
    String getName();

    /**
     * Tags specific to this meter convention.
     * @param memoryPoolBean the memory pool bean from which to derive tags
     * @return tags to use with the meter
     */
    default Tags getTags(MemoryPoolMXBean memoryPoolBean) {
        return Tags.empty();
    }

    /**
     * Create a {@link JvmMemoryUsedMeterConvention} with the given name.
     * @param name meter name
     * @return a new convention instance
     */
    static JvmMemoryUsedMeterConvention of(String name) {
        return () -> name;
    }

    /**
     * Create a {@link JvmMemoryUsedMeterConvention} with the given name and tags
     * function.
     * @param name meter name
     * @param tagsFunction function to derive tags from a {@link MemoryPoolMXBean}
     * @return a new convention instance
     */
    static JvmMemoryUsedMeterConvention of(String name, Function<MemoryPoolMXBean, Tags> tagsFunction) {
        return new JvmMemoryUsedMeterConvention() {
            @Override
            public String getName() {
                return name;
            }

            @Override
            public Tags getTags(MemoryPoolMXBean memoryPoolBean) {
                return tagsFunction.apply(memoryPoolBean);
            }
        };
    }

}
