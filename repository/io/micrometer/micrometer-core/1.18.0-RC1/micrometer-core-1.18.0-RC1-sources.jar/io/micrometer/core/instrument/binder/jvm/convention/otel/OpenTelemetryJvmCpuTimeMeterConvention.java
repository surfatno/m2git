/*
 * Copyright 2026 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention.otel;

import io.micrometer.core.instrument.binder.jvm.convention.JvmCpuTimeMeterConvention;

/**
 * Convention for process CPU time metrics based on OpenTelemetry semantic conventions.
 *
 * @see <a href=
 * "https://opentelemetry.io/docs/specs/semconv/runtime/jvm-metrics/#metric-jvmcputime">OpenTelemetry
 * semantic convention for jvm.cpu.time</a>
 * @see io.micrometer.core.instrument.binder.jvm.convention.otel
 * @see io.micrometer.core.instrument.binder.system.ProcessorMetrics
 * @since 1.18.0
 */
public class OpenTelemetryJvmCpuTimeMeterConvention implements JvmCpuTimeMeterConvention {

    @Override
    public String getName() {
        return "jvm.cpu.time";
    }

}
