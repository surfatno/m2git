/*
 * Copyright 2025 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention.otel;

import io.micrometer.core.instrument.Tags;

import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;

/**
 * Conventions for JVM memory metrics based on OpenTelemetry semantic conventions.
 *
 * @see <a href=
 * "https://github.com/open-telemetry/semantic-conventions/blob/v1.37.0/docs/runtime/jvm-metrics.md">OpenTelemtry
 * Semantic conventions for JVM metrics v1.37.0</a>
 * @see io.micrometer.core.instrument.binder.jvm.JvmMemoryMetrics
 * @since 1.16.0
 * @deprecated use individual convention types such as
 * {@link OpenTelemetryJvmMemoryUsedMeterConvention},
 * {@link OpenTelemetryJvmMemoryCommittedMeterConvention},
 * {@link OpenTelemetryJvmMemoryMaxMeterConvention}, and
 * {@link OpenTelemetryJvmMemoryUsedAfterLastGcMeterConvention} instead
 */
@Deprecated
@SuppressWarnings("deprecation")
public class OpenTelemetryJvmMemoryMeterConventions
        extends io.micrometer.core.instrument.binder.jvm.convention.micrometer.MicrometerJvmMemoryMeterConventions {

    public OpenTelemetryJvmMemoryMeterConventions(Tags extraTags) {
        super(extraTags);
    }

    @Override
    protected Tags getCommonTags(MemoryPoolMXBean memoryPoolBean) {
        return this.extraTags.and(Tags.of("jvm.memory.pool.name", memoryPoolBean.getName(), "jvm.memory.type",
                MemoryType.HEAP.equals(memoryPoolBean.getType()) ? "heap" : "non_heap"));
    }

    @Override
    public io.micrometer.core.instrument.binder.MeterConvention<MemoryPoolMXBean> getMemoryMaxConvention() {
        return new io.micrometer.core.instrument.binder.SimpleMeterConvention<>("jvm.memory.limit",
                this::getCommonTags);
    }

}
