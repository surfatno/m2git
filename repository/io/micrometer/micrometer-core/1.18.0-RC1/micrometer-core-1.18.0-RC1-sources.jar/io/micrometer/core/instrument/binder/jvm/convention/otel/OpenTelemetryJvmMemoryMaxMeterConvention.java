/*
 * Copyright 2026 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention.otel;

import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.jvm.convention.JvmMemoryMaxMeterConvention;

import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;

/**
 * Convention for JVM memory max metrics based on OpenTelemetry semantic conventions.
 *
 * @see <a href=
 * "https://opentelemetry.io/docs/specs/semconv/runtime/jvm-metrics/#metric-jvmmemorylimit">OpenTelemetry
 * semantic convention for jvm.memory.limit</a>
 * @see io.micrometer.core.instrument.binder.jvm.convention.otel
 * @see io.micrometer.core.instrument.binder.jvm.JvmMemoryMetrics
 * @since 1.18.0
 */
public class OpenTelemetryJvmMemoryMaxMeterConvention implements JvmMemoryMaxMeterConvention {

    @Override
    public String getName() {
        return "jvm.memory.limit";
    }

    @Override
    public Tags getTags(MemoryPoolMXBean memoryPoolBean) {
        return Tags.of("jvm.memory.pool.name", memoryPoolBean.getName(), "jvm.memory.type",
                MemoryType.HEAP.equals(memoryPoolBean.getType()) ? "heap" : "non_heap");
    }

}
