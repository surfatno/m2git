/*
 * Copyright 2018 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument;

import io.micrometer.core.annotation.Incubating;
import org.jspecify.annotations.Nullable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import java.util.function.ToDoubleFunction;

/**
 * A virtual meter that manages a dynamic set of gauges with a common name and common
 * tags.
 * <p>
 * A {@code MultiGauge} is not itself a {@link Meter}; it creates and removes individual
 * {@link Gauge} meters as rows are registered. Each row contributes unique tags and a
 * value function. Re-registering rows reconciles the gauges currently managed by this
 * instance with the supplied rows.
 *
 * @author Jon Schneider
 * @since 1.1.0
 */
@Incubating(since = "1.1.0")
public class MultiGauge {

    private final MeterRegistry registry;

    private final Meter.Id commonId;

    private final Map<Meter.Id, RowState> registeredRows = new HashMap<>();

    private MultiGauge(MeterRegistry registry, Meter.Id commonId) {
        this.registry = registry;
        this.commonId = commonId;
    }

    /**
     * @param name The gauge's name.
     * @return A new gauge builder.
     */
    public static Builder builder(String name) {
        return new Builder(name);
    }

    /**
     * Register rows for this multi-gauge without replacing rows that have already been
     * registered with the same tags. Rows that are no longer present are removed.
     * @param rows rows to register
     */
    public void register(Iterable<? extends Row<?>> rows) {
        register(rows, false);
    }

    /**
     * Register rows for this multi-gauge.
     * <p>
     * Each row is registered as a gauge using this multi-gauge's common name and tags,
     * combined with the row's unique tags, after applying any configured
     * {@link io.micrometer.core.instrument.config.MeterFilter MeterFilter}s.
     * <ul>
     * <li>Previously registered rows that are no longer present in {@code rows} are
     * removed from the registry.</li>
     * <li>When {@code overwrite} is {@code true}, existing gauges are updated to track
     * the new row values. If multiple rows in {@code rows} resolve to the same meter ID
     * (either directly or after filter transformations), the last row in iteration order
     * takes precedence.</li>
     * <li>When {@code overwrite} is {@code false}, previously registered rows are left
     * unchanged. If multiple rows in {@code rows} resolve to the same meter ID, the first
     * row in iteration order takes precedence.</li>
     * </ul>
     * <p>
     * Note: If a {@code MeterFilter} removes or modifies tags such that multiple rows
     * share the same mapped tags, those rows will contend for the same single gauge.
     * @param rows rows to register
     * @param overwrite whether to update previously registered rows and overwrite
     * duplicate rows within the batch
     */
    public void register(Iterable<? extends Row<?>> rows, boolean overwrite) {
        synchronized (registeredRows) {
            Set<Meter.Id> newRowIds = new HashSet<>();

            for (Row<?> row : rows) {
                Meter.Id preFilteredId = commonId.withTags(row.uniqueTags);
                Meter.Id rowId = registry.getMappedId(preFilteredId);
                newRowIds.add(rowId);

                RowState existingState = registeredRows.get(rowId);
                if (existingState != null) {
                    if (overwrite) {
                        existingState.setRow(row);
                    }
                }
                else {
                    RowState newState = new RowState(row);
                    registry.gauge(preFilteredId, newState, RowState::value);
                    registeredRows.put(rowId, newState);
                }
            }

            registeredRows.keySet().removeIf(id -> {
                if (!newRowIds.contains(id)) {
                    registry.remove(id);
                    return true;
                }
                return false;
            });
        }
    }

    private static final class RowState {

        private volatile Row<?> row;

        RowState(Row<?> row) {
            this.row = row;
        }

        void setRow(Row<?> row) {
            this.row = row;
        }

        double value() {
            Row<?> r = this.row;
            return r != null ? r.value() : Double.NaN;
        }

    }

    public static class Row<T> {

        private final Tags uniqueTags;

        private final T obj;

        private final ToDoubleFunction<T> valueFunction;

        private Row(Tags uniqueTags, T obj, ToDoubleFunction<T> valueFunction) {
            this.uniqueTags = uniqueTags;
            this.obj = obj;
            this.valueFunction = valueFunction;
        }

        double value() {
            return valueFunction.applyAsDouble(obj);
        }

        /**
         * Create a row from tags, an object, and a value function.
         * @param uniqueTags tags that identify this row
         * @param obj object from which the gauge value is read
         * @param valueFunction function used to extract the gauge value
         * @param <T> object type
         * @return a row for use with {@link MultiGauge#register(Iterable)} or
         * {@link MultiGauge#register(Iterable, boolean)}
         */
        public static <T> Row<T> of(Tags uniqueTags, T obj, ToDoubleFunction<T> valueFunction) {
            return new Row<>(uniqueTags, obj, valueFunction);
        }

        /**
         * Create a row from tags and a number.
         * @param uniqueTags tags that identify this row
         * @param number number used as the gauge value
         * @return a row for use with {@link MultiGauge#register(Iterable)} or
         * {@link MultiGauge#register(Iterable, boolean)}
         */
        public static Row<Number> of(Tags uniqueTags, Number number) {
            return new Row<>(uniqueTags, number, Number::doubleValue);
        }

        /**
         * Create a row from tags and a number supplier.
         * @param uniqueTags tags that identify this row
         * @param valueFunction supplier used to provide the gauge value
         * @param <T> number type
         * @return a row for use with {@link MultiGauge#register(Iterable)} or
         * {@link MultiGauge#register(Iterable, boolean)}
         */
        public static <T extends Number> Row<Supplier<T>> of(Tags uniqueTags, Supplier<T> valueFunction) {
            return new Row<>(uniqueTags, valueFunction, f -> {
                Number value = valueFunction.get();
                return value == null ? Double.NaN : value.doubleValue();
            });
        }

    }

    /**
     * Fluent builder for multi-gauges.
     */
    public static class Builder {

        private final String name;

        private Tags tags = Tags.empty();

        private @Nullable String description;

        private @Nullable String baseUnit;

        private Builder(String name) {
            this.name = name;
        }

        /**
         * @param tags Must be an even number of arguments representing key/value pairs of
         * tags.
         * @return The gauge builder with added tags.
         */
        public Builder tags(String... tags) {
            return tags(Tags.of(tags));
        }

        /**
         * @param tags Tags to add to the eventual gauge.
         * @return The gauge builder with added tags.
         */
        public Builder tags(Iterable<Tag> tags) {
            this.tags = this.tags.and(tags);
            return this;
        }

        /**
         * @param key The tag key.
         * @param value The tag value.
         * @return The gauge builder with a single added tag.
         */
        public Builder tag(String key, String value) {
            this.tags = tags.and(key, value);
            return this;
        }

        /**
         * @param description Description text of the eventual gauge.
         * @return The gauge builder with added description.
         */
        public Builder description(@Nullable String description) {
            this.description = description;
            return this;
        }

        /**
         * @param unit Base unit of the eventual gauge.
         * @return The gauge builder with added base unit.
         */
        public Builder baseUnit(@Nullable String unit) {
            this.baseUnit = unit;
            return this;
        }

        /**
         * Create a multi-gauge associated with the given registry and the configured
         * name, tags, description, and base unit.
         * @param registry registry used to manage the gauges created for registered rows
         * @return a multi-gauge associated with the given registry
         */
        public MultiGauge register(MeterRegistry registry) {
            return new MultiGauge(registry, new Meter.Id(name, tags, baseUnit, description, Meter.Type.GAUGE, null));
        }

    }

}
