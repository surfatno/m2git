/*
 * Copyright 2017 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.cache;

import com.hazelcast.config.Config;
import io.micrometer.common.util.internal.logging.InternalLogger;
import io.micrometer.common.util.internal.logging.InternalLoggerFactory;
import io.micrometer.core.instrument.*;
import io.micrometer.core.instrument.binder.BaseUnits;
import io.micrometer.core.instrument.binder.cache.HazelcastIMapAdapter.LocalMapStats;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.ToDoubleFunction;
import java.util.function.ToLongFunction;

/**
 * Collect metrics on Hazelcast caches, including detailed metrics on storage space, near
 * cache usage, and timings.
 * <p>
 * To detect whether statistics are enabled, use an overload that accepts the Hazelcast
 * {@link Config}. If no configuration is provided, statistics are assumed to be enabled.
 * The statistics-enabled state is captured when this binder is created. If statistics are
 * enabled later, create and bind a new {@code HazelcastCacheMetrics} instance.
 *
 * @author Jon Schneider
 * @author Jewoo Shin
 */
public class HazelcastCacheMetrics extends CacheMeterBinder<Object> {

    private static final InternalLogger log = InternalLoggerFactory.getInstance(HazelcastCacheMetrics.class);

    private static final String DESCRIPTION_CACHE_ENTRIES = "The number of entries held by this member";

    private static final String DESCRIPTION_CACHE_ENTRY_MEMORY = "Memory cost of entries held by this member";

    private static final String DESCRIPTION_CACHE_NEAR_REQUESTS = "The number of requests (hits or misses) of near cache entries owned by this member";

    private final HazelcastIMapAdapter cache;

    private final boolean statisticsEnabled;

    /**
     * Record metrics on a Hazelcast cache.
     * @param registry registry to bind metrics to
     * @param cache Hazelcast IMap cache to instrument
     * @param tags Tags to apply to all recorded metrics. Must be an even number of
     * arguments representing key/value pairs of tags.
     * @return The instrumented cache, unchanged. The original cache is not wrapped or
     * proxied in any way.
     */
    public static Object monitor(MeterRegistry registry, Object cache, String... tags) {
        return monitor(registry, cache, Tags.of(tags));
    }

    /**
     * Record metrics on a Hazelcast cache.
     * @param registry registry to bind metrics to
     * @param cache Hazelcast IMap cache to instrument
     * @param tags Tags to apply to all recorded metrics.
     * @return The instrumented cache, unchanged. The original cache is not wrapped or
     * proxied in any way.
     */
    public static Object monitor(MeterRegistry registry, Object cache, Iterable<Tag> tags) {
        new HazelcastCacheMetrics(cache, tags).bindTo(registry);
        return cache;
    }

    /**
     * Record metrics on a Hazelcast cache.
     * @param registry registry to bind metrics to
     * @param cache Hazelcast IMap cache to instrument
     * @param tags Tags to apply to all recorded metrics.
     * @param config Hazelcast configuration used to determine whether statistics are
     * enabled for the cache
     * @return The instrumented cache, unchanged. The original cache is not wrapped or
     * proxied in any way.
     * @since 1.18.0
     */
    public static Object monitor(MeterRegistry registry, Object cache, Iterable<Tag> tags, Config config) {
        new HazelcastCacheMetrics(cache, tags, config).bindTo(registry);
        return cache;
    }

    /**
     * Binder for Hazelcast cache metrics.
     * @param cache Hazelcast IMap cache to instrument
     * @param tags Tags to apply to all recorded metrics.
     */
    public HazelcastCacheMetrics(Object cache, Iterable<Tag> tags) {
        this(cache, tags, true);
    }

    /**
     * Binder for Hazelcast cache metrics.
     * @param cache Hazelcast IMap cache to instrument
     * @param tags Tags to apply to all recorded metrics.
     * @param config Hazelcast configuration used to determine whether statistics are
     * enabled for the cache
     * @since 1.18.0
     */
    public HazelcastCacheMetrics(Object cache, Iterable<Tag> tags, Config config) {
        this(cache, tags, config.findMapConfig(HazelcastIMapAdapter.nameOf(cache)).isStatisticsEnabled());
    }

    private HazelcastCacheMetrics(Object cache, Iterable<Tag> tags, boolean statisticsEnabled) {
        super(cache, HazelcastIMapAdapter.nameOf(cache), tags);
        this.cache = new HazelcastIMapAdapter(cache);
        this.statisticsEnabled = statisticsEnabled;
        if (!statisticsEnabled) {
            log.warn(
                    "The cache '{}' is not recording statistics. No meters that require statistics will be registered. Enable statistics for this cache (for example by calling 'MapConfig#setStatisticsEnabled(true)' when building the cache) before binding metrics.",
                    HazelcastIMapAdapter.nameOf(cache));
        }
    }

    @Override
    protected @Nullable Long size() {
        if (!statisticsEnabled) {
            return null;
        }
        LocalMapStats localMapStats = cache.getLocalMapStats();
        if (localMapStats != null) {
            return localMapStats.getOwnedEntryCount();
        }

        return null;
    }

    /**
     * @return The number of hits against cache entries held in this local partition. Not
     * all gets had to result from a get operation against {@link #cache}. If a get
     * operation elsewhere in the cluster caused a lookup against an entry held in this
     * partition, the hit will be recorded against map stats in this partition and not in
     * the map stats of the calling {@code IMap}.
     */
    @Override
    protected long hitCount() {
        if (!statisticsEnabled) {
            return UNSUPPORTED;
        }
        LocalMapStats localMapStats = cache.getLocalMapStats();
        if (localMapStats != null) {
            return localMapStats.getHits();
        }

        return 0L;
    }

    /**
     * @return There is no way to calculate miss count in Hazelcast. See issue #586.
     */
    @Override
    protected @Nullable Long missCount() {
        return null;
    }

    @Override
    protected @Nullable Long evictionCount() {
        return null;
    }

    @Override
    protected long putCount() {
        if (!statisticsEnabled) {
            return UNSUPPORTED;
        }
        LocalMapStats localMapStats = cache.getLocalMapStats();
        if (localMapStats != null) {
            return localMapStats.getPutOperationCount() + localMapStats.getSetOperationCount();
        }

        return 0L;
    }

    @Override
    protected void bindImplementationSpecificMetrics(MeterRegistry registry) {
        if (!statisticsEnabled) {
            return;
        }
        Gauge
            .builder("cache.entries", cache,
                    cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getBackupEntryCount))
            .tags(getTagsWithCacheName())
            .tag("ownership", "backup")
            .description(DESCRIPTION_CACHE_ENTRIES)
            .register(registry);

        Gauge
            .builder("cache.entries", cache,
                    cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getOwnedEntryCount))
            .tags(getTagsWithCacheName())
            .tag("ownership", "owned")
            .description(DESCRIPTION_CACHE_ENTRIES)
            .register(registry);

        Gauge
            .builder("cache.entry.memory", cache,
                    cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getBackupEntryMemoryCost))
            .tags(getTagsWithCacheName())
            .tag("ownership", "backup")
            .description(DESCRIPTION_CACHE_ENTRY_MEMORY)
            .baseUnit(BaseUnits.BYTES)
            .register(registry);

        Gauge
            .builder("cache.entry.memory", cache,
                    cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getOwnedEntryMemoryCost))
            .tags(getTagsWithCacheName())
            .tag("ownership", "owned")
            .description(DESCRIPTION_CACHE_ENTRY_MEMORY)
            .baseUnit(BaseUnits.BYTES)
            .register(registry);

        FunctionCounter
            .builder("cache.partition.gets", cache,
                    cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getGetOperationCount))
            .tags(getTagsWithCacheName())
            .description("The total number of get operations executed against this partition")
            .register(registry);

        timings(registry);
        nearCacheMetrics(registry);
    }

    private double getDouble(@Nullable LocalMapStats localMapStats, ToDoubleFunction<LocalMapStats> function) {
        return localMapStats != null ? function.applyAsDouble(localMapStats) : Double.NaN;
    }

    private void nearCacheMetrics(MeterRegistry registry) {
        LocalMapStats localMapStats = cache.getLocalMapStats();
        if (localMapStats != null && localMapStats.getNearCacheStats() != null) {
            Gauge
                .builder("cache.near.requests", cache,
                        cache -> getDouble(cache.getLocalMapStats(),
                                (stats) -> Objects.requireNonNull(stats.getNearCacheStats()).getHits()))
                .tags(getTagsWithCacheName())
                .tag("result", "hit")
                .description(DESCRIPTION_CACHE_NEAR_REQUESTS)
                .register(registry);

            Gauge
                .builder("cache.near.requests", cache,
                        cache -> getDouble(cache.getLocalMapStats(),
                                (stats) -> Objects.requireNonNull(stats.getNearCacheStats()).getMisses()))
                .tags(getTagsWithCacheName())
                .tag("result", "miss")
                .description(DESCRIPTION_CACHE_NEAR_REQUESTS)
                .register(registry);

            Gauge
                .builder("cache.near.evictions", cache,
                        cache -> getDouble(cache.getLocalMapStats(),
                                (stats) -> Objects.requireNonNull(stats.getNearCacheStats()).getEvictions()))
                .tags(getTagsWithCacheName())
                .description("The number of evictions of near cache entries owned by this member")
                .register(registry);

            Gauge
                .builder("cache.near.persistences", cache,
                        cache -> getDouble(cache.getLocalMapStats(),
                                (stats) -> Objects.requireNonNull(stats.getNearCacheStats()).getPersistenceCount()))
                .tags(getTagsWithCacheName())
                .description("The number of near cache key persistences (when the pre-load feature is enabled)")
                .register(registry);
        }
    }

    private void timings(MeterRegistry registry) {
        FunctionTimer.builder("cache.gets.latency", cache,
                cache -> getLong(cache.getLocalMapStats(), LocalMapStats::getGetOperationCount),
                cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getTotalGetLatency), TimeUnit.MILLISECONDS)
            .tags(getTagsWithCacheName())
            .description("Cache gets")
            .register(registry);

        FunctionTimer.builder("cache.puts.latency", cache,
                cache -> getLong(cache.getLocalMapStats(), LocalMapStats::getPutOperationCount),
                cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getTotalPutLatency), TimeUnit.MILLISECONDS)
            .tags(getTagsWithCacheName())
            .description("Cache puts")
            .register(registry);

        FunctionTimer
            .builder("cache.removals.latency", cache,
                    cache -> getLong(cache.getLocalMapStats(), LocalMapStats::getRemoveOperationCount),
                    cache -> getDouble(cache.getLocalMapStats(), LocalMapStats::getTotalRemoveLatency),
                    TimeUnit.MILLISECONDS)
            .tags(getTagsWithCacheName())
            .description("Cache removals")
            .register(registry);
    }

    private long getLong(@Nullable LocalMapStats localMapStats, ToLongFunction<LocalMapStats> function) {
        return localMapStats != null ? function.applyAsLong(localMapStats) : 0L;
    }

}
