/*
 * Copyright 2017 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.cache;

import io.micrometer.common.util.internal.logging.InternalLogger;
import io.micrometer.common.util.internal.logging.InternalLoggerFactory;
import io.micrometer.core.instrument.*;
import io.micrometer.core.instrument.config.InvalidConfigurationException;
import org.jspecify.annotations.Nullable;

import javax.cache.Cache;
import javax.cache.CacheManager;
import javax.cache.configuration.CompleteConfiguration;
import javax.management.*;
import java.util.List;

/**
 * Collect metrics on JSR-107 JCache caches, including detailed metrics on manual puts and
 * removals. See
 * https://github.com/jsr107/demo/blob/master/src/test/java/javax/cache/core/StatisticsExample.java
 * <p>
 * Note that JSR-107 does not provide any insight into the size or estimated size of the
 * cache, so the size metric of a JCache cache will always report 0.
 * <p>
 * The statistics-enabled state is captured when this binder is created. Runtime changes
 * made through {@link CacheManager#enableStatistics(String, boolean)} are not tracked. If
 * statistics are enabled later, create and bind a new {@code JCacheMetrics} instance to
 * register statistics-dependent meters.
 *
 * @author Jon Schneider
 * @author Jewoo Shin
 */
public class JCacheMetrics<K, V, C extends Cache<K, V>> extends CacheMeterBinder<C> {

    private static final InternalLogger log = InternalLoggerFactory.getInstance(JCacheMetrics.class);

    // VisibleForTesting
    @Nullable ObjectName objectName;

    private final boolean registerCacheRemovalsAsFunctionCounter;

    private final boolean statisticsEnabled;

    /**
     * Record metrics on a JCache cache.
     * @param registry The registry to bind metrics to.
     * @param cache The cache to instrument.
     * @param tags Tags to apply to all recorded metrics. Must be an even number of
     * arguments representing key/value pairs of tags.
     * @param <C> The cache type.
     * @param <K> The cache key type.
     * @param <V> The cache value type.
     * @return The instrumented cache, unchanged. The original cache is not wrapped or
     * proxied in any way.
     */
    public static <K, V, C extends Cache<K, V>> C monitor(MeterRegistry registry, C cache, String... tags) {
        return monitor(registry, cache, Tags.of(tags));
    }

    /**
     * Record metrics on a JCache cache.
     * @param registry The registry to bind metrics to.
     * @param cache The cache to instrument.
     * @param tags Tags to apply to all recorded metrics.
     * @param <C> The cache type.
     * @param <K> The cache key type.
     * @param <V> The cache value type.
     * @return The instrumented cache, unchanged. The original cache is not wrapped or
     * proxied in any way.
     */
    public static <K, V, C extends Cache<K, V>> C monitor(MeterRegistry registry, C cache, Iterable<Tag> tags) {
        return monitor(registry, cache, Tags.of(tags), false);
    }

    /**
     * Record metrics on a JCache cache.
     * @param registry The registry to bind metrics to.
     * @param cache The cache to instrument.
     * @param tags Tags to apply to all recorded metrics.
     * @param registerCacheRemovalsAsFunctionCounter whether to register the
     * {@code cache.removals} metric as a FunctionCounter
     * @param <C> The cache type.
     * @param <K> The cache key type.
     * @param <V> The cache value type.
     * @return The instrumented cache, unchanged. The original cache is not wrapped or
     * proxied in any way.
     * @since 1.14.9
     */
    public static <K, V, C extends Cache<K, V>> C monitor(MeterRegistry registry, C cache, Iterable<Tag> tags,
            boolean registerCacheRemovalsAsFunctionCounter) {
        new JCacheMetrics<>(cache, tags, registerCacheRemovalsAsFunctionCounter).bindTo(registry);
        return cache;
    }

    public JCacheMetrics(C cache, Iterable<Tag> tags) {
        this(cache, tags, true);
    }

    /**
     * Create a {@link CacheMeterBinder} for a JCache instance.
     * @param cache the JCache instance to instrument
     * @param tags additional tags to add to JCache meters
     * @param registerCacheRemovalsAsFunctionCounter whether to register the
     * {@code cache.removals} metric as a FunctionCounter
     * @since 1.14.9
     */
    public JCacheMetrics(C cache, Iterable<Tag> tags, boolean registerCacheRemovalsAsFunctionCounter) {
        super(cache, cache.getName(), tags);
        this.registerCacheRemovalsAsFunctionCounter = registerCacheRemovalsAsFunctionCounter;
        this.statisticsEnabled = isStatisticsEnabled(cache);
        if (!statisticsEnabled) {
            log.warn(
                    "The cache '{}' is not recording statistics. No meters that require statistics will be registered. Enable statistics for this cache (for example by calling 'MutableConfiguration#setStatisticsEnabled(true)' when building the cache) before binding metrics.",
                    cache.getName());
        }
        try {
            CacheManager cacheManager = cache.getCacheManager();
            if (cacheManager != null) {
                // ehcache's uri is prefixed with 'urn:'
                String cacheManagerUri = cacheManager.getURI().toString().replace(':', '.');

                this.objectName = new ObjectName("javax.cache:type=CacheStatistics" + ",CacheManager=" + cacheManagerUri
                        + ",Cache=" + cache.getName());
            }
        }
        catch (MalformedObjectNameException ignored) {
            throw new InvalidConfigurationException(
                    "Cache name '" + cache.getName() + "' results in an invalid JMX name");
        }
    }

    @Override
    protected @Nullable Long size() {
        // JCache statistics don't support size
        return null;
    }

    @Override
    protected long hitCount() {
        if (!statisticsEnabled) {
            return UNSUPPORTED;
        }
        return lookupStatistic("CacheHits");
    }

    @Override
    protected @Nullable Long missCount() {
        if (!statisticsEnabled) {
            return null;
        }
        return lookupStatistic("CacheMisses");
    }

    @Override
    protected @Nullable Long evictionCount() {
        if (!statisticsEnabled) {
            return null;
        }
        return lookupStatistic("CacheEvictions");
    }

    @Override
    protected long putCount() {
        if (!statisticsEnabled) {
            return UNSUPPORTED;
        }
        return lookupStatistic("CachePuts");
    }

    @Override
    protected void bindImplementationSpecificMetrics(MeterRegistry registry) {
        if (!statisticsEnabled) {
            return;
        }
        if (objectName != null) {
            if (registerCacheRemovalsAsFunctionCounter) {
                FunctionCounter.builder("cache.removals", objectName, objectName -> lookupStatistic("CacheRemovals"))
                    .tags(getTagsWithCacheName())
                    .description("Cache removals")
                    .register(registry);
            }
            else {
                Gauge.builder("cache.removals", objectName, objectName -> lookupStatistic("CacheRemovals"))
                    .tags(getTagsWithCacheName())
                    .description("Cache removals")
                    .register(registry);
            }
        }
    }

    @SuppressWarnings("unchecked")
    private static boolean isStatisticsEnabled(Cache<?, ?> cache) {
        try {
            CompleteConfiguration<?, ?> config = cache.getConfiguration(CompleteConfiguration.class);
            // When the provider does not expose CompleteConfiguration (or the
            // configuration cannot be resolved), assume statistics are enabled
            // to avoid a false positive warning and avoid skipping meters.
            return config == null || config.isStatisticsEnabled();
        }
        catch (IllegalArgumentException ignored) {
            return true;
        }
    }

    private Long lookupStatistic(String name) {
        if (objectName != null) {
            try {
                List<MBeanServer> mBeanServers = MBeanServerFactory.findMBeanServer(null);
                for (MBeanServer mBeanServer : mBeanServers) {
                    try {
                        return (Long) mBeanServer.getAttribute(objectName, name);
                    }
                    catch (AttributeNotFoundException | InstanceNotFoundException ex) {
                        // did not find MBean, try the next server
                    }
                }
            }
            catch (MBeanException | ReflectionException ex) {
                throw new IllegalStateException(ex);
            }
        }

        // didn't find the MBean in any servers
        return 0L;
    }

}
