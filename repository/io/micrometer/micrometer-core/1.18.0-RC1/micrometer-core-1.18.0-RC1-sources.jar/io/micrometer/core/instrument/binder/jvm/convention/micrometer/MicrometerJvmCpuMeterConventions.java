/*
 * Copyright 2025 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention.micrometer;

import io.micrometer.core.instrument.Tags;

/**
 * Historical convention used in Micrometer JVM-derived CPU related metrics.
 *
 * @see io.micrometer.core.instrument.binder.system.ProcessorMetrics
 * @since 1.16.0
 * @deprecated use individual convention types such as
 * {@link MicrometerJvmCpuTimeMeterConvention},
 * {@link MicrometerJvmCpuCountMeterConvention}, and
 * {@link MicrometerJvmCpuLoadMeterConvention} instead
 */
@Deprecated
@SuppressWarnings("deprecation")
public class MicrometerJvmCpuMeterConventions
        implements io.micrometer.core.instrument.binder.jvm.convention.JvmCpuMeterConventions {

    private final Tags extraTags;

    public MicrometerJvmCpuMeterConventions(Tags extraTags) {
        this.extraTags = extraTags;
    }

    protected Tags getCommonTags() {
        return extraTags;
    }

    @Override
    public io.micrometer.core.instrument.binder.MeterConvention<Object> cpuTimeConvention() {
        return new io.micrometer.core.instrument.binder.SimpleMeterConvention<>("process.cpu.time", getCommonTags());
    }

    @Override
    public io.micrometer.core.instrument.binder.MeterConvention<Object> cpuCountConvention() {
        return new io.micrometer.core.instrument.binder.SimpleMeterConvention<>("system.cpu.count", getCommonTags());
    }

    @Override
    public io.micrometer.core.instrument.binder.MeterConvention<Object> processCpuLoadConvention() {
        return new io.micrometer.core.instrument.binder.SimpleMeterConvention<>("process.cpu.usage", getCommonTags());
    }

}
