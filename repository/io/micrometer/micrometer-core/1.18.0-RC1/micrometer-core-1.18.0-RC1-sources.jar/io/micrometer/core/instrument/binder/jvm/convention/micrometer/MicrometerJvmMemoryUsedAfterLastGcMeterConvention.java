/*
 * Copyright 2026 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.core.instrument.binder.jvm.convention.micrometer;

import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.binder.jvm.convention.JvmMemoryUsedAfterLastGcMeterConvention;

import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;

/**
 * Historical convention used in Micrometer instrumentation for JVM memory used after last
 * GC metrics.
 *
 * @see io.micrometer.core.instrument.binder.jvm.JvmMemoryMetrics
 * @since 1.18.0
 */
public class MicrometerJvmMemoryUsedAfterLastGcMeterConvention implements JvmMemoryUsedAfterLastGcMeterConvention {

    @Override
    public String getName() {
        return "jvm.memory.used_after_last_gc";
    }

    @Override
    public Tags getTags(MemoryPoolMXBean memoryPoolBean) {
        return Tags.of("id", memoryPoolBean.getName(), "area",
                MemoryType.HEAP.equals(memoryPoolBean.getType()) ? "heap" : "nonheap");
    }

}
